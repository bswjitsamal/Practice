package com.hexa;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Sample {

	
	  public static void main(String[] args) { // TODO Auto-generated method stub
		  Sample s = new Sample();
		  s.GetWeatherDetails();
	  }
	 

	public void GetWeatherDetails()
	 {   
		
		//Specify the base URL to RESTful web services
		RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city";
		
		//Get the RequestSpecification of the request that you want to sent
		//to the server, the server is specified by the BaseURL that we have 
		//specified in the above step
		
		RequestSpecification httpRequest = RestAssured.given();
		
		//Make a request to the server by specifying the method Type and method URL
		//This will return the Response from server 
		Response response = httpRequest.request(Method.GET, "/Hyderabad");
		
		//Read the header of a given name , In this line we will get the Header name Content-Type
		String contentType = response.header("Content-Type");
		
		//Validating the content type header
		//Assert that correct status code is required
		if (contentType.equals("application/json")) {
			System.out.println("It is returing true value");
		}
		else {
			System.out.println("the header content type -->" + contentType);
		}
				
		
		//In this line we will get the Header name Server
		String serverType = response.header("Server");
		
		//Assert that correct status code is required
		if(serverType.equals("nginx")) {
			System.out.println("It is returing true value");
		}
		else{
			System.out.println("the server value is -->" +serverType);
		}
		
		// In this line we will get the Header name Content-Encoading
        String acceptLanguage = response.header("Content-Encoding");
        
      //Assert that correct status code is required
      	if(acceptLanguage.equals("gzip")) {
      			System.out.println("It is returing true value");
      	}
     	else{
      			System.out.println("the Content-Encoading -->" +acceptLanguage);
      		}
      		

        
		// Print response time
		long timeInMs  = response.time();
		System.out.println("Response Time in Ms : " + timeInMs );
		
		//Now let us print the body of the message to see what response 
		// We have received from the server
		String responseBody = response.getBody().asString();
		System.out.println("Response Boday is --> " +responseBody);
		
		//Getting the status code
		int statusCode = response.getStatusCode();

		
		//Assert that correct status code is required
		if(statusCode == 200) {
			System.out.println("It is returing true value");
		}
		else{
			System.out.println("the respose code is -->" +response);
		}
		
		
		//Get the 1st JsonPath object instance from the Response interface
		JsonPath jsonPathEvaluator = response.jsonPath();
		String city = jsonPathEvaluator.get("City");
		if(city.equals("Hyderabad")) {
			System.out.println("Correct City name is received in the response");
		}
		else{
			System.out.println("the respose code is -->" +response);
		}
		
	 }
}
