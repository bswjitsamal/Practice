package com.hexa;

import org.junit.*;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Demo2 {
	
	public static Response response;
    public static String jsonAsString;
	
	 @BeforeClass
	    public static void setupURL()
	    {
	        // here we setup the default URL and API base path to use throughout the tests
	        RestAssured.baseURI = "http://yourwebsiteaddress.com";
	        RestAssured.basePath = "/api/yourapi/";
	    }
	 @Test
	    public static void callRidesAPI()
	    {
	        // call the rides API, the full address is "http://yourwebsiteaddress.com/api/yourapi/rides",
	        // but we set the default above, so just need "/rides"
	        response =
	            when().
	                get("/rides").
	            then().
	                contentType(ContentType.JSON).  // check that the content type return from the API is JSON
	            extract().response(); // extract the response

	        // We convert the JSON response to a string, and save it in a variable called 'jsonAsString'
	        jsonAsString = response.asString();
	    }

}
