package com.hexa;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetRequestWithQueryParameters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI = "https://reqres.in/api";
		
		Response res = null;
		
		try {
			res  = RestAssured.given()
					.when().queryParam("page", 2).queryParam("id", 5)
					.get("/users");
		}catch(Exception e) {
			e.printStackTrace();
		}

		System.out.println("Response: "+res.asString());
		System.out.println("Response Code: " +res.getStatusCode());
	}

}
