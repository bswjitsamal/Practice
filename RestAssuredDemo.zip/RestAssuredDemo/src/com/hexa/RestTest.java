package com.hexa;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

import java.util.List;
import java.util.Map;


public class RestTest {
	
	public static Response doGetRequest(String endPoint) {
		RestAssured.defaultParser = Parser.JSON;
		return
				given().headers("Content-type", ContentType.JSON, "Accept", ContentType.JSON).
				when().get(endPoint).
				then().contentType(ContentType.JSON).extract().response();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Response response = doGetRequest("https://jsonplaceholder.typicode.com/photos");
		// the $ symbol is for root nodes.

		List<String> jsonResponse = response.jsonPath().getList("$");
		System.out.println(jsonResponse.size());

		// Print response time
		long timeInMs = response.time();
		System.out.println("Response Time in Ms : " + timeInMs);

		String usernames = response.jsonPath().getString("title[0]");
		System.out.println(usernames);

		// If we want to get the 1st entry
		// Map<String, String> company = response.jsonPath().getMap("company[0]");
		// System.out.println(company.get("name"));
	}

}
