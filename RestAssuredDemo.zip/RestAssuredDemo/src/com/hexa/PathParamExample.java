package com.hexa;

import static org.junit.Assert.assertEquals;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class PathParamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String id = "210079";
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/";
		
		Response res = null;
		
		try {
			res = RestAssured.given()
					.pathParam("id", id)
					.when()
					.get("/{id}");
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Response: "+res.asString());
		System.out.println("Status Code:" + res.getStatusCode());
		System.out.println("Dose Response contains 'employee-salary' ?" + res.asString().contains("employee_salary"));

		assertEquals(200, res.getStatusCode());
	}

}
