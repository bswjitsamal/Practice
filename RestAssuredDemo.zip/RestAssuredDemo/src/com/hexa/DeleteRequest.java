package com.hexa;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class DeleteRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1";
		
		Response res = null;
		
		try {
			res = RestAssured.given()
					.contentType(ContentType.JSON)
					.delete("/delete/210079");					
		}catch (Exception e){
			e.printStackTrace();
		}
		System.out.println("Response: "+ res.asString());
		System.out.println("Status Code: "+ res.getStatusCode());
	}

}
