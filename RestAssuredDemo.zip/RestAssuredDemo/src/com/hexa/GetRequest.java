package com.hexa;

import static org.junit.Assert.assertEquals;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1";
		
		Response res = null;
		
		try {
			res = RestAssured.given()
					.when()
					.get("/employee/237808");					
		}catch(Exception e) {
			e.printStackTrace();
		}

		System.out.println("Response: "+ res.asString());
		System.out.println("Status Code: "+res.getStatusCode());
		///System.out.println("Dose Response contains employee_Salary: "+ res.asString().contains("employee_salary"));
		System.out.println("Does Reponse contains 'Biswjait'? :" + res.asString().contains("biswajit"));
		assertEquals(200, res.getStatusCode());
	}

}
