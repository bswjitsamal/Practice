package com.hexa;

import static org.junit.Assert.assertEquals;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class PostRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1";
		
		String requestBody = "{\n" +
	            "  \"name\": \"biswajit\",\n" +
	            "  \"salary\": \"5000\",\n" +
	            "  \"age\": \"20\"\n" +
	            "}";
		
		
		Response res = null;
		
		try {
			res = RestAssured.given()
					.contentType(ContentType.JSON)
					.body(requestBody)
					.post("/create");
		}catch (Exception e){
			e.printStackTrace();
		}
		
		System.out.println("Response: " + res.asString());
		System.out.println("Status Code: " + res.statusCode());
		System.out.println("Dose Response Contain 'Biswjait:  " + res.asString().contains("biswjait"));
		
		assertEquals(200,res.statusCode() );

	}

}
 	