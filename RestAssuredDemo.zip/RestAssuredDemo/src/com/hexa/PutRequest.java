package com.hexa;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.junit.Assert.assertEquals;

public class PutRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1";
		
		String requestBody = "{\r\n" +
	            " \"name\":\"Biswajit\",\r\n" +
	            " \"salary\":\"1123\",\r\n" +
	            " \"age\":\"23\"\r\n" +
	            "}";
		
		Response response = null;

		try {
            response = RestAssured.given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .put("/update/210079");
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Response :" + response.asString());
        System.out.println("Status Code :" + response.getStatusCode());
        System.out.println("Does Reponse contains 'Biswajit'? :" + response.asString().contains("Biswajit"));


        assertEquals(200, response.getStatusCode());
		
	}
	
	

}
