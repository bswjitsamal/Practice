package com.hexa;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class DeserializeJsonResponse {
	
	public static void main(String args[]) {
		
	}
	
	public void RegistrationSuccessfull(){
		
		RestAssured.baseURI = "http://restapi.demoqa.com/customer";
		RequestSpecification request = RestAssured.given();
		
		 JSONObject requestParams = new JSONObject();
		 requestParams.put("FirstName", "Virender"); // Cast
		 requestParams.put("LastName", "Singh");
		 requestParams.put("UserName", "63userf2d3d2011");
		 requestParams.put("Password", "password1"); 
		 requestParams.put("Email",  "ed26dff39@gmail.com");
		
	}
	
	

}
