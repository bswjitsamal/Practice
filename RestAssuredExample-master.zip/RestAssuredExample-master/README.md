# RestAssuredExample
RestAssured Example
You can find details here: https://www.swtestacademy.com/api-testing-with-rest-assured/
