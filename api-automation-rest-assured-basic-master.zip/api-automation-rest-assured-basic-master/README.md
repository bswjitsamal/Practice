# api-automation-rest-assured-basic
Basic Rest Assured Automation Example

You can learn details in swtestacademy.com
Here is the link: https://www.swtestacademy.com/api-testing-with-rest-assured/ 
