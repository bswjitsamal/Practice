# Lifetime Selenium

Testing code to validate code is functioning correctly. 
Build with JUnit and Selenium

### Table of Contents
**[Maven](#run-test-with-maven)**<br>
**[Environment Profile](#environment-profile)**<br>
**[Test Tier Execution](#test-tier-execution)**<br>
**[Putting It All Together](#putting-it-all-together)**<br>
**[Installation](#installation)**<br>
**[Push result to qTest](#push-result-to-qtest)**<br>


## Run Test with Maven
To run all test simply execute 

`mvn clean verify`

To run test on a specfic browser append one of the following properties

- `-Dbrowser=firefox`
- `-Dbrowser=chrome`
- `-Dbrowser=ie`
- `-Dbrowser=edge`
- `-Dbrowser=opera`
- `-Dbrowser=htmlunit`
- `-Dbrowser=phantomjs`
- `-Dbrowser=chrome_headless`
- `-Dbrowser=WINDOWS_10_CHROME_63`
- `-Dbrowser=WINDOWS_10_FIREFOX_57`
- `-Dbrowser=WINDOWS_10_IE_11`
//TODO Need to add few more browserstack configurations

Example execution

`mvn clean verify -Dbrowser=chrome`

## Environment Profile
To specify the environment add one of the following (defaults to qa)

- `-Pdev`
- `-Pint`
- `-Pqa`
- `-Pstg`
- `-Pprd`

## Test Tier Execution
To specify a tier test add one of the following

- `-Ptier1`
- `-Ptier2`
- `-Ptier3`

## Putting It All Together
You can combine properties and profiles to customize your execution

In the example below we are specifying single test name test to execute in  **Chrome** on **QA**:

'clean verify -Dtest=*Test#test_tier_Sampletest1 -Dbrowser=CHROME -Pqa

In the example below we are specifying **Tier 1** test in **Chrome** on **QA**:

'clean verify -Dbrowser=CHROME -Pqa,test'

In the example below we are specifying **Tier 1** test in **WINDOWS_10_CHROME_63** on **QA**:

'clean verify -Dbrowser=WINDOWS_10_CHROME_65 -Pqa,test'

## Debug Test:

In the example below we are specifying **Tier 1** test in **IE** on **QA**:

'-DforkMode=never test -Dmaven.surefire.debug test -Dbrowser=IE -Pqa,tier1'

## Installation

> //TODO <br/>
> add links to resources

## Push result to qTest

In the example below we are specifying  **Tier 1** test in **Chrome** on **QA** and specifying profile 'qtest' at the end to push result to qTest

'clean verify -Dbrowser=CHROME -Pqa,tier1,qtest

if profile 'qtest' not specified, then the execution results will be generated but will not be pushed to qTest.

'clean verify -Dbrowser=CHROME -Pqa,tier1
