package net.lt.tests;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
//import net.lt.pages.AccountsPage;
import net.lt.pages.BookabilityPage;
import net.lt.pages.BookingPage;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.EventPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ReservationConfirmationPage;
import net.lt.pages.ReservationsPage;
import net.lt.pages.ReviewAndPaymentPage;

public class PaidEventsTest extends TestBase {
	
	EventPage evntPg;
	LoginPage lgnPg;
	Utility util;
	DetailsPage detlPg;
	HomePage homPg;
	BookingPage bookingPg;
	ReviewAndPaymentPage revPaymentPage;	
	PendingReservationPage pResvPg;
	ReservationConfirmationPage ConfPg;
	ClassSchedulesPage clsSchPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	BookabilityPage bookabilityPg;
	
	
	@Before
	public void paidEventsSetup() {


		
		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
	
		evntPg = new EventPage(driver);

	} 

	@Test
	public void test_tier1_employeeCompletePayment() throws InterruptedException {

		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		DetailsPage detlPg = new DetailsPage(driver);
		HomePage homPg = new HomePage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		ReviewAndPaymentPage revPaymentPage = new ReviewAndPaymentPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.memberemployee.user"),
				envProperties.getProperty("login.memberemployee.password"));

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.eventsCrossTown);

		evntPg.selectDatefromMultiDate(2);

		Thread.sleep(900);
		util.waitAndClickElement(evntPg.getSpooktacular());

		util.verifyPageTitle(Constants.eventDetailsCrossTown);

		util.waitAndClickElement(detlPg.getBtnReserve());
		util.waitAndClickElement(bookingPg.getSelectParticipant());
		
		util.waitAndClickElement(revPaymentPage.getChkBoxNewTandC());
	//	util.waitAndClickElement(pResvPg.getBtnContinueToFinish());
		Thread.sleep(2900);
		// WE are in Review and Payment page
		
		/*util.waitAndClickElement(revPaymentPage.getSelectCreditCardTab());

		revPaymentPage.getInputName().sendKeys(envProperties.getProperty("member.user.name"));
		revPaymentPage.getInputCardNu().sendKeys(envProperties.getProperty("member.user.cardnu"));
		revPaymentPage.getInputMonth().sendKeys(envProperties.getProperty("member.user.month"));
		revPaymentPage.getInputYear().sendKeys(envProperties.getProperty("member.user.year"));
		revPaymentPage.getInputSecurityCode().sendKeys(envProperties.getProperty("member.user.securitycode"));
		revPaymentPage.getInputBillingZip().sendKeys(envProperties.getProperty("member.user.zip"));*/
		
		
		

		util.waitAndClickElement(revPaymentPage.getChkBoxTandC());
		util.waitAndClickElement(revPaymentPage.getBtnCompletePurchase());

		// util.browserRefresh();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());

		

	}

	/**
	 * 
	 * @throws Breakfast With Santa..(Paid Event)
	 */

	@Test
	public void test_tier1_oneUseroneChildAndCompletePayment() throws InterruptedException {

		

		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		DetailsPage detlPg = new DetailsPage(driver);
		HomePage homPg = new HomePage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		ReviewAndPaymentPage revPaymentPage = new ReviewAndPaymentPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.paidmember.user"),
				envProperties.getProperty("login.paidmember.password"));

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.eventsCrossTown);
		evntPg.selectDatefromMultiDate(2);

		util.waitAndClickElement(evntPg.getBreakfastWithSanta());

		util.verifyPageTitle(Constants.eventDetailsCrossTown);

		util.waitAndClickElement(detlPg.getBtnReserve());
		Thread.sleep(900);
		
		bookingPg.selectMultipleParticipants();
		pResvPg.confirmReservation();
		Thread.sleep(2900);
		

		// WE are in Review and Payment page
		//util.waitAndClickElement(revPaymentPage.getSelectCreditCardTab());
		
		//Clicking on change link
		util.waitAndClickElement(revPaymentPage.getLnkChange());
		
		//Clicking on another form of payment 
		util.waitAndClickElement(revPaymentPage.getLnkAntherFormPayment());
		Thread.sleep(900);
		//pare redirects to Payment information page

		revPaymentPage.getInputName().sendKeys(envProperties.getProperty("member.user.name"));
		revPaymentPage.getInputCardNu().sendKeys(envProperties.getProperty("member.user.cardnu"));
		revPaymentPage.getInputMonth().sendKeys(envProperties.getProperty("member.user.month"));
		revPaymentPage.getInputYear().sendKeys(envProperties.getProperty("member.user.year"));
		//revPaymentPage.getInputSecurityCode().sendKeys(envProperties.getProperty("member.user.securitycode"));
		revPaymentPage.getInputBillingZip().sendKeys(envProperties.getProperty("member.user.zip"));

		util.waitAndClickElement(revPaymentPage.getBtnUpdatePayment());
		Thread.sleep(900);
		
		util.waitAndClickElement(revPaymentPage.getChkBoxTandC());
		util.waitAndClickElement(revPaymentPage.getBtnCompletePurchase());
		
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		
		

	}

	@Test
	public void test_tier1_addAdultOnlyToCompletePayment() throws InterruptedException {

		

		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		DetailsPage detlPg = new DetailsPage(driver);
		HomePage homPg = new HomePage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		ReviewAndPaymentPage revPaymentPage = new ReviewAndPaymentPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.paidmember.user"),
				envProperties.getProperty("login.paidmember.password"));

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.eventsCrossTown);
		evntPg.selectDatefromMultiDate(1);

		util.waitAndClickElement(evntPg.getBreakfastWithSanta());

		util.verifyPageTitle(Constants.eventDetailsCrossTown);

		util.waitAndClickElement(detlPg.getBtnReserve());
		util.waitAndClickElement(bookingPg.getSelectParticipant());
		
		util.waitAndClickElement(revPaymentPage.getChkBoxNewTandC());
	//	util.waitAndClickElement(pResvPg.getBtnContinueToFinish());
		Thread.sleep(900);

		util.isElementPresent(Constants.youmustselectoneadultandonejunior);
		
		//util.isTextPresent(bookingPg.getErrorTxtYouMustSelectOneAdultAndJunior(), Constants.youmustselectoneadultandonejunior);

		

	}

	@Test
	public void test_tier1_VerifySameUserRegister() throws InterruptedException {

		

		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		DetailsPage detlPg = new DetailsPage(driver);
		HomePage homPg = new HomePage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		BookabilityPage bokabltyPg = new BookabilityPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.paidmember.user"),
				envProperties.getProperty("login.paidmember.password"));

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.eventsCrossTown);
		evntPg.selectDatefromMultiDate(1);

		util.clickElement(evntPg.getSpooktacular());

		util.verifyPageTitle(Constants.EVENT_DETAILS_PAGE_TITLE);
		util.clickElement(detlPg.getBtnReserve());
		util.verifyPageTitle(Constants.Reservations);
		pResvPg.selectParticipants();//select multiple participants
		
		util.clickElement(revPaymentPage.getChkBoxNewTandC());
		util.clickElement(pResvPg.getBtnContinueToPayment());
			
		util.clickElement(revPaymentPage.getChkBoxTandC());
		util.clickElement(revPaymentPage.getBtnCompletePurchase());
		
		util.isTextPresent(ConfPg.getConfirmationText(), Constants.confirmationText);
		util.isTextPresent(ConfPg.getConfirmation(), Constants.confirmationtext2);

		// Redirecting to pending reservation page
		pResvPg.confirmReservation();

		/// Logout from the applicaion and loged in as seconday member
		util.clickElement(bokabltyPg.getloggedInName());
		util.clickElement(bokabltyPg.getBtnLogOut());

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/crosstown-eden-prairie/events.html");

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		// Again try to reserve the same user
		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.eventsCrossTown);

		evntPg.selectDatefromMultiDate(1);

		util.waitAndClickElement(evntPg.getSpooktacularFree());

		util.verifyPageTitle(Constants.eventDetailsCrossTown);

		util.waitAndClickElement(detlPg.getBtnReserve());

		lgnPg.login(envProperties.getProperty("login.paidmember.user"),
				envProperties.getProperty("login.paidmember.password"));
		Thread.sleep(900);
		util.waitAndClickElement(bookingPg.getSelectParticipant());
		util.waitAndClickElement(bookingPg.getBtnNext());

		new Utility(driver).isTextPresent(bookingPg.getAlertMsg(), "User is already registered.");
		util.waitAndClickElement(myResvPg.getBtnMyReservations());

		// util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());

		myResvPg.verifyConfirmationAndCancellationReservation("Spooktacular");

		
	}

	
	
/*
	
	@Test
	public void test_tier1_TimerTimesOutforGenericCartComponent() throws InterruptedException {

		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		DetailsPage detlPg = new DetailsPage(driver);
		HomePage homPg = new HomePage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		ReviewAndPaymentPage revPaymentPage = new ReviewAndPaymentPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.paidmember.user"),
				envProperties.getProperty("login.paidmember.password"));

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.eventsCrossTown);

		int dayOfMonth = util.addDaysToDate(1);
		util.clickElement(driver.findElement(By.id("date-from")));
		evntPg.selectDatefromMultiDate(String.valueOf(dayOfMonth));

		util.waitAndClickElement(evntPg.getBreakfastWithSanta());

		util.verifyPageTitle(Constants.eventDetailsCrossTown);

		util.waitAndClickElement(detlPg.getBtnResrve());
		bookingPg.selectMultipleParticipants();
		util.waitAndClickElement(bookingPg.getBtnNext());


		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		
		// Wait for page to load
		Thread.sleep(600000);
		
		//Verify Modal should display on screen 
		pResvPg.verifyModalOnScreen();
		
		//Verify timer is rest again 
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		
	}*/
	
	@Test
	public void test_tier1_VerifyThirdPartyReservations() throws InterruptedException {	

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));

		homPg.searchLocation("Crosstown (Eden Prairie)");
		util.verifyPageTitle(Constants.CrossTown);

		util.clickElement(homPg.getLnkEvent());
		util.clickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.EVENT_PAGE_TITLE);
		evntPg.selectDatefromMultiDate(1);
		util.clickElement(evntPg.getLnk3rdParty());

		util.verifyPageTitle(Constants.EVENT_DETAILS_PAGE_TITLE);
		
		Assert.assertTrue(util.isElementPresent(detlPg.getBtnReserveByLocator()));
		
		Assert.assertTrue(util.isElementPresent("Reservations are managed through an external website."));
	}
	
	@Test
	public void test_tier1_VerifyPaidEventsInPendingReservationPage() throws InterruptedException {
		

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.user2.user"), envProperties.getProperty("login.user2.password"));
		util.verifyPageTitle(Constants.Chanhassen);

		util.clickElement(homPg.getLnkEvent());
		util.clickElement(homPg.getLnkAllEvent());	

		evntPg.selectDatefromMultiDate(1);

		util.clickElement(evntPg.getSpooktacular());

		util.verifyPageTitle(Constants.EVENT_DETAILS_PAGE_TITLE);
		util.clickElement(detlPg.getBtnReserve());
		util.verifyPageTitle(Constants.Reservations);
		Assert.assertTrue(util.isTextPresent(pResvPg.getTax(), Constants.Tax));
		Assert.assertTrue(util.isTextPresent(pResvPg.getTitle(), Constants.TitleSpooktacular));//verify Title Spooktacular
		Assert.assertTrue(util.isElementPresent(pResvPg.getBtnContinueToPayment()));//verify Continue to Payment button is present
		Assert.assertTrue(util.isElementPresent(pResvPg.getLinkCancel()));
		pResvPg.verifyParticipantsEnabled();
		pResvPg.selectParticipants();//select multiple participants
	}
	
		
	@Test
	public void test_tier1_VerifyPaidEventsInReviewPaymentAndConfirmationPage() throws InterruptedException {

		
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.user1.user"), envProperties.getProperty("login.user1.password"));
		util.verifyPageTitle(Constants.Chanhassen);

		util.clickElement(homPg.getLnkEvent());
		util.clickElement(homPg.getLnkAllEvent());
		util.verifyPageTitle(Constants.EventsChanhassen);		

		util.clickElement(evntPg.getSpooktacular());

		util.verifyPageTitle(Constants.EVENT_DETAILS_PAGE_TITLE);

		util.clickElement(detlPg.getBtnReserve());	
		
		
		util.clickElement(bookingPg.getSelectParticipant());
		
		util.clickElement(revPaymentPage.getChkBoxNewTandC());
		util.clickElement(pResvPg.getBtnContinueToPayment());
		Thread.sleep(900);
		
		if(revPaymentPage.LinkChange().isDisplayed() )
		{
			util.isTextPresentAndClickText(revPaymentPage.LinkChange(), "Change");
			util.isTextPresentAndClickText(revPaymentPage.LinkChange(), "Add another form of payment");
			revPaymentPage.updatePaymentInformation("AutoTest","4112344112344113","02","20","55344");
	        Thread.sleep(900);
		}
		
		
		util.clickElement(revPaymentPage.getChkBoxTandC());
		util.clickElement(revPaymentPage.getBtnCompletePurchase());
		
		util.isTextPresent(ConfPg.getConfirmationText(), Constants.confirmationText);
		util.isTextPresent(ConfPg.getConfirmation(), Constants.confirmationtext2);
		util.clickElement(ConfPg.geBtnViewAllReservations());
		util.verifyPageTitle(Constants.Reservations);
		



	}


}
