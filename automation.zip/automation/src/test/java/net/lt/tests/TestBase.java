package net.lt.tests;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import net.lt.config.DriverFactory;
import net.lt.config.EnvConfig;

public class TestBase extends DriverFactory {

	Properties envProperties;
	public Capabilities capabilities;
	String env;

	@Before
	public void setup() {
		try {
			envProperties = EnvConfig.getInstance().getEnvProperties();
			driver = getDriver();
			capabilities = ((RemoteWebDriver) driver).getCapabilities();
			if (capabilities.getCapability("deviceName") == null) {
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.manage().window().maximize();
			} else {
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				System.out.println("Current Device: " + capabilities.getCapability("deviceName"));
			}		
			driver.get(EnvConfig.getInstance().getPrefix() + "www.lifetime.life");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@After
	public void teardown() {
		quitDriver(); // Closes the browser and stops the selenium driver
	}
}