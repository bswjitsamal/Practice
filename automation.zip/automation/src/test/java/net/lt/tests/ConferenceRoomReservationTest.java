package net.lt.tests;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;

import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.BookingPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationConfirmationPage;
import net.lt.pages.ReservationsPage;

public class ConferenceRoomReservationTest extends TestBase {

	@Test
	public void test_tier1_ConferenceRoomCreateReservationPageTitle() {

		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);

		BookingPage bookingPg = new BookingPage(driver);
		ProgramsPage progPg = new ProgramsPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));

		// Navigating to my reservaton page and cancel all reservations
		util.clickElement(myResvPg.getBtnMyReservations());
		util.verifyPageTitle(Constants.Reservations);
		myResvPg.verifyConfirmationAndCancellationReservation("Cancel");
		util.clickElement(myResvPg.getMakeNewReservation());

		bookingPg.selectAvailableConferenceRoom();
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		pResvPg.confirmReservation();
		util.clickElement(resvConfPg.geBtnViewAllReservations());
		util.browserRefresh(1);
		myResvPg.verifyConfirmationAndCancellationReservation("Conference Room");

	}

	@Test
	public void test_tier1_PendingReservationCountdownTimer() {

		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);

		BookingPage bookingPg = new BookingPage(driver);
		ProgramsPage progPg = new ProgramsPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));

		bookingPg.selectAvailableConferenceRoom();
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));

		// Refresh the page and verifying the timer
		util.browserRefresh(1);
		util.verifyPageTitle(Constants.ConferenceRoomCreateReservationPageTitle);
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));

		pResvPg.confirmReservation();

		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		util.browserRefresh(1);
		myResvPg.verifyConfirmationAndCancellationReservation("Conference Room");

	}

	@Test
	public void test_tier1_VerfyLTworkCanNotViewMyLTReservations() {

		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		HomePage homPg = new HomePage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		ProgramsPage progPg = new ProgramsPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));

		bookingPg.selectAvailableConferenceRoom();
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		pResvPg.confirmReservation();
		util.clickElement(resvConfPg.geBtnViewAllReservations());

		new Utility(driver).isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), "Conference Room");

		util.clickElement(myResvPg.getLnkMembers());

		util.clickElement(homPg.getLnkReservation());

		new Utility(driver).isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), "Conference Room");
		// Verifying the reservation done in LT Work is not
																// displaying under MyLT

		/**
		 * Navigating to MyLT Page to verify the current reservation should not display
		 * under MyLT
		 */

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/st-louis-park.html");
		new Utility(driver).browserRefresh(1);

		util.verifyPageTitle(Constants.ST_LOUIS_PARK);
		//Assert.assertFalse(util.isTextPresent(homPg.getResevationBrief(), "Conference Room"));
		homPg.verifyReservationNotPresent();

	}

	@Test
	public void test_tier1_veriyAddToCalendarInformation() throws Exception {

		Utility util = new Utility(driver);
		Capabilities capabilities = util.getCapabilities();
		LoginPage lgnPg = new LoginPage(driver);
		String className = "Conference Room";

		BookingPage bookingPg = new BookingPage(driver);
		ProgramsPage progPg = new ProgramsPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);
		

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));

		bookingPg.selectAvailableConferenceRoom();
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		pResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());

		// util.browserRefresh();

//		util.waitAndClickElement(resvConfPg.geBtnAddToCalendar());
//		util.waitAndClickElement(resvConfPg.geBtnAddToCalendarModal());
//
//		myResvPg.verifyConfirmationAndCancellationReservation(className);

		myResvPg.verifyAddToCalendar(capabilities , className);

		util.verifyPageTitle(Constants.Reservations);
		myResvPg.verifyConfirmationAndCancellationReservation("Conference Room");

	}
	

}