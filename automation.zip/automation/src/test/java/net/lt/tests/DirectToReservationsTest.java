package net.lt.tests;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.BookabilityPage;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ReservationConfirmationPage;
import net.lt.pages.ReservationsPage;

public class DirectToReservationsTest extends TestBase {
	
	

	/**
	 * 
	 * Swim Assessment
	 * 
	 **/
	@Test
	public void test_tier1_SwimAssessment() {

		LoginPage lgnPg = new LoginPage(driver);
		BookabilityPage bookabltyPg = new BookabilityPage(driver);
		PendingReservationPage PResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		HomePage homPg = new HomePage(driver);
		Utility util = new Utility(driver);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");
		lgnPg.login(envProperties.getProperty("login.swimmember.user"),
				envProperties.getProperty("login.swimmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");

		util.waitAndClickElement(bookabltyPg.getLblParticipant());
		util.selectFromDropDown(bookabltyPg.getSelectDate());

		util.selectFromDropDown(bookabltyPg.getSelectTime());
		util.waitAndClickElement(bookabltyPg.getBtnNext());

		PResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		// myResvPg.clickMyReservations();
		util.browserRefresh(1);
		myResvPg.verifyConfirmationAndCancellationReservation("Swim");

		

	}

	@Test
	public void test_tier1_PTonBoarding() {
		
		LoginPage lgnPg = new LoginPage(driver);
		BookabilityPage bookabltyPg = new BookabilityPage(driver);
		PendingReservationPage PResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		HomePage homPg = new HomePage(driver);
		Utility util = new Utility(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/pt-onboarding.html");
		lgnPg.login(envProperties.getProperty("login.swimmember.user"),
				envProperties.getProperty("login.swimmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/pt-onboarding.html");

		util.waitAndClickElement(bookabltyPg.getLblParticipant());
		util.selectFromDropDown(bookabltyPg.getSelectDate());

		util.selectFromDropDown(bookabltyPg.getSelectTime());
		util.waitAndClickElement(bookabltyPg.getBtnNext());

		PResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		// myResvPg.clickMyReservations();
		util.browserRefresh(1);
		myResvPg.verifyConfirmationAndCancellationReservation("Onboarding");

	}
	
	
	
	@Test
	public void test_tier1_EditPTonBoarding() {
		
		LoginPage lgnPg = new LoginPage(driver);
		BookabilityPage bookabltyPg = new BookabilityPage(driver);
		PendingReservationPage PResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		HomePage homPg = new HomePage(driver);
		Utility util = new Utility(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/pt-onboarding.html");
		lgnPg.login(envProperties.getProperty("login.swimmember.user"),
				envProperties.getProperty("login.swimmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/pt-onboarding.html");

		util.waitAndClickElement(bookabltyPg.getLblParticipant());
		util.selectFromDropDown(bookabltyPg.getSelectDate());

		util.selectFromDropDown(bookabltyPg.getSelectTime());
		util.waitAndClickElement(bookabltyPg.getBtnNext());

		PResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		// myResvPg.clickMyReservations();
		util.browserRefresh(10);
		
		//Clicking on edit Reservation page
		
		myResvPg.verifyEditReservation("Onboarding");
		
		homPg.getLnkReservation().click();
		
		myResvPg.verifyEditReservation("Onboarding");
		util.waitAndClickElement(bookabltyPg.getLblParticipant());
		util.selectFromDropDown(bookabltyPg.getSelectDate());

		util.selectFromDropDown(bookabltyPg.getSelectTime());
		util.waitAndClickElement(bookabltyPg.getBtnNext());

		PResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		//-Pqtest
	}

	

	@Test
	public void test_tier1_60DayChallenge() {

		
		LoginPage lgnPg = new LoginPage(driver);
		BookabilityPage bookabltyPg = new BookabilityPage(driver);
		PendingReservationPage PResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		HomePage homPg = new HomePage(driver);
		Utility util = new Utility(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/60day.html");
		lgnPg.login(envProperties.getProperty("login.60daymember.user"),
				envProperties.getProperty("login.60daymember.password"));
		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/60day.html");

		util.waitAndClickElement(bookabltyPg.getLblParticipant());
		util.selectFromDropDown(bookabltyPg.getSelectDate());

		util.selectFromDropDown(bookabltyPg.getSelectTime());
		util.waitAndClickElement(bookabltyPg.getBtnNext());

		PResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		// myResvPg.clickMyReservations();
		util.browserRefresh(1);
		myResvPg.verifyConfirmationAndCancellationReservation("60day");

	}

	@Test
	public void test_tier1_SwimAssessmentParticipantOrder()
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
		LoginPage lgnPg = new LoginPage(driver);
		BookabilityPage bokabltyPg = new BookabilityPage(driver);
		HomePage homPg = new HomePage(driver);
		Utility util = new Utility(driver);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");
		lgnPg.login(envProperties.getProperty("login.swimmember.user"),
				envProperties.getProperty("login.swimmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");

		System.out.println("The participant name is displaying as 1st item is: "
				+ bokabltyPg.getloggedInName().getText().equals(bokabltyPg.get1stName().getText()));
		// Assert.assertEquals("The participant name is displaying as 1st item is: "+
		// bokabltyPg.getloggedInName().getText(),bokabltyPg.get1stName().getText());

		/**
		 * Verify the participant order
		 */

		HashMap<Integer, String> hashmap = new HashMap<Integer, String>();
		hashmap.put(107441744, "SwimmerMsMelissa");
		hashmap.put(107441756, "SwimmerMrJon (age 114)");
		hashmap.put(107441746, "SwimmerDos");
		hashmap.put(107441747, "SwimmerTres");
		hashmap.put(107441745, "SwimmerUno");
		hashmap.put(107547545, "AnotherUno");
		hashmap.put(107547542, "Anita");
		hashmap.put(107547547, "CincoMonths");
		hashmap.put(107547546, "CuatroMonths");
		hashmap.put(107547543, "Enita");
		hashmap.put(107547544, "SwimmerMrJon (age 0)");

		for (Map.Entry m : hashmap.entrySet()) {
			if (bokabltyPg.getParticipantName().contains(m.getValue()))
				System.out.println("Bingo: " + m.getKey());
		}

		// Logout from the applicaion and loged in as seconday member
		util.clickElement(bokabltyPg.getloggedInName());
		util.clickElement(bokabltyPg.getBtnLogOut());

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");
		lgnPg.login(envProperties.getProperty("login.swim2ndmember.user"),
				envProperties.getProperty("login.swim2ndmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");

		System.out.println("The participant name is displaying as 1st item is: "
				+ bokabltyPg.getloggedInName().getText().equals(bokabltyPg.get1stName().getText()));

		/*
		 * String[] Names = bokabltyPg.get1stName().getText().split(" ");
		 * 
		 * Assert.assertEquals("The participant name is displaying as 1st item is: "
		 * +Names[0], bokabltyPg.getloggedInName().getText());
		 */ }
	
	
	/*@Test
	public void test_tier1_TimerTimesOutforGenericCartComponent() throws InterruptedException {

		new ClassSchedulesPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		new DetailsPage(driver);
		new ReservationsPage(driver);
		HomePage homPg = new HomePage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);
		BookabilityPage bookabltyPg = new BookabilityPage(driver);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");
		lgnPg.login(envProperties.getProperty("login.swimmember.user"),
				envProperties.getProperty("login.swimmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		driver.navigate()
				.to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/account/booking/swim-assessment.html");

		util.waitAndClickElement(bookabltyPg.getLblParticipant());
		util.selectFromDropDown(bookabltyPg.getSelectDate());

		util.selectFromDropDown(bookabltyPg.getSelectTime());
		util.waitAndClickElement(bookabltyPg.getBtnNext());

		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		
		// Wait for page to load
		Thread.sleep(600000);
		
		//Verify Modal should display on screen 
		pResvPg.verifyModalOnScreen();
		
		//Verify timer is rest again 
		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		
	}*/


}