package net.lt.tests;

import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.BookingPage;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

public class PendingReservationTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	/**
	 * Description : To validate the ability to perform Platinum Reservation Created
	 * By : Saravanan Ravichandran Created Date : Feb 12th 2018 Modified By :
	 * Modified Date : Preconditions :
	 */

	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;

	PendingReservationPage pResvPg;
	ProgramsPage progPg ;


	@Before
	public void apiSetup() {

		// RestAssured.baseURI =
		// "https://api.lifetimefitness.com/qa/edge/api/"+Constants.apiResourceId+"&size=100";
		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";		

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
		progPg = new ProgramsPage(driver);

	}

	/**
	 * Method to reserve a court
	 * @param clubLocation
	 * @param courtToBeReserved
	 * @return 
	 */
	public String[] reserveACourt( String courtToBeReserved, int noOfDaysFromCurrentDay)
	{
		ProgramsPage progPg = new ProgramsPage(driver);
		homPg.navigateToPrograms(courtToBeReserved); // Navigate to Class Schedule page from member page
		// mbrPg.navigateToProgramPage("Yoga");
		util.verifyPageTitle(courtToBeReserved); // Verifying the page title

		String[] courtInfo = progPg.reserveACourt(courtToBeReserved, noOfDaysFromCurrentDay); // Reserve a court	
		return  courtInfo;
	}

	/**
	 * Description : To verify the Heading for courts selected, for Squash,Tennis and Racquetball court
	 * And Navigate to LTwork url and verify the conference room reservation
	 */

	@Test
	public void test_tier1_VerifyHeadingForCourtAndConferenceRoomsReservations() {

		BookingPage bookingPage = new BookingPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/st-louis-park.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		//login
		lgnPg.login(envProperties.getProperty("login.user1.user"), envProperties.getProperty("login.user1.password"));		
		util.verifyPageTitle("St. Louis Park");		


		//Racquetball Court
		String[] courtInfoRacquet = reserveACourt("Racquetball", 2);
		//verify the courtName, selected court and PageHeader
		pResvPg.verifyCourtTitle(courtInfoRacquet, "Racquetball");
		//click link Cancel
		util.clickElement(pResvPg.getLinkCancel());
		//verify Facilities page
		util.verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);

		//Squash Court
		String[] courtInfoSquash = reserveACourt("Squash", 3);
		//verify the courtName, selected court and PageHeader
		pResvPg.verifyCourtTitle(courtInfoSquash, "Squash");
		//click link Cancel
		util.clickElement(pResvPg.getLinkCancel());
		//verify Facilities page
		util.verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);


		//Tennis Court
		String[] courtInfoTennis =reserveACourt("Tennis", 3);
		//verify the courtName, selected court and PageHeader
		pResvPg.verifyCourtTitle(courtInfoTennis, "Tennis");
		//refresh the browser
		util.browserRefresh(1);
		//verify pending reservation page title
		util.verifyPageTitle(Constants.CourtReservations);
		//click link Cancel
		util.clickElement(pResvPg.getLinkCancel());
		//verify Facilities page
		util.verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);

		//navigate to LTwork URL
		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));		
		util.verifyPageTitle("Booking");		
		bookingPage.selectAvailableConferenceRoom();	
		bookingPage.cancelConferenceRoomReservation();

	}

	/**
	 * Description : To verify the StartTime,EndTime, CourtLocation, and verifying with 30mins and 60 mins duration in pending reservation page
	 * @throws ParseException 
	 */

	@Test
	public void test_tier1_VerifyMyLTcourtsPendingReservationsPage() throws ParseException {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/st-louis-park.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		//login
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));		
		util.verifyPageTitle("St. Louis Park");	

		homPg.navigateToPrograms("Tennis"); // Navigate to Class Schedule page from member page
		util.verifyPageTitle("Tennis"); // Verifying the page title
		String[] courtInfo = progPg.reserveACourt("Tennis", 5); // Reserve a court	
		util.verifyPageTitle(Constants.Reservations); 		
		Assert.assertTrue(pResvPg.getdrpdwnDuration().getText().contains("30 minutes"));//verify dropdwn default 30 mins		
		pResvPg.verifyCourtDetails(courtInfo, "St. Louis Park", 30);
		
		//Select duration 60 minutes from dropDown
		util.fn_Select(pResvPg.getdrpdwnDuration() , "60 minutes");
		util.waitUntilSpinnerDisappears();
	
		//Add 60 minutes to the current time
		pResvPg.verifyCourtDetails(courtInfo, "St. Louis Park", 60);
		

		//click link Cancel
		util.clickElement(pResvPg.getLinkCancel());
		//verify Facilities page
		util.verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);
	}






































}

