package net.lt.tests;



import net.lt.common.WebServiceUtil;

public class ExerpExampleClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String className = "EDG Cycle";
		String StudioName = "Cycle Studio";
		int clubId = 151;
		int capacity = 1;
		
		int bookingId = new WebServiceUtil().createClassInExerp( clubId, className, StudioName, capacity);		
		
		//int personId = new WebServiceUtil().getExerpPersonId("Warren Working", "PRIVATE");
		//int personId = new WebServiceUtil().getExerpPersonId("Swimmerchanhassen Michael", "PRIVATE");	
		
		//new WebServiceUtil().verifyReservationsExerp( clubId, personId,className, bookingId );
		//new WebServiceUtil().cancelBookingInExerp(151, bookingId);
	
	}

}
