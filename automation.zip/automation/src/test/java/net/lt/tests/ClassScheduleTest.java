package net.lt.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

public class ClassScheduleTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	/**
	 * Description : To validate the ability to perform Platinum Reservation Created
	 * By : Saravanan Ravichandran Created Date : Feb 12th 2018 Modified By :
	 * Modified Date : Preconditions :
	 */

	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;

	PendingReservationPage pResvPg;
	


	@Before
	public void apiSetup() {

		// RestAssured.baseURI =
		// "https://api.lifetimefitness.com/qa/edge/api/"+Constants.apiResourceId+"&size=100";
		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";		

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);		

	}


	/**
	 * Description : To verify the ability to view saved search, edit saved search and favorites class schedules
	 */

	@Test
	public void test_tier1_VerifyAbilityToViewSavedSearch() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		//login
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));		
		util.verifyPageTitle("Chanhassen");	

		homPg.navigateToClassSchPage(); // Navigate to Class Schedule page from member page
		util.verifyPageTitle(Constants.PageTitleChanhassen); // Verifying the page title

		clsSchPg.deleteAllFavourites();

		Assert.assertTrue(util.isTextPresent(clsSchPg.alertMsgNoFavSched(), Constants.YOU_HAVE_N0_FAV_MSG));
		//Add Favorites
		String name = clsSchPg.addFavourites();
		//Favorite name link is in blue color  '"+className+"'
		WebElement favNameXpath = driver.findElement(By.xpath("//div[@class='favorite-block']/button[contains(text(),'"+name+"')]"));
		Assert.assertTrue(util.getElementColor( favNameXpath).equalsIgnoreCase("#0078aa"));
		//verify chiclets	 
		Assert.assertTrue(clsSchPg.getSpnChiclets().getText().contains(name));
		//verify edit
		util.clickElement(clsSchPg.getBtnEditFav());
		clsSchPg.getInputEdit().clear();
		Assert.assertFalse(clsSchPg.getBtnSavEdit().isEnabled()); // save button is disabled

		// maximum length is 50 charac
		Assert.assertTrue(clsSchPg.getInputEdit().getAttribute("maxlength").equals("50"));
		String editedName = "mgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmg";
		util.enterText(clsSchPg.getInputEdit(), editedName);
		util.clickElement(clsSchPg.getBtnSavEdit());
		util.isTextPresent(clsSchPg.getTextContainer(), Constants.EditSuccessMessage);
		Assert.assertTrue(clsSchPg.getlnkFavName().getText().contains("mgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmg"));

		//Once again verify edit fav name 
		util.clickElement(clsSchPg.getBtnEditFav());
		util.clickElement(clsSchPg.getBtnSavEdit());
		Assert.assertTrue(clsSchPg.getlnkFavName().getText().contains("mgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmgmg"));

		//delete the fav
		util.clickElement(clsSchPg.getBtnDeletFav());
		util.clickElement(clsSchPg.getBtnDelFav());

		//add fav filter
		util.clickElement(clsSchPg.getBtnFilters()); // Clicking on the Filter button, it will get expand
		clsSchPg.selectItemFromFilter("Interest", "Cardio");
		util.clickElement(clsSchPg.geBtnAddScheduleToFav());
		String name1 = "Cardio";
		util.enterText(clsSchPg.getInInputext(), name1);
		util.clickElement(clsSchPg.getBtnAdd());
		util.isTextPresent(clsSchPg.getTextContainer(), Constants.SuccessMessage);

		//edit with the  same fav filter name added
		util.clickElement(clsSchPg.getBtnEditFav());
		clsSchPg.getInputEdit().clear();
		String editedName1 = "Cardio";
		util.enterText(clsSchPg.getInputEdit(), editedName1);
		Assert.assertTrue(util.isTextPresent(clsSchPg.getTxtErrMsgSameFavName(), Constants.sameNameErrMsg));//verify error message

		//cancel and delete
		util.clickElement(clsSchPg.getBtnCancel());
		util.clickElement(clsSchPg.getBtnDeletFav());
		util.clickElement(clsSchPg.getBtnDelFav());                 


	}


	/**
	 * Description : To verify the filter dropdowns, help Link ,Studio in Dropdowns and
	 *  Verify tabnavigation for Classes & Facilities
	 */


	@Test
	public void test_tier1_VerifyFilterDropdownsAndHelpLink() {
		ProgramsPage prgPg = new ProgramsPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/st-louis-park.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		//login
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));		
		util.verifyPageTitle("St. Louis Park");	

		homPg.navigateToClassSchPage(); // Navigate to Class Schedule page from member page
		util.verifyPageTitle(Constants.ClassesStLouisPark); // Verifying the page title
		util.clickElement(clsSchPg.getBtnFilters()); // Clicking on the Filter button, it will get expand
		util.wait(5);

		//verify dropdowns
		clsSchPg.verifyDropdowns();

		//verify selecting multiple filters from dropdown
		clsSchPg.selectItemFromFilter("Interest", "Yoga");
		clsSchPg.selectItemFromFilter("Interest", "Cardio");

		//verify classes and facilities tab
		Assert.assertTrue(util.isElementPresent(clsSchPg.getLnkClasses()));
		Assert.assertTrue(util.isElementPresent(clsSchPg.getLnkFacilities()));

		//click link facilities
		util.clickElement(clsSchPg.getLnkFacilities());
		util.verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);

		// Navigate to programs and select a court
		homPg.navigateToPrograms("Racquetball"); 
		util.verifyPageTitle("Racquetball"); // Verifying the page title

		//click button reserve a court
		util.clickElement(prgPg.getReserveACourtButton());
		util.verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);

		//click link classes
		util.clickElement(clsSchPg.getLnkClasses());
		util.verifyPageTitle(Constants.ClassesStLouisPark);

		//verify filter studio
		util.clickElement(clsSchPg.getBtnFilters()); // Clicking on the Filter button, it will get expand
		clsSchPg.selectItemFromFilter("Interest", "Studio");
		clsSchPg.selectAvailableClass("St. Louis Park");
		util.verifyPageTitle(Constants.CLASS_DETAILS_PAGE_TITLE);

		//navigate back to class schedules 
		homPg.navigateToClassSchPage(); 
		util.verifyPageTitle(Constants.ClassesStLouisPark); // Verifying the page title

		//verify help link		
		Assert.assertTrue(util.isElementPresent(clsSchPg.getLnkHelp()));
		util.clickElement(clsSchPg.getLnkHelp());
		util.verifyPageTitle(Constants.HELP_FAQ_PAGE_TITLE);



	}	
	/**
	 * Description : To verify the Error messsage on removing the LocationChiclet
	 * and to verify the same error message on unchecking the location from AddClubLocation Dropdown
	 *  
	 */


	@Test
	public void test_tier1_VerifyRemoveLocationErrorMessage() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		//login
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));		
		util.verifyPageTitle("Chanhassen");	

		homPg.navigateToClassSchPage(); // Navigate to Class Schedule page from member page
		util.verifyPageTitle(Constants.PageTitleChanhassen); // Verifying the page title

		//click chiclet Remove Location
		util.clickElement(clsSchPg.getchicletLoc());
		util.wait(5);
		//verify Error message
		Assert.assertTrue(util.isTextPresent(clsSchPg.getErrMsgRemoveLoc(), Constants.RemoveLocErrMsg));
		util.clickElement(clsSchPg.getbtnYesPopupRemoveLoc());//click yes button
		//verify No location ErrorMessage
		Assert.assertTrue(util.isTextPresent(clsSchPg.getErrMsgNoLoc(), Constants.NoLocErrMsg));

		homPg.navigateToClassSchPage(); // Navigate to Class Schedule page from member page
		util.verifyPageTitle(Constants.PageTitleChanhassen); // Verifying the page title

		util.clickElement(clsSchPg.getBtnFilters()); // Clicking on the Filter button, it will get expand
		util.clickElement(clsSchPg.getDrpdwnAddClubLoc());
		String clubName = "Chanhassen";
		By locationCheckBox = By.xpath("(//span[text()='"+clubName+"']/preceding-sibling::input)[1]");
		util.clickElement(locationCheckBox);
		util.wait(10);

		//verify ErrorMsg when unchecking the location from dropdown
		Assert.assertTrue(util.isTextPresent(clsSchPg.getErrMsgRemoveLocChkBox(), Constants.RemoveLocErrMsg));
		util.clickElement(clsSchPg.getbtnYesPopupRemoveLocChkBox());
		//verify No location ErrorMessage
		Assert.assertTrue(util.isTextPresent(clsSchPg.getErrMsgNoLoc(), Constants.NoLocErrMsg));

	}
	/**
	 * Description : To verify the Links are suppressed in classSchedule when User should be in Prospect site - lifetime locations
	 *  
	 */

	@Test
	public void test_tier1_VerifyTheListOfLinksAreSuppressed() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.lifetime.life/life-time-locations/mn-chanhassen.html?");

		util.wait(5);
		util.clickElement(clsSchPg.getBtnFilters()); // Clicking on the Filter button, it will get expand
		//verify the links are suppressed
	//	clsSchPg.verifyLinksAreSupppressed();
		Assert.assertTrue(util.isTextPresent(clsSchPg.gethdrClassSchedules(), Constants.hdrClassSchedules));
		Assert.assertFalse(util.isElementPresent(clsSchPg.getBtnShowOrHideFav()));
		Assert.assertFalse(util.isElementPresent(clsSchPg.getLnkHelp()));
		Assert.assertFalse(util.isElementPresent(clsSchPg.getbtnPrintWeek()));
		Assert.assertFalse(util.isElementPresent(clsSchPg.getAddFav())); 



	}
}

