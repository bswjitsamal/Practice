package net.lt.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

public class LTWorkTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	/**
	 * Description : To validate the ability to perform Platinum Reservation Created
	 * By : Saravanan Ravichandran Created Date : Feb 12th 2018 Modified By :
	 * Modified Date : Preconditions :
	 */

	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;

	PendingReservationPage pResvPg;
	ProgramsPage programsPg;


	@Before
	public void apiSetup() {

		// RestAssured.baseURI =
		// "https://api.lifetimefitness.com/qa/edge/api/"+Constants.apiResourceId+"&size=100";
		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";		

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
		programsPg = new ProgramsPage(driver);

	}
	
	



	@Test
	public void test_tier3_LTWorkVerifyConferenceRoomReservationRule() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));
		util.waitAndClickElement(myResvPg.getLnkReservationRules());
		util.isElementPresent(myResvPg.HideReservationRules().getText());
		Assert.assertTrue(util.isTextPresent(myResvPg.TextMsg(), Constants.RESERVATION_RULES_MSG));
	}

}


