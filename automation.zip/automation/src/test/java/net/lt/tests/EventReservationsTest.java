package net.lt.tests;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.SQLUtility;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.BookingPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.EventPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.ReservationsPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ReservationConfirmationPage;

public class EventReservationsTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	@Before
	public void apiSetup() {

		// RestAssured.baseURI =
		// "https://api.lifetimefitness.com/qa/edge/api/"+Constants.apiResourceId+"&size=100";
		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

	}

	@Test
	public void test_tier1_searchFilterAndReserveEvent() throws SQLException {

		

		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		DetailsPage detlPg = new DetailsPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);
		HomePage homPg = new HomePage(driver);
		PendingReservationPage PResvPg = new PendingReservationPage(driver);
		// ReservationConfirmationPage resvConfPg = new
		// ReservationConfirmationPage(driver);
		BookingPage bookingPg = new BookingPage(driver);
		SQLUtility sqlUtil = new SQLUtility();
		int reservation = 0;

		// creates the event and gets the reservationid
		reservation = sqlUtil.createEventData("701592708281", "2019-05-25 17:00:00", "2021-05-25 18:00:00", "25.00",
				"Spooktacular", "206", "4012", "GYM 1", "Spooktacular", "4541");

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.memberemployee.user"),
				envProperties.getProperty("login.memberemployee.password"));

		String externalId = envProperties.getProperty("login.member.memberid");

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		util.verifyPageTitle(Constants.EventsKingwood);

		evntPg.selectDatefromMultiDate(1);

		util.waitAndClickElement(evntPg.getSpooktacularFree());

		util.verifyPageTitle(Constants.eventDetailsKingWood);

		util.waitAndClickElement(detlPg.getBtnReserve());
		util.waitAndClickElement(bookingPg.getSelectParticipant());
		util.waitAndClickElement(bookingPg.getBtnNext());

		PResvPg.confirmReservation();

		myResvPg.verifyFitMetrixReservation(externalId, Auth, "Spooktacular");

		sqlUtil.deleteEventData(reservation);

		

	}

	@Test
	public void test_tier1_ReserveaButtonAvailableForFutureEventsNotForPast() {



		// LOGGER.info("Starting test " + method.getName() + "... ");
		HomePage homPg = new HomePage(driver);
		EventPage evntPg = new EventPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.eventmember.user"),
				envProperties.getProperty("login.eventmember.password"));

		homPg.searchLocation("Kingwood TX");
		util.verifyPageTitle(Constants.Kingwood);

		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());
		util.verifyPageTitle(Constants.EventsKingwood);

		util.waitAndClickElement(evntPg.getBtnFirstEventOnScreen());
		util.verifyPageTitle(Constants.eventDetailsKingWood);

		/**
		 * Verify the presence of reserve button for todays event
		 */
		util.isElementPresent("Reserve");
		util.waitAndClickElement(homPg.getLnkEvent());
		util.waitAndClickElement(homPg.getLnkAllEvent());

		evntPg.selectDatefromMultiDate(1);

		util.waitAndClickElement(evntPg.getDoWhatMovesYou());
		util.verifyPageTitle(Constants.eventDetailsKingWood);

		util.isElementPresent("Reserve");

		
	}

}
