package net.lt.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationConfirmationPage;
import net.lt.pages.ReservationsPage;

public class CourtReservationsTest extends TestBase {
	RequestSpecification basicAuth, Auth;
	String SSOID;

	LoginPage lgnPg;
	Utility util;
	HomePage homPg;
	ProgramsPage progPg;
	PendingReservationPage pResvPg;
	ReservationsPage resvPg;

	@Before
	public void apiSetup() {

		lgnPg = new LoginPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		progPg = new ProgramsPage(driver);
		pResvPg = new PendingReservationPage(driver);
		resvPg = new ReservationsPage(driver);	

		RestAssured.baseURI = "https://api.lifetimefitness.com/qa";
		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Ocp-Apim-Subscription-Key", "2e77f50f231e4647b3339a5494470361");
		Auth.contentType(ContentType.JSON);

	}
	/**
	 * Method to reserve a court
	 * @param clubLocation
	 * @param courtToBeReserved
	 */
	public void reserveACourt(String clubLocation, String courtToBeReserved, int noOfDaysFromCurrentDay)
	{
		homPg.searchLocation(clubLocation);
		// homPg.selectLocation("St. Louis Park");
		util.verifyPageTitle((clubLocation.split(" "))[0]);		

		homPg.navigateToPrograms(courtToBeReserved); // Navigate to Class Schedule page from member page
		// mbrPg.navigateToProgramPage("Yoga");
		util.verifyPageTitle(courtToBeReserved); // Verifying the page title

		progPg.reserveACourt(courtToBeReserved, noOfDaysFromCurrentDay); // Reserve a court		
	}

	@Test
	public void test_tier1_TennisCourtReservation() throws InterruptedException {

		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		resvPg.deleteReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		reserveACourt("Centennial Tennis onyx", "Tennis", 1);

		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Tennis");

		resvPg.validateCourtReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);
		resvPg.deleteReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);

	}

	/*@Test
	public void test_tier1_PickleballReservation() throws InterruptedException {

		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		HomePage homPg = new HomePage(driver);
		ProgramsPage progPg = new ProgramsPage(driver);
		PendingReservationPage pResvPg = new PendingReservationPage(driver);
		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		myResvPg.deleteReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);

		
		homPg.searchLocation("Plymouth, MN, USA");
		util.verifyPageTitle(Constants.plymouth);

		homPg.underProgramsNavigateTo("Pickleball"); // Navigate to Class Schedule page from member page
		util.verifyPageTitle(Constants.PickleBall_Plymouth); // Verifying the page title

		progPg.reserveACourt("PickleBall"); // Reserve a court
		util.verifyPageTitle(Constants.CourtReservations);

		System.out.println("The timer lies in between the range is : " + util.isBetween(pResvPg.timerStart(), 0, 15));
		pResvPg.confirmReservation();
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		myResvPg.validateCourtReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);
		myResvPg.deleteReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);
		// myResvPg.verifyConfirmationAndCancellationReservation("Tennis");

	}
*/
	
	@Test
	public void test_tier1_SquashCourtReservation() throws InterruptedException {


		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.squashcourt.user"),
				envProperties.getProperty("login.squashcourt.password"));
		resvPg.deleteReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.squashcourt.user"), envProperties.getProperty("login.squashcourt.password"));

		reserveACourt("Parker-Aurora", "Squash", 1);

		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Squash");

		resvPg.validateCourtReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);
		resvPg.deleteReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);
	}


	@Test
	public void test_tier1_RacquetballCourtReservation() throws InterruptedException {

		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.racquetball.user"),
				envProperties.getProperty("login.racquetball.password"));
		resvPg.deleteReservations(Auth, "Racquetball",
				Integer.parseInt(envProperties.getProperty("login.racquetball.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.racquetball.user"), envProperties.getProperty("login.racquetball.password"));

		reserveACourt("Bloomington, MN", "Racquetball", 1);

		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Racquetball");

		resvPg.validateCourtReservations(Auth, "Racquetball",
				Integer.parseInt(envProperties.getProperty("login.racquetball.memberid")), SSOID);
		resvPg.deleteReservations(Auth, "Racquetball",
				Integer.parseInt(envProperties.getProperty("login.racquetball.memberid")), SSOID);	

	}

	@Test
	public void test_tier1_verifySquashReservationAllowedOnlyOncePerDay() throws InterruptedException {

		String className = "Squash";
		
		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.squashcourt.user"),
				envProperties.getProperty("login.squashcourt.password"));
		resvPg.deleteReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.squashcourt.user"), envProperties.getProperty("login.squashcourt.password"));

		reserveACourt("Parker-Aurora", "Squash", 1);

		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Squash");
		resvPg.verifyAddToCalendar(capabilities , className);		

		reserveACourt("Parker-Aurora", "Squash", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.SQUASH_RESREVATION_ALLOWED_PER_DAY_MSG));
		
		resvPg.deleteReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);
		
	}
	
	
	@Test
    public void test_tier1_verifySquashCourtReservationAsUnauthenticated() throws InterruptedException 
	{

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		
		reserveACourt("Parker-Aurora", "Squash", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.UNAUTHENTICATED_MSG));

    }
	
	
	@Test
    public void test_tier1_verifySquashCourtReservationOutOfMembershipLevel() throws InterruptedException 
	{

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.squashcourt.user"), envProperties.getProperty("login.squashcourt.password"));

		reserveACourt("St. Louis Park", "Squash", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.OUTSIDE_OF_MEMBERSHIP_LEVEL));

    }

	//RACQUET BALL
	
	@Test
	public void test_tier1_verifyRacquetballReservationAllowedOnlyOncePerDay() throws InterruptedException {

		String className = "Racquetball";
		
		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.racquetball.user"),
				envProperties.getProperty("login.racquetball.password"));
		resvPg.deleteReservations(Auth, "Racquetball",
				Integer.parseInt(envProperties.getProperty("login.racquetball.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.racquetball.user"), envProperties.getProperty("login.racquetball.password"));

		reserveACourt("Bloomington, MN", "Racquetball", 1);

		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Racquetball");
		//resvPg.verifyAddToCalendar(capabilities , className);

		reserveACourt("Bloomington, MN", "Racquetball", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.RACQUETBALL_RESREVATION_ALLOWED_PER_DAY_MSG));
		
		resvPg.deleteReservations(Auth, "Racquetball",
				Integer.parseInt(envProperties.getProperty("login.racquetball.memberid")), SSOID);
		
	}
	@Test
    public void test_tier1_verifyRacquetballCourtReservationAsUnauthenticated() throws InterruptedException 
	{

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		
		reserveACourt("Parker-Aurora", "Racquetball", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.UNAUTHENTICATED_MSG));

    }
	
	@Test
    public void test_tier1_verifyRacquetballCourtReservationOutOfMembershipLevel() throws InterruptedException 
	{

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.racquetball.user"), envProperties.getProperty("login.racquetball.password"));

		reserveACourt("Parker-Aurora", "Racquetball", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.OUTSIDE_OF_MEMBERSHIP_LEVEL));

    }
	
	//Tennis	
	
	@Test
    public void test_tier1_verifyTennisCourtReservationOutOfMembershipLevel() throws InterruptedException 
	{

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.tenniscourt.user"), envProperties.getProperty("login.tenniscourt.password"));

		reserveACourt("Eden Prairie Athletic", "Tennis", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.OUTSIDE_OF_MEMBERSHIP_LEVEL));

    }
	
	@Test
    public void test_tier1_verifyTennisCourtReservationAsUnauthenticated() throws InterruptedException 
	{

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		
		reserveACourt("Centennial Tennis onyx", "Tennis", 1);
		
		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.UNAUTHENTICATED_MSG));

}
	@Test
	public void test_tier1_verifyTennisReservationAllowMultiplePerDay() throws InterruptedException {

		String className = "Tennis";
		
		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		resvPg.deleteReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		reserveACourt("Centennial Tennis onyx", "Tennis", 1);

		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Tennis");
		resvPg.verifyAddToCalendar(capabilities , className);

		reserveACourt("Centennial Tennis onyx", "Tennis", 1);
		pResvPg.confirmReservation();	

		resvPg.verifyCourtReservationInUI("Tennis");
		
		//Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.RACQUETBALL_RESREVATION_ALLOWED_PER_DAY_MSG));
		
		resvPg.deleteReservations(Auth, "Tennis",
				Integer.parseInt(envProperties.getProperty("login.member.memberid")), SSOID);
		
	}
	
	
	
}
