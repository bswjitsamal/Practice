package net.lt.tests;


import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

public class HomePageTest extends TestBase {
	RequestSpecification basicAuth, Auth;
	String SSOID;
	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ProgramsPage progPg; //= new ProgramsPage(driver);
	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;

	PendingReservationPage pResvPg;

	@Before
	public void apiSetup() {


		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";	

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);

	}

	/**
	 * Method to reserve a court
	 * @param clubLocation
	 * @param courtToBeReserved
	 */
	public void reserveACourt(String clubLocation, String courtToBeReserved, int noOfDaysFromCurrentDay)
	{
		ProgramsPage progPg = new ProgramsPage(driver);
		homPg.searchLocation(clubLocation);
		// homPg.selectLocation("St. Louis Park");
		util.verifyPageTitle((clubLocation.split(" "))[0]);		

		homPg.navigateToPrograms(courtToBeReserved); // Navigate to Class Schedule page from member page
		// mbrPg.navigateToProgramPage("Yoga");
		util.verifyPageTitle(courtToBeReserved); // Verifying the page title

		progPg.reserveACourt(courtToBeReserved, noOfDaysFromCurrentDay); // Reserve a court		
	}

	/**
	 * 
	 * Home Page listing reserved class sched functionality
	 * 
	 */
	
	@Test
	public void test_tier1_verifyUpcomingReservations() {

		HomePage homPg = new HomePage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
		ReservationsPage myResvPg = new ReservationsPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));
		homPg.searchLocation("St. Louis Park");		
		util.verifyPageTitle("St. Louis Park");

		util.waitUntilJavaScriptLoads();
		ArrayList<String> homeVaue = homPg.getTextValuesUpComingReservations();

		if (homeVaue.size() == 0) {
			System.out.println("The text is visible: " + homPg.getPYouHaveNoUpComingReservations().getText());

		} else {

			util.clickElement(homPg.getLnkReservation()); // Navigate to Class Schedule page from member page
			util.verifyPageTitle(Constants.Reservations); // Verifying the page title

			ArrayList<String> myResvList = myResvPg.getTextValues();

			util.compareArrayOfText(myResvList, homeVaue);

		}

	}


	@Test
	public void test_tier1_CreateFavoritesAndVerifySavedSearches() 
	{	

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		//login
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));		
		util.verifyPageTitle("Chanhassen");		
		//click on Add a Favorite link
		util.clickElement(homPg.LinkAddaFavorite());
		util.verifyPageTitle(Constants.Classes);
		util.clickElement(clsSchPg.getBtnShowOrHideFav());
		Assert.assertTrue(util.isTextPresent(clsSchPg.alertMsgNoFavSched(), Constants.YOU_HAVE_N0_FAV_MSG));
		//Add Favorites
		clsSchPg.addFavourites();
		//Navigate back to Home Page
		util.wait(5);
		util.clickElement(clsSchPg.getlifetimelogo());
		util.clickElement(homPg.LinkFavoriteName());
		util.verifyPageTitle(Constants.Classes);
		//verify added favorites in the Home Page
		util.isElementPresent(clsSchPg.FavName().getText());
		//Delete all favorites
		clsSchPg.deleteAllFavourites();
		util.clickElement(clsSchPg.getlifetimelogo());
		Assert.assertTrue(util.isTextPresent(homPg.gettextNoFavClassSched(), Constants.NO_FAVORITES_MSG));

	}

	@Test
	public void test_tier1_verifyYogaClassReservationInHomePage() {

		String className = "Ashtanga Vinyasa";
		String externalId = envProperties.getProperty("login.member.memberid"); // Cancel all available fitmetrix
		// reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Yoga", "Ashtanga Vinyasa");
		clsSchPg.selectAvailableClass("Chanhassen");
		detlPg.reserveClass();
		util.clickElement(detlPg.getLnkClassSchedules());
		//util.verifyPageTitle(Constants.Classes);
		util.clickElement(clsSchPg.getlifetimelogo());
		
//		util.wait(50);
//		util.browserRefresh(2);
//		util.wait(50);
		util.verifyPageTitle("Chanhassen");
//		driver.navigate().refresh();
		util.wait(5);
		driver.get("https://qa-my.lifetime.life/clubs/mn/chanhassen.html");
		util.verifyPageTitle("Chanhassen");
		util.clickElement(clsSchPg.getlifetimelogo());
		util.verifyPageTitle("Chanhassen");
		
		
		By classNameXpath = By.xpath("//div[@class='schedules-component-container']//a[text()='"+className+"']");
		
		util.waitForElementsToBeVisible(classNameXpath);
		Assert.assertTrue(util.isElementPresent(classNameXpath));
		util.clickElement(classNameXpath);		
		myResvPg.verifyAddToCalendar(capabilities , className);


		myResvPg.verifyFitMetrixReservation(externalId, Auth, "Ashtanga Vinyasa");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

	}


	@Test
	public void test_tier1_verifyEdgeCycleClassReservationInHomePage() {


		String className = "EDG Cycle";

		String externalId = envProperties.getProperty("login.member.memberid");

		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cycling", "EDG Cycle");
		clsSchPg.selectAvailableClass("Chanhassen");
		detlPg.reserveClass();
		util.clickElement(detlPg.getLnkClassSchedules());
		util.verifyPageTitle(Constants.Classes);
		util.clickElement(clsSchPg.getlifetimelogo());
		By classNameXpath = By.xpath("//div[@class='schedules-component-container']//a[text()='"+className+"']");
		Assert.assertTrue(util.isElementPresent(classNameXpath));
		util.clickElement(classNameXpath);	
		//myResvPg.verifyAddToCalendar(capabilities , className);


		myResvPg.verifyFitMetrixReservation(externalId, Auth, "EDG Cycle");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

	}
	@Test
	public void test_tier1_verifyCourtReservationInHomePage() {

		RestAssured.baseURI = "https://api.lifetimefitness.com/qa";
		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Ocp-Apim-Subscription-Key", "2e77f50f231e4647b3339a5494470361");
		Auth.contentType(ContentType.JSON);

		String className = "Squash";

		SSOID = util.getSSOId(Auth, envProperties.getProperty("login.squashcourt.user"),
				envProperties.getProperty("login.squashcourt.password"));
		myResvPg.deleteReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.squashcourt.user"), envProperties.getProperty("login.squashcourt.password"));

		reserveACourt("Parker-Aurora", "Squash", 1);

		pResvPg.confirmReservation();	

		myResvPg.verifyCourtReservationInUI("Squash");	
		util.clickElement(clsSchPg.getlifetimelogo());
		homPg.searchLocation("Chanhassen");	
		By classNameXpath = By.xpath("//div[@class='schedules-component-container']//a[contains(text(),'"+className+"')]");
		Assert.assertTrue(util.isElementPresent(classNameXpath));
		util.clickElement(classNameXpath);		
		myResvPg.verifyAddToCalendar(capabilities , className);


		myResvPg.validateCourtReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);
		myResvPg.deleteReservations(Auth, "Squash",
				Integer.parseInt(envProperties.getProperty("login.squashcourt.memberid")), SSOID);	




	}

	@Test
	public void test_tier3_verifyViewDropdownAsPerMembershipLevel() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));

		List<String> Locations = new ArrayList<String>();
		Locations.add("Chanhassen");
		Locations.add("Apple Valley, MN, USA");
		Locations.add("Lakeville , MN, USA");
		Locations.add("Eden Prairie athletic");

		for( String location : Locations)
		{
			homPg.searchLocation(location);			
			util.verifyPageTitle((location.split(" "))[0]);

			if (location == "Chanhassen") {
				Assert.assertTrue(util.isTextPresent(homPg.MembershipLevel(), Constants.Chnhsn));
			}
			else if (location == "AppleValley, MN, USA") {
				Assert.assertTrue(util.isTextPresent(homPg.MembershipLevel(), Constants.AppleValley));
			}
			else if (location == "LakeVille, MN, USA") {
				Assert.assertTrue(util.isTextPresent(homPg.MembershipLevel(), Constants.LakesVille));
			}
			else if (location == "Eden Prairie athletic") {
				Assert.assertTrue(util.isTextPresent(homPg.MembershipLevel(), Constants.EdenPrairieAthletic));
			}

		}


	}

	//	@Test
	//	public void test_tier3_validatingTheHomepageComponents() {
	//
	//		HomePage homPg = new HomePage(driver);
	//		ClassSchedulesPage clsSchPg = new ClassSchedulesPage(driver);
	//		LoginPage lgnPg = new LoginPage(driver);
	//		Utility util = new Utility(driver);
	//
	//
	//		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
	//		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));
	//
	//
	//		homPg.selectLocation("Chanhassen");
	//		util.verifyPageTitle(Constants.Chanhassen);
	//		homPg.verifyHomePageComponentsBrief();
	//
	//	}





}




