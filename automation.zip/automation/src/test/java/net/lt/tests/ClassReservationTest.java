package net.lt.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.BookabilityPage;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ReservationConfirmationPage;
import net.lt.pages.ReservationsPage;

public class ClassReservationTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	/**
	 * Description : To validate the ability to perform Platinum Reservation Created
	 * By : Saravanan Ravichandran Created Date : Feb 12th 2018 Modified By :
	 * Modified Date : Preconditions :
	 */

	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;

	PendingReservationPage pResvPg;
	BookabilityPage bookabilityPg;
	ReservationConfirmationPage resvConfPg ;

	@Before
	public void apiSetup() {

		// RestAssured.baseURI =
		// "https://api.lifetimefitness.com/qa/edge/api/"+Constants.apiResourceId+"&size=100";
		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";		

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
		bookabilityPg = new BookabilityPage(driver);
		resvConfPg =  new ReservationConfirmationPage(driver);
	}



	/**
	 * Authenticated user trying to register for a class
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void test_tier1_ReserveEdgeCycleClassAuth() throws InterruptedException {

		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Cycling", "EDG Cycle");
		clsSchPg.selectAvailableClass("St. Louis Park");
		detlPg.reserveClass();

		myResvPg.verifyFitMetrixReservation(externalId, Auth, "EDG Cycle");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
	}


	/**
	 * UnAuthenticated user trying to register for a class
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void test_tier1_ReserveCycleClassUnAuth() throws InterruptedException {

		String externalId = envProperties.getProperty("login.member.memberid"); // Cancel all available fitmetrix
		// reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cycling", "EDG Cycle");
		clsSchPg.selectAvailableClass("Chanhassen");		
		detlPg.reserveClass();

		// Verify through API whether the reservation is done successfully
		myResvPg.verifyFitMetrixReservation(externalId, Auth, "EDG Cycle");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
	}

	/**
	 * Authenticated user trying to register for a yoga class
	 * 
	 * @throws InterruptedException
	 */

	@Test
	public void test_tier1_ReserveYogaAuth() throws InterruptedException {

		String externalId = envProperties.getProperty("login.member.memberid"); // Cancel all available fitmetrix
		// reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));

		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Yoga", "BE");
		clsSchPg.selectAvailableClass("St. Louis Park");
		detlPg.reserveClass();


		myResvPg.verifyFitMetrixReservation(externalId, Auth, "BE");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

	}


	/**
	 * Authenticated user trying to register for a pilates class
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void test_tier1_member30DayWindowforPilates() throws InterruptedException {


		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Crosstown (Eden Prairie)", "Pilates", "Discover Pilates");

		clsSchPg.selectAvailableClass("Crosstown (Eden Prairie)");
		detlPg.reserveClass();
		util.clickElement(fmPg.getBtnMyReservations()); // navigate to My Reservation page, it it will listed all
		// the reservation.
		util.verifyPageTitle(Constants.Reservations);		

		// Verify through API whether the reservation is done successfully
		myResvPg.verifyFitMetrixReservation(externalId, Auth, "Discover Pilates");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

	}


	/**
	 * Cancel the class reserved
	 * 
	 * @throws InterruptedException
	 */

	@Test
	public void test_tier1_veriyAbilityToCancelGreaterOrLessThen24Hr() throws Exception {

		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Yoga", "BE");
		clsSchPg.selectAvailableClass("St. Louis Park");
		detlPg.reserveClass();	
		util.clickElement(fmPg.getBtnAddToCalendar());
		util.clickElement(fmPg.getBtnAddToOutLookCalendar());

		util.clickElement(myResvPg.getBtnMyReservations()); // navigate to My Reservation page, it it will listed
		// all the reservation.
		util.verifyPageTitle(Constants.Reservations);

		myResvPg.verifyCancelButtonPresentIfLessThen24Hr("Cancel");

		myResvPg.verifyFitMetrixReservation(externalId, Auth, "BE");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);	



	}

	/**
	 * verifying Discover pilates registration
	 * 
	 * @throws InterruptedException
	 */

	@Test
	public void test_tier1_memberVerifyDiscoverPilatesRegistration() throws InterruptedException {
		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Crosstown (Eden Prairie)", "Pilates", "Discover Pilates");
		clsSchPg.selectAvailableClass("Crosstown (Eden Prairie)");
		detlPg.reserveClass();		

		util.clickElement(fmPg.getBtnAddToCalendar());
		util.clickElement(fmPg.getBtnAddToOutLookCalendar());

		util.clickElement(myResvPg.getBtnMyReservations()); // navigate to My Reservation page, it it will listed
		// all the reservation.
		util.verifyPageTitle(Constants.Reservations);
		myResvPg.verifyCancelButtonPresentIfLessThen24Hr("Cancel");

		myResvPg.verifyFitMetrixReservation(externalId, Auth, "Discover Pilates");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);		

	}


	/**
	 * Verify add reservations to calendar for yoga class
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void test_tier1_memberAddReservationstoCalendarforYogaclass() throws Exception {


		String className = "BE";
		// Deleting the existing .ics files
		if (capabilities.getCapability("deviceName") == null) {
			util.deleteCalendarDownloads(capabilities, className); 
		}
		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Yoga", "BE");
		clsSchPg.selectAvailableClass("St. Louis Park");
		detlPg.reserveClass();	
		// Clicking on add to calendar link on home page

		util.clickElement(fmPg.getBtnAddToCalendar());
		util.clickElement(fmPg.getBtnAddToOutLookCalendar());

		//myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		if (capabilities.getCapability("deviceName") == null) {
			util.validateAddToCalendar(capabilities, className);
		}

		myResvPg.verifyFitMetrixReservation(externalId, Auth, "BE");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

	}


	/**
	 *  user trying to register for Kids Academy
	 * 
	 * @throws InterruptedException
	 */

	@Test
	public void test_tier1_memberRegistrationKidsAcademy() throws Exception {

		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Kids Academy", "Dance");
		clsSchPg.selectAvailableClass("Chanhassen");
		detlPg.reserveClass();


		//User redirects to Pendign reservation page
		pResvPg.selectCheckBoxParticipants();
		pResvPg.confirmReservation();

		util.verifyPageTitle(Constants.Reservations);
		// Verify through API whether the reservation is done successfully
		myResvPg.verifyFitMetrixReservation(externalId, Auth, "Dance");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

	}	


	/**
	 * Test to verify the pick a spot editing
	 * @throws Exception
	 */
	@Test
	public void test_tier1_veriyEditReservations() throws Exception {
		
		String externalId = envProperties.getProperty("login.member.memberid2");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user2"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cycling", "EDG Cycle (Pick a Spot)");
		clsSchPg.navigateToNextWeekandClick();	
		detlPg.reservePickSpotClass();
		util.isElementPresent("Spot ");
		util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
		ReservationsPage resvePg = new ReservationsPage(driver);

		String initialSpot_Value = resvePg.getTxtSpot().getText();
		util.browserRefresh(1);

		myResvPg.verifyEditPickaSpotReservation("EDG Cycle (Pick a Spot)");
		String updatedSpot_Value = resvePg.getTxtSpot().getText();

		Assert.assertFalse(initialSpot_Value.equals(updatedSpot_Value));
		myResvPg.verifyFitMetrixReservation(externalId, Auth, "EDG Cycle (Pick a Spot)");
		// Cancel all fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);}
}


