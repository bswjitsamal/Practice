package net.lt.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.BookabilityPage;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

/**
 * This class contains all the test that validates the functionality in class details page
 * @author e9002137
 *
 */
public class ClassDetailsTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	/**
	 * Description : To validate the ability to perform Platinum Reservation Created
	 * By : Saravanan Ravichandran Created Date : Feb 12th 2018 Modified By :
	 * Modified Date : Preconditions :
	 */

	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;
	ProgramsPage progPg;
	PendingReservationPage pResvPg;
	BookabilityPage bookabilityPg;


	@Before
	public void apiSetup() {

		// RestAssured.baseURI =
		// "https://api.lifetimefitness.com/qa/edge/api/"+Constants.apiResourceId+"&size=100";
		RestAssured.baseURI = "https://qaapi.fitmetrix.io/api";		

		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Authorization", "Basic OUJGRDdDNTA0NEI3NDcyNkFFREY4NEYzRTcwODQ0MDA6Mzg2Nzgz");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
		bookabilityPg = new BookabilityPage(driver);
		progPg = new ProgramsPage(driver);

	}


	/**
	 * Test to verify Favorites
	 * @throws InterruptedException
	 */

	@Test
	public void test_tier1_FavoritesUnAuth() throws InterruptedException 
	{
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Pilates", "Pilates 1");
		clsSchPg.verifyFavourites();
	}

	/**
	 * Test to verifystart and end date filters
	 * @throws Exception
	 */
	@Test
	public void test_tier1_memberVerifyStartAndEndDateFilters() throws Exception {


		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Yoga", "Ashtanga Vinyasa");


	}

	/**
	 * Test to verify order of filters
	 * @throws Exception
	 */
	@Test
	public void test_tier1_memberVerifyFiltersOrdering() throws Exception {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Yoga", "Ashtanga Vinyasa");	
		List<String> expFilterList = new ArrayList<String>();
		expFilterList.add("Interest");
		expFilterList.add("Class Name");
		expFilterList.add("Time of Day");
		expFilterList.add("Age");
		expFilterList.add("Skill Level");
		expFilterList.add("Intensity");
		expFilterList.add("Instructor");
		expFilterList.add("Add Club Location");

		// to catch all web elements into list
		List<WebElement> myList = clsSchPg.getFilterItem();
		List<String> all_elements_text = new ArrayList<>();

		for (int i = 0; i < myList.size(); i++) {

			// loading text of each element in to array all_elements_text
			all_elements_text.add(myList.get(i).getText());

			// to print directly
			System.out.println(myList.get(i).getText());

		}
		Assert.assertTrue(all_elements_text.equals(expFilterList));
	}


	/**
	 * Test to verify the next occurances
	 * @throws Exception
	 */
	@Test
	public void test_tier1_memberVerifyNextOccurances() throws Exception {


		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Kids Academy", "Mountain Stars - Beginner");	
		clsSchPg.selectAvailableClass("Chanhassen");

		//Verify uppon clikcing on the more items, it should redrirect to another details page.
		List<WebElement> myList = detlPg.getViewRelatedItems();
		List<String> all_elements_text = new ArrayList<>();

		for (int i = 0; i < myList.size(); i++) {
			// loading text of each element in to array all_elements_text
			all_elements_text.add(myList.get(i).getText());
			// to print directly
			System.out.println(myList.get(i).getText());
		}

		//Clicking on any of the related items and it should redirect to details page
		detlPg.clickOnAnyRelatedItems();	
		util.verifyPageTitle(Constants.PageTitleClassDetailClassChanhassen);

	}

	/**
	 * Test to verify the add to calendar information
	 * @throws Exception
	 */
	@Test
	public void test_tier1_veriyAddToCalendarInformation() throws Exception 
	{

		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Yoga", "BE");
		clsSchPg.selectAvailableClass("St. Louis Park");

		util.clickElement(detlPg.getbtnAddToCalendar());
		util.clickElement(fmPg.getBtnAddToOutLookCalendar());

		if (capabilities.getCapability("deviceName") == null) {
			util.validateAddToCalendar(capabilities, "BE");
		}


	}


	/**
	 * Test to verify the registration copy
	 * @throws Exception
	 */
	@Test
	public void test_tier1_memberVerifyRegistrationCopy() throws Exception {


		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cycling", "EDG Cycle");	
		clsSchPg.selectAvailableClass("Chanhassen");
		//Verify text display on screen under registration
		//Verifying for Registration Required 
		Assert.assertTrue(detlPg.getViewRegistrationRecommended().getText().equals("Registration Recommended"));
		// Clicking on the Filter button, it will get expand
		driver.navigate().back();
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Weight Loss", "GTX Burn");	
		clsSchPg.selectAvailableClass("Chanhassen");

		//Verify text display on screen under registration
		Assert.assertTrue(detlPg.getViewRegistrationRecommended().getText().equals("Registration Required"));

	}


	/**
	 * Test to verify the add to calendar in class details page
	 * @throws Exception
	 */
	@Test
	public void test_tier1_verifyAddToCalendarButtonOnClassDetails() throws Exception {

		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Yoga", "BE");	
		clsSchPg.selectAvailableClass("St. Louis Park");
		Assert.assertTrue(util.isElementPresent(detlPg.getbtnAddToCalendar()));	

	}


	/**
	 * Test to verify invalid filters
	 * @throws Exception
	 */
	@Test
	public void test_tier1_verifyNotAllowInvalidFilters() throws Exception {

		// Utility util = new Utility(driver);
		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("St. Louis Park", "Yoga", "BE");
		String URL = driver.getCurrentUrl();
		//System.out.println("The Current URL is "+URL);

		String originalString = URL; 
		String stringToBeInserted = "For"; 
		int index = 108; 

		//System.out.println("Modified String: "+ util.insertString(originalString, stringToBeInserted, index)); 
		String modifiedString = util.insertString(originalString, stringToBeInserted, index);

		driver.get(modifiedString);
		Thread.sleep(100);
		String expText = "Sorry, the \"Class Name\" filter is not valid. Please choose another filter.";
		//verify alert on screen display 
		util.isTextPresent(clsSchPg.getAlertMessage(), expText);

	}

	/**
	 * Test to verify the wait list functionality
	 * @throws Exception
	 */
	@Test
	public void test_tier1_verifyWaitListFunctionality() throws Exception {

		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");		
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Yoga", "Ashtanga Vinyasa");
		clsSchPg.selectAvailableClass("Chanhassen");
		detlPg.reserveClass();

		util.clickElement(myResvPg.getBtnMyReservations());
		util.verifyPageTitle(Constants.Reservations);

		/// Logout from the applicaion and loged in as seconday member
		util.clickElement(bookabilityPg.getloggedInName());
		util.clickElement(bookabilityPg.getBtnLogOut());

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"),
				envProperties.getProperty("login.member.password"));
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Yoga", "Ashtanga Vinyasa");
		clsSchPg.selectAvailableClass("Chanhassen");
		detlPg.reserveClass();

		util.clickElement(detlPg.getBtnReserve());	

	}

	/**
	 * Test to verify the loader
	 * @throws Exception
	 */
	@Test
	public void test_tier1_verifyLoaderExist() throws Exception 
	{
		String externalId = envProperties.getProperty("login.member.memberid"); // Cancel all available fitmetrix
		// reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		util.verifyPageTitle("Chanhassen");

		homPg.navigateToClassSchPage(); // Navigate to Class Schedule page from member page

	}



	/**
	 * verifying the design updates and the registration 
	 */
	@Test
	public void test_tier3_VerifyDesignUpdatesAndRegistrationSidebar() {

		String externalId = envProperties.getProperty("login.member.memberid");
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cardio", "EDG Cycle");
		clsSchPg.selectAvailableClass("Chanhassen");
		//verify elements in Details Page
		Assert.assertTrue(util.isElementPresent(detlPg.getClassEndDate()));
		Assert.assertTrue(util.isElementPresent(detlPg.PostEDGcycle()));
		Assert.assertTrue(util.isElementPresent(detlPg.getHdrRegistration()));
		Assert.assertTrue(detlPg.getTxtSpotsAvailable().getText().contains("spots available"));
		Assert.assertTrue(util.isTextPresent(detlPg.getHdrWhatToExpect(), "What to Expect"));
		Assert.assertTrue(util.isElementPresent(detlPg.getBtnLoginToReserve()));

		util.clickElement(detlPg.getBtnLoginToReserve());
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		Assert.assertTrue(util.isElementPresent(detlPg.getBtnReserve()));
		util.verifyPageTitle(Constants.CLASS_DETAILS_PAGE_TITLE);
		util.clickElement(detlPg.getBtnReserve());
		//util.wait(10);
		util.verifyPageTitle(Constants.FITMETRIX_PAGE_TITLE);





	}

	/**
	 * verifying instructor name with bio link
	 */
	@Test
	public void test_tier3_VerifyInstructorNameWithBioLink() {

		String externalId = envProperties.getProperty("login.member.memberid");
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Aaron W.", "Cardio", "Gluteus MAXout");
		clsSchPg.selectAvailableClass("Chanhassen");
		//Instructor Name is displayed as link
		Assert.assertTrue(util.isElementPresent(detlPg.getLnkInstructor()));
		//Instructor name link is in blue color
		Assert.assertTrue(util.getElementColor(detlPg.getLnkInstructor()).equalsIgnoreCase("#0078aa"));
		util.clickElement(detlPg.getLnkInstructor());
		util.verifyPageTitle(Constants.PT_BIOS_PAGE_TITLE);
		driver.navigate().back();
		util.verifyPageTitle(Constants.CLASS_DETAILS_PAGE_TITLE);
	}

	/**
	 * verifying instructor name without bio link
	 */
	@Test
	public void test_tier3_VerifyInstructorNameWithoutBioLink() {

		String externalId = envProperties.getProperty("login.member.memberid");
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cardio", "EDG Cycle");
		clsSchPg.selectAvailableClass("Chanhassen");
		//Instructor Name is displayed as text, NOT as link
		Assert.assertTrue(util.isElementPresent(detlPg.getTxtInstructor()));
		//Instructor name link is NOT in blue color
		Assert.assertFalse(util.getElementColor(detlPg.getTxtInstructor()).equalsIgnoreCase("#0078aa"));		
	}

	@Test
	public void test_tier3_VerifyDisplayNotificationGreaterThan6Days() {

		String externalId = envProperties.getProperty("login.member.memberid");
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));
		//EDG cycle
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cardio", "EDG Cycle");
		//select greater than 6 days
		util.clickElement(clsSchPg.getBtnNextWeek());
		util.clickElement(clsSchPg.getBtnNextWeek());
		if (util.getDevice().equals("Mobile")) {
			int i = 1;
			while(i < 6)
			{
				while(util.isElementPresent(clsSchPg.getDivEdgeCycling()) == false)
				{
					util.clickElement(clsSchPg.getNextAvailableDate(i));
				}
				i++;
			}
		}
		util.clickElement(clsSchPg.getDivEdgeCycling());

		Assert.assertTrue(util.isTextPresent((progPg.getAlertMsg()),
				Constants.NotificationGreaterThan6Days));
		//YOGA
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Yoga", "Ashtanga Vinyasa");
		//select greater than 6 days
		util.clickElement(clsSchPg.getBtnNextWeek());
		util.clickElement(clsSchPg.getBtnNextWeek());
		if (util.getDevice().equals("Mobile")) {
			int i = 1;
			while(i < 6)
			{
				while(util.isElementPresent(clsSchPg.getDivEdgeCycling()) == false)
				{
					util.clickElement(clsSchPg.getNextAvailableDate(i));
				}
				i++;
			}
		}
		util.clickElement(clsSchPg.getDivEdgeCycling());
		Assert.assertTrue(util.isTextPresent((progPg.getAlertMsg()), 
				Constants.NotificationGreaterThan6Days));

	}


	/**
	 * verifying class with multiple instructor
	 */
	@Test
	public void test_tier3_VerifyClassWithMultipleInstructor() {
		String externalId = envProperties.getProperty("login.member.memberid");
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen",  "Cardio", "Express TCX");
		util.clickElement(clsSchPg.getBtnNextWeek());
		//clsSchPg.selectAvailableClass("Chanhassen");
		util.clickElement(clsSchPg.getTcxXpath());
		//util.verifyPageTitle(Constants.CLASS_DETAILS_PAGE_TITLE);
		util.wait(5);
		//verify class with more than one instructor
		List<WebElement> multipleInstructor = driver.findElements(By.xpath("//button[text()='Add to Calendar']/preceding-sibling::p[2]/span"));

		Assert.assertTrue(multipleInstructor.size() > 0);
		for(WebElement instructor : multipleInstructor)
		{
			//Assert.assertTrue(multipleInstructor.size() > 1);
			String abc =instructor.getText();
			System.out.println(abc);
		}

	}

	/**
	 * Verify when user get registered for the class and revisit the same class details page, add to calendar button should display. 
	 */
	@Test
	public void test_tier3_VerifyAddToCalendarAfterRegisteringClass() {

		String externalId = envProperties.getProperty("login.member.memberid");
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));
		//EDG cycle
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cardio", "EDG Cycle");
		clsSchPg.selectAvailableClass("Chanhassen");
		detlPg.reserveClass();

		util.clickElement(detlPg.getLnkClassSchedules());
		clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cardio", "EDG Cycle");
		clsSchPg.selectAvailableClass("Chanhassen");
		//verify add  to calendar button in class details page after registering the class
		util.verifyPageTitle(Constants.CLASS_DETAILS_PAGE_TITLE);
		Assert.assertTrue(util.isElementPresent(detlPg.getbtnAddToCalendar()));


	}

	/**
	 * Test to verify the Team Message Update
	 * @throws Exception
	 */
	@Test
	public void test_tier1_veriyUpdateTeamMessage() throws Exception {

		String text = "Reservation available upon purchase in-club (online purchase coming soon)";
		String externalId = envProperties.getProperty("login.member.memberid");
		// Cancel all available fitmetrix reservations
		myResvPg.CancelAllFitMetrixReservations(externalId, Auth);
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.member.user"), envProperties.getProperty("login.member.password"));

		clsSchPg.navigateToSchedulesPageAndSelectFilters("Crosstown (Eden Prairie)", "Strength Training",
				"Alpha Strong");

		clsSchPg.selectAvailableClass("Crosstown (Eden Prairie)");

		// Verify the message on screen .
		util.isElementPresent(text);

	}
}

