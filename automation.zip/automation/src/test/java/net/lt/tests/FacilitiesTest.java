package net.lt.tests;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

public class FacilitiesTest extends TestBase {

	RequestSpecification basicAuth, Auth;

	/**
	 * Description : To validate the ability to perform Platinum Reservation Created
	 * By : Saravanan Ravichandran Created Date : Feb 12th 2018 Modified By :
	 * Modified Date : Preconditions :
	 */	

	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;

	PendingReservationPage pResvPg;
	ProgramsPage programsPg;


	@Before
	public void apiSetup() 
	{
		//API BASE uri
		RestAssured.baseURI = "https://api.lifetimefitness.com/qa";
		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Ocp-Apim-Subscription-Key", "2e77f50f231e4647b3339a5494470361");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
		programsPg = new ProgramsPage(driver);
	}




	/**
	 * Test to verify whether Founders member bronze has ability to book courts at Gold locations
	 * @throws Exception
	 */
	@Test
	public void test_tier2_MemberFoundersBronzePlusmembershouldhavetheabilitytobookRacquetballandSquashcourtsat7Goldlocation() throws Exception 
	{
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.founderBronze.user"), envProperties.getProperty("login.founderBronze.password"));

		//Adding all locations to a Array list
		List<String> locations = new ArrayList<String>();

		locations.add("Woodbury MN, USA"); 
		locations.add("Bloomington MN, USA");
		locations.add("Fridley MN, USA");
		
		//Iterating each locations and verifying whether able to Racquetball book courts
		for( String location : locations)
		{
			homPg.searchLocation(location);			
			util.verifyPageTitle((location.split(" "))[0]);		
			homPg.navigateToPrograms(Constants.RACQUETBALL);		
		}
	}
	
	/**
	 * Test to verify whether Founders member has ability to book courts at Gold locations
	 * @throws Exception
	 */
	@Test
	public void test_tier2_MemberFoundermembersShouldhavetheabilitytobookRacquetballandSquashcourtsat7Goldlocation() throws Exception 
	{
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.founderOne.user"), envProperties.getProperty("login.founderOne.password"));

		//Adding all locations to a Array list
		List<String> locations = new ArrayList<String>();

		locations.add("Woodbury MN, USA"); 
		locations.add("Bloomington MN, USA");
		locations.add("Fridley MN, USA");

		//Iterating each locations and verifying whether able to Racquetball book courts
		for( String location : locations)
		{
			homPg.searchLocation(location);			
			util.verifyPageTitle((location.split(" "))[0]);		
			homPg.navigateToPrograms(Constants.RACQUETBALL);		
		}
	}

	
	/**
	 * Test to verify whether Conference Rooms option removed from MyLT
	 */
	@Test
	public void test_tier1_verifyConferenceRoomsRemovedfromMyLT() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "www.mylt.life/login.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));		

		homPg.selectLocation("St. Louis Park");
		util.verifyPageTitle("St. Louis Park");
		homPg.navigateToPrograms("Tennis"); // Navigate to Class Schedule page from member page
		util.clickElement(programsPg.getReserveACourtButton());		

		Assert.assertFalse(myResvPg.getFacilitiesDropDown().getText().contains("Conference room"));		
	}

	@Test
	public void test_tier3_verifyReservationPolicyAndWaiver() {
		ProgramsPage progPg = new ProgramsPage(driver);
		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "www.mylt.life/login.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));
		reserveACourt("Parker-Aurora", "Racquetball", 1);
		pResvPg.verifyReservationPolicyAndWaiver();


	}

	@Test
	public void test_tier3_MemberUpdateFacilityRulesforDayPassUsers() throws InterruptedException 
	{
		ProgramsPage progPg = new ProgramsPage(driver);

		driver.navigate().to(EnvConfig.getInstance().getPrefix()
				+ "www.mylt.life/login.html");

		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
				envProperties.getProperty("login.ltmember.password"));
		reserveACourt("Parker-Aurora", "Squash", 1);

		Assert.assertTrue(util.isTextPresent(progPg.getAlertMsg(), Constants.DAYPASS_MSG));

	}
	//	@Test
	//	public void test_tier2_MemberVerifyStickyfacilityTypeUponReturningtoPage() {
	//		LoginPage lgnPg = new LoginPage(driver);
	//		Utility util = new Utility(driver);
	//
	//		BookingPage bookingPg = new BookingPage(driver);
	//		ProgramsPage progPg = new ProgramsPage(driver);
	//		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
	//		ReservationsPage myResvPg = new ReservationsPage(driver);
	//		PendingReservationPage pResvPg = new PendingReservationPage(driver);
	//
	//		driver.navigate().to(EnvConfig.getInstance().getPrefix()
	//				+ "www.mylt.life/login.html");
	//
	//		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
	//				envProperties.getProperty("login.ltmember.password"));
	//		myResvPg.FacilitiesDropdown();
	//		
	//	
	//	
	//	}
	//	@Test
	//	public void test_tier3_MemberUpdateFacilityRulesforDayPassUsers() {
	//		LoginPage lgnPg = new LoginPage(driver);
	//		Utility util = new Utility(driver);
	//
	//		BookingPage bookingPg = new BookingPage(driver);
	//		ProgramsPage progPg = new ProgramsPage(driver);
	//		ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
	//		ReservationsPage myResvPg = new ReservationsPage(driver);
	//		PendingReservationPage pResvPg = new PendingReservationPage(driver);
	//
	//		driver.navigate().to(EnvConfig.getInstance().getPrefix()
	//				+ "work.lifetime.life/login.html?resource=/member/pa/ardmore/facilities.html");
	//
	//		lgnPg.login(envProperties.getProperty("login.ltmember.user"),
	//				envProperties.getProperty("login.ltmember.password"));
	//		
	//}

	/**
	 * Method to reserve a court
	 * @param clubLocation
	 * @param courtToBeReserved
	 */
	public void reserveACourt(String clubLocation, String courtToBeReserved, int noOfDaysFromCurrentDay)
	{
		Utility util = new Utility(driver);
		HomePage homPg = new HomePage(driver);

		ProgramsPage progPg = new ProgramsPage(driver);
		homPg.searchLocation(clubLocation);

		util.verifyPageTitle((clubLocation.split(" "))[0]);		

		homPg.navigateToPrograms(courtToBeReserved); // Navigate to Class Schedule page from member page

		util.verifyPageTitle(courtToBeReserved); // Verifying the page title

		progPg.reserveACourt(courtToBeReserved, noOfDaysFromCurrentDay);		
	}
}


