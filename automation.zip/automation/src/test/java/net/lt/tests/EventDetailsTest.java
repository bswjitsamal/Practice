package net.lt.tests;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;
import net.lt.pages.ClassSchedulesPage;
import net.lt.pages.DetailsPage;
import net.lt.pages.EventPage;
import net.lt.pages.FitMetrixPage;
import net.lt.pages.HomePage;
import net.lt.pages.LoginPage;
import net.lt.pages.PendingReservationPage;
import net.lt.pages.ProgramsPage;
import net.lt.pages.ReservationsPage;

public class EventDetailsTest extends TestBase {
	RequestSpecification basicAuth, Auth;
	String SSOID;
	int threadNum = Runtime.getRuntime().availableProcessors() * 2;

	ProgramsPage progPg; //= new ProgramsPage(driver);
	ClassSchedulesPage clsSchPg;
	Utility util;
	HomePage homPg;
	FitMetrixPage fmPg;
	ReservationsPage myResvPg;
	LoginPage lgnPg;
	DetailsPage detlPg;
	EventPage evntPg;

	PendingReservationPage pResvPg;

	@Before
	public void apiSetup() {


		RestAssured.baseURI = "https://api.lifetimefitness.com/qa";
		// Authentication with bearer Token
		Auth = RestAssured.given();
		Auth.headers("Ocp-Apim-Subscription-Key", "2e77f50f231e4647b3339a5494470361");
		Auth.contentType(ContentType.JSON);

		clsSchPg = new ClassSchedulesPage(driver);
		util = new Utility(driver);
		homPg = new HomePage(driver);
		fmPg = new FitMetrixPage(driver);
		myResvPg = new ReservationsPage(driver);
		lgnPg = new LoginPage(driver);
		detlPg = new DetailsPage(driver);
		pResvPg =  new PendingReservationPage(driver);
		evntPg = new EventPage(driver);

	} 


	@Test
	public void test_tier2_verifyFilterOptionsInEventPage() {


		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));
		util.verifyPageTitle(Constants.Chanhassen);

		util.clickElement(homPg.getLnkEvent());
		util.clickElement(homPg.getLnkAllEvent());
		// util.verifyPageTitle(Constants.EventsChanhassen);

		//verify Hide Filters button is present
		util.isElementPresent(evntPg.BtnHideFilters());

		//verifyDropdownsPresentInEventsPage
		Assert.assertTrue(util.isElementPresent(evntPg.drpdwnStartdate()));
		Assert.assertTrue(util.isElementPresent(evntPg.drpdwnEnddate()));
		Assert.assertTrue(util.isElementPresent(evntPg.drpdwnInterest()));
		Assert.assertTrue(util.isElementPresent(evntPg.drpdwnAge()));
		Assert.assertTrue(util.isElementPresent(evntPg.drpdwnAddClubLoc()));
		//verify chiclets club location present
		List<WebElement> filters = driver.findElements(By.xpath("//div[@class='chiclets-container']//button[contains(@class,'chiclet')]"));
		for(WebElement filter : filters)
		{
			Assert.assertTrue(filter.getText().contains("Chanhassen"));
		}
		//verify the start date and End date
		String startDate = evntPg.drpdwnStartdate().getText();
		String EndDate = evntPg.drpdwnEnddate().getText();
		String currentDate = Utility.getFormattedDate(new Date(), "EEEE, MMM dd");
		Calendar cal = Calendar.getInstance(); 
		cal.add(Calendar.DATE, 90);
		Date newdate = cal.getTime();
		String after90Days = Utility.getFormattedDate(newdate, "EEEE, MMM dd");
		startDate.equals(currentDate);
		EndDate.equals(after90Days);
		//click button Hide Filters
		util.clickElement(evntPg.BtnHideFilters());
		util.wait(3);
		//verify the dropdowns not visible
		Assert.assertFalse(util.isElementPresent(evntPg.drpdwnStartdate()));
		Assert.assertFalse(util.isElementPresent(evntPg.drpdwnEnddate()));
		Assert.assertFalse(util.isElementPresent(evntPg.drpdwnInterest()));
		Assert.assertFalse(util.isElementPresent(evntPg.drpdwnAge()));
		Assert.assertFalse(util.isElementPresent(evntPg.drpdwnAddClubLoc()));
		//verify the chiclets club location is still present
		List<WebElement> filterss = driver.findElements(By.xpath("//div[@class='chiclets-container']//button[contains(@class,'chiclet')]"));
		for(WebElement filter : filterss)
		{
			Assert.assertTrue(filter.getText().contains("Chanhassen"));

		}




	}

	@Test
	public void test_tier2_verifyAddGroupParameters() {

		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/login.html");
		lgnPg.login(envProperties.getProperty("login.ltmember.user"), envProperties.getProperty("login.ltmember.password"));
		util.verifyPageTitle(Constants.Chanhassen);

		util.clickElement(homPg.getLnkEvent());
		util.clickElement(homPg.getLnkAllEvent());
		// util.verifyPageTitle(Constants.EventsChanhassen);
		String invalidGroupURL = EnvConfig.getInstance().getPrefix() + "my.lifetime.life/clubs/mn/chanhassen/events.html?interestFormatGroup=InvalidGroup" ;
		String eventURL = EnvConfig.getInstance().getPrefix() + "my.lifetime.life/clubs/mn/chanhassen/events.html?interestFormatGroup=Event";
		String campURL = EnvConfig.getInstance().getPrefix() + "my.lifetime.life/clubs/mo/west-county-chesterfield/events.html?interestFormatGroup=Camp";
			

		List<WebElement> validGroupFilters = driver.findElements(By.xpath("//div[@class='chiclets-container']//button[contains(@class,'chiclet')]"));
		Assert.assertTrue(validGroupFilters.size() > 0);
		for(WebElement filter : validGroupFilters)
		{
			Assert.assertTrue(filter.getText().contains("Chanhassen"));
		}

		//verifying the filters with URL 'invalid group URL'

		driver.navigate().to(invalidGroupURL);
		util.verifyPageTitle("Events");
		List<WebElement> invalidGroupFilters = driver.findElements(By.xpath("//div[@class='chiclets-container']//button[contains(@class,'chiclet')]"));
		Assert.assertTrue(invalidGroupFilters.size() > 0);
		for(WebElement filter : invalidGroupFilters)
		{
			Assert.assertTrue(filter.getText().contains("Chanhassen"));
		}

		System.out.println("invalid group verification done");
		//navigating to  URL 'Events'

		driver.navigate().to(eventURL);
		String URL1 = driver.getCurrentUrl();
		util.verifyPageTitle("Events");
		System.out.println(URL1);
		
		List<WebElement> eventCheckboxes = driver.findElements(By.xpath("//div[text()='Event']/..//label[contains(@class,'checkbox')]/input"));
		Assert.assertTrue(eventCheckboxes.size() > 0);
		for(WebElement checkBox : eventCheckboxes)
		{
			Assert.assertTrue(checkBox.isSelected());			
		}
		
		//verify all the filters with 'events' are present
		List<WebElement> eventfilters = driver.findElements(By.xpath("//div[@class='chiclets-container']//button[contains(@class,'chiclet')]"));
		Assert.assertTrue(eventfilters.size() > 0);
		for(WebElement filter : eventfilters)
		{
			String abc = filter.getText();
			System.out.println(abc);
			if(!filter.getText().contains("Chanhassen"))
			{
				Assert.assertTrue(filter.getText().contains("Event"));
			}
		}

		System.out.println("Events verification done");
		driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mo/west-county-chesterfield.html");


		driver.navigate().to(campURL);
		util.verifyPageTitle("Events");
		
		List<WebElement> campCheckboxes = driver.findElements(By.xpath("//div[text()='Camp']/..//label[contains(@class,'checkbox')]/input"));
		Assert.assertTrue(campCheckboxes.size() > 0);
		for(WebElement checkBox : campCheckboxes)
		{
			Assert.assertTrue(checkBox.isSelected());	
		}
		//verify all the filters with 'camp' are present
		List<WebElement> campFilters = driver.findElements(By.xpath("//div[@class='chiclets-container']//button[contains(@class,'chiclet')]"));
		Assert.assertTrue(campFilters.size() > 0);
		for(WebElement filter : campFilters)
		{
			String abc = filter.getText();
			System.out.println(abc);
			if(!filter.getText().contains("West County-Chesterfield"))
			{
				Assert.assertTrue(filter.getText().contains("Camp"));
			}

		}
	}
	
	
	
}



















