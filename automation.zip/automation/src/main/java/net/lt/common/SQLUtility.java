package net.lt.common;

import java.sql.SQLException;
import java.util.Properties;
import net.lt.config.EnvConfig;

/*******************************************************************************
 * *
 */
public class SQLUtility {

	/*******************************************************************************
	 * Used to create event in boss database
	 *
	 */
	public int createEventData(String upccode, String startDate, String endDate, String defPrice, String comment,
			String club, String resourceId, String resource, String upcDesc, String mmsProdId) throws SQLException {
		Properties sqlProp;
		String sql;
		int reservation = 0;
		try {
			sqlProp = EnvConfig.getInstance().getSqlProperties();
			sql = sqlProp.getProperty("CREATE_EVENT_SQL");
			sql = sql.replace("$UPCCODE", upccode);
			sql = sql.replace("$STARTDATE", startDate);
			sql = sql.replace("$ENDDATE", endDate);
			sql = sql.replace("$DEFPRICE", defPrice);
			sql = sql.replace("$COMMENT", comment);
			sql = sql.replace("$CLUB", club);
			sql = sql.replace("$RESOURCEID", resourceId);
			sql = sql.replace("$RESOURCE", resource);
			sql = sql.replace("$UPCDESC", upcDesc);
			sql = sql.replace("$MMSPRODID", mmsProdId);
			reservation = DatabaseUtil.insertQuery(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return reservation;
	}

	/*******************************************************************************
	 * Used to delete event in boss database
	 *
	 */
	public void deleteEventData(int reservationid) throws SQLException {
		Properties sqlProp;
		String sql;
		try {
			sqlProp = EnvConfig.getInstance().getSqlProperties();
			sql = sqlProp.getProperty("DELETE_EVENT_SQL");
			sql = sql.replace("$RESERVATION", Integer.toString(reservationid));
			DatabaseUtil.deleteQuery(sql);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
