package net.lt.common;

/*******************************************************************************
 * Automation Constants will be maintained here
 */
public final class Constants {

	public static final int TIME_OUT = 60;

	/*******************************************************************************
	 * Schedule constants
	 */

	public static final String FavoriteName = "ScheduleName";
	public static final String EditFavName = "ScheduleName1";
	public static final String Chanhassen = "Chanhassen";
	public static final String PageTitleChanhassen = "Schedules - Chanhassen";
	public static final String PageTitleClassDetailClassChanhassen = "Class Details - Chanhassen";	


	//PageTitle

	public static final String LifeTimeFitnessReservations = "Life Time Fitness Reservations";
	//public static final String LifeTimeFitnessReservations_1 = "Class Details - St. Louis Park";
	public static final String Reservations = "Reservations";
	//public static final String Reservations = "Reservations";
	public static final String CourtReservations = "Reservations";
	public static final String ConferenceRoomCreateReservationPageTitle = "Create Reservation";
	public static final String ClassDetailsStLouisPark = "Class Details - St. Louis Park";
	public static final String ClassDetailsChanhassen = "Class Details - Chanhassen";
	public static final String ClassDetailsCrossTown = "Class Details - Crosstown (Eden Prairie)";
	public static final String ClassesStLouisPark = "Schedules - St. Louis Park";
	public static final String ClassesChanhassen = "Schedules - Chanhassen";
	public static final String Classes = "Schedules";
	
	public static final String SaveAsFavText = "Demo";
	public static final String SaveFavText = "Meg";
	public static final String EditFavText = "Demo1";
	public static final String SuccessMessage = "Schedule successfully added to Favorites.";
	public static final String EditSuccessMessage = "Favorite schedule name successfully edited.";
	public static final String TennisCrossTown = "Tennis - Crosstown (Eden Prairie)";
	public static final String ClassCrossTown = "Schedules - Crosstown (Eden Prairie)";
	public static final String CrossTown = "Crosstown (Eden Prairie)";
	public static final String RacquetballCrossTown = "Racquetball - Crosstown (Eden Prairie)";
	public static final String Kingwood = "Kingwood";
	public static final String EventsKingwood = "Events - Kingwood";
	public static final String EventsChanhassen = "Events - Chanhassen";
	public static final String eventDetailsKingWood = "Event Details - Kingwood";
	public static final String eventDetailsChanhassen = "Event Details - Chanhassen";
	public static final String eventDetailsCrossTown = "Event Details - Crosstown (Eden Prairie)";
	public static final String eventsCrossTown = "Events - Crosstown (Eden Prairie)";
	public static final String alertMessage = "You must select one adult and one junior.";
	public static final String youmustselectoneadultandonejunior = "You must select one adult and one junior";
	public static final String youmustselectatleastoneparticipant = "You must select at least one participant.";


	// Page Title
	
	
	public static final String JOIN_PAGE_TITLE = "Life Time Healthy Way of Life | Join Life Time";
	public static final String FACILITIES_PAGE_TITLE = "Facilities";
	public static final String EVENT_DETAILS_PAGE_TITLE = "Event Details";
	public static final String EVENT_PAGE_TITLE = "Event";
	public static final String HELP_FAQ_PAGE_TITLE = "Help & FAQs";
	public static final String LOGIN_PAGE_TITLE = "Login";
	public static final String CLASS_DETAILS_PAGE_TITLE = "Class Details";
	public static final String FITMETRIX_PAGE_TITLE = "Pick a Spot";
	public static final String PT_BIOS_PAGE_TITLE = "Performer Bios";


	/**
	 * Club Location Constants
	 */
	public static final String ST_LOUIS_PARK = "St. Louis Park";


	/**
	 * Location Names //components test
	 *
	 */
	public static final String centennial = "Court 1, Centennial Tennis";
	public static final String YogaChanhassen1 = "Yoga Studio, Chanhassen";
	public static final String YogaChanhassen2 = "Yoga Studio, Chanhassen";
	


	/**
	 * Membership Levels
	 *
	 */
	public static final String Chnhsn = "Onyx Limited Club";
	public static final String AppleValley = "Bronze Club";
	public static final String EdenPrairieAthletic = "Diamond Club";
	public static final String LakesVille = "Platinum Club";

	/**
	 * dropdowns and chkbox in event page
	 *
	 */
	public static final String interest = "Interest";
	public static final String age = "Age";
	public static final String showOnlyFreeEvents = "Show only FREE events";


	/**
	 * Alert Messages
	 *
	 */
	public static final String YOU_HAVE_N0_FAV_MSG = "You have no favorite schedules. Save a favorite schedule for next time by applying filters and then selecting “Add Schedule to Favorites” below.";
	public static final String NO_FAVORITES_MSG = "No favorite class schedules";
	public static final String DAYPASS_MSG = "Day pass users must call or visit the club to make court reservations";
	public static final String UNAUTHENTICATED_MSG = "You must be logged in to make a reservation. Log in.";
	public static final String NotificationGreaterThan6Days = "The registration booking window will open 6 days before the class.";
	public static final String SQUASH_RESREVATION_ALLOWED_PER_DAY_MSG = "One squash court reservation is allowed per day. To create a new reservation, you must cancel your existing reservation. (720) 842-0800";
	public static final String OUTSIDE_OF_MEMBERSHIP_LEVEL = "This Life Time location is outside your membership level. Locate nearby clubs you can access.";
	public static final String RACQUETBALL_RESREVATION_ALLOWED_PER_DAY_MSG = "One racquetball court reservation is allowed per day. To create a new reservation, you must cancel your existing reservation. (720) 842-0800";
	public static final String RESERVATION_RULES_MSG = "If you have any special needs for your meeting (technology, catering, or otherwise) please contact the Front Desk or the Life Time Work Manager. Please cancel at least 60 minutes in advance of start time, otherwise standard charges will occur.";

	public static final String Tax = "(plus tax)";
	public static final String TitleSpooktacular = "Spooktacular";
	public static final String confirmationText = "Your reservation is complete.";
	public static final String confirmationtext2 = "Thank you! An email has been sent to the email addresses on file. Additional documentation may be required prior to participating in the activity.";

	public static final String sameNameErrMsg = "This schedule name already exists. Please try a different one.";

	public static final String RemoveLocErrMsg = "Are you sure you want to remove this location? Doing so will clear all results.";

	public static final String NoLocErrMsg = "No location selected. To continue, select one or more locations in the filters below, or choose a new location in the navigation bar above.";


	public static final String hdrClassSchedules = "Class Schedules";
	
	
	/**
	 * Courts Constants
	 */
	public static final String RACQUETBALL = "Racquetball";



}