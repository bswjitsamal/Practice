package net.lt.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.junit.Assert;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

/*******************************************************************************
 * Common page class to use in all page classes
 */ 
public 
class 
WebServiceUtil 
{

	
   /**
    * Method to get the Activitykey from exerp
    * @param centerId
    * @param className
    * @return
    */
   public 
   String 
   getExerpActivityKey( int centerId, String className )
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/BookingAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         
         
                                                 //Set the Header Information
                                                 //for Exerp Soap request
         HashMap<String, String> l_headermap = new HashMap<>();
         l_headermap.put( "Content-Type", "text/xml" );
         l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
         String l_reqbody = "<soapenv:Envelope " + 
        		 "xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " + 
        		 "xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
        		 "	  <soapenv:Header/>\r\n" + 
        		 "    <soapenv:Body>\r\n" + 
        		 "        <v5:getAvailableActivities>\r\n" + 
        		 "            <centers>\r\n" + 
        		 "                <item>" + centerId + "</item>\r\n" + 
        		 "            </centers>\r\n" + 
        		 "        </v5:getAvailableActivities>\r\n" + 
        		 "    </soapenv:Body>\r\n" + 
        		 "</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
                                       //Post the request and 
                                                 //get the exerp response back
          l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
          System.out.println(""+l_response.getStatusCode());
          verifyStatusCode(l_response, 200);
          
          String l_resp = l_response.asString();
          String l_root = "Envelope.Body.getAvailableActivitiesResponse.return";
          XmlPath l_path = new XmlPath( l_resp ).setRoot( l_root );
          int itemSize = (l_path).getList("item").size();
       
          for(int i=0;i<=itemSize-1;i++)
          {
        	  if(l_path.get( "item.name[" + i + "]" ).toString().equalsIgnoreCase(className))
        	  {
        		  System.out.println("ActivityId" + l_path.get( "item.activityId[" + i + "]").toString() );
        		  return l_path.get( "item.activityId[" + i + "]").toString(); 
        	  }
          }
         
         return null; 
         
      }
      catch( Exception l_exception )
      {
         throw new RuntimeException( l_exception );
      }

   }
   
   
   /**
    * Method to get the resource Id from exerp
    * @param centerId
    * @param activityKey
    * @param studioName
    * @return
    */
   public 
   String 
   getExerpResourceId( int centerId, String activityKey, String studioName )
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/BookingAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         
         
                                                 //Set the Header Information
                                                 //for Exerp Soap request
         HashMap<String, String> l_headermap = new HashMap<>();
         l_headermap.put( "Content-Type", "text/xml" );
         l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
         String l_reqbody = "<soapenv:Envelope " + 
        		 "xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " + 
        		 "xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
        		 "	  <soapenv:Header/>\r\n" + 
        		 "    <soapenv:Body>\r\n" + 
        		 "        <v5:getResources>\r\n" +        		         
        		 "                <center>" + centerId + "</center>\r\n" + 
        		 "                <activityKey>" + activityKey + "</activityKey>\r\n" + 
        		 "        </v5:getResources>\r\n" + 
        		 "    </soapenv:Body>\r\n" + 
        		 "</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
                                       //Post the request and 
                                                 //get the exerp response back
          l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
          System.out.println(""+l_response.getStatusCode());
          verifyStatusCode(l_response, 200);
          
          String l_resp = l_response.asString();
          String l_root = "Envelope.Body.getResourcesResponse.return";
          XmlPath l_path = new XmlPath( l_resp ).setRoot( l_root );
          int itemSize = (l_path).getList("item").size();
         
          for(int i=0;i<=itemSize-1;i++)
          {
          	  if(l_path.get( "item.name[" + i + "]" ).toString().equalsIgnoreCase(studioName))
        	  {
        		  System.out.println("resourceId" + l_path.get( "item.key.id[" + i + "]").toString() );
        		  return l_path.get( "item.key.id[" + i + "]").toString();
        	  }
          }
         
         return null; 
         
      }
      catch( Exception l_exception )
      {
         throw new RuntimeException( l_exception );
      }

   }
   
   /**
    * Method to get the Staff Id from exerp
    * @param centerId
    * @return
    */
   public 
   int 
   getExerpPersonId( String personName, String personType)
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/PersonAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         
         
                                                 //Set the Header Information
                                                 //for Exerp Soap request
         HashMap<String, String> l_headermap = new HashMap<>();
         l_headermap.put( "Content-Type", "text/xml" );
         l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
         String l_reqbody = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
         		"  <soapenv:Header/>\r\n" + 
         		"  <soapenv:Body>\r\n" + 
         		"    <v5:findPersons>\r\n" + 
         		"      <parameters>        \r\n" + 
         		"        <personType>"+ personType +"</personType>\r\n" + 
         		"        <name>"+ personName +"</name>\r\n" + 
         		"      </parameters>\r\n" + 
         		"    </v5:findPersons>\r\n" + 
         		"  </soapenv:Body>\r\n" + 
         		"</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
                                       //Post the request and 
                                                 //get the exerp response back
          l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
          System.out.println(""+l_response.getStatusCode());
          verifyStatusCode(l_response, 200);
          
          String l_resp = l_response.asString();
          String l_root = "Envelope.Body.findPersonsResponse.return";
          XmlPath l_path = new XmlPath( l_resp ).setRoot( l_root );        
          System.out.println(l_path.get( "item.personId.id").toString());
          return Integer.parseInt(l_path.get( "item.personId.id").toString());      
      
         
      }
      catch( Exception l_exception )
      {
         throw new RuntimeException( l_exception );
      }

   }
   
   
   /**
    * Method to get the Staff Id from exerp
    * @param centerId
    * @return
    */
   public 
   int 
   getExerpPersonId( int centerId, String personType)
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/PersonAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         
         
                                                 //Set the Header Information
                                                 //for Exerp Soap request
         HashMap<String, String> l_headermap = new HashMap<>();
         l_headermap.put( "Content-Type", "text/xml" );
         l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
         String l_reqbody = "<soapenv:Envelope \r\n" + 
         		"xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" \r\n" + 
         		"xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
         		"   <soapenv:Header/>\r\n" + 
         		"   <soapenv:Body>\r\n" + 
         		"      <v5:findPersons>\r\n" + 
         		"         <parameters>\r\n" + 
         		"            <center>"+ centerId + "</center>\r\n" + 
         		"            <personType>" + personType + "</personType>\r\n" + 
         		"         </parameters>\r\n" + 
         		"      </v5:findPersons>\r\n" + 
         		"   </soapenv:Body>\r\n" + 
         		"</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
                                       //Post the request and 
                                                 //get the exerp response back
          l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
          System.out.println(""+l_response.getStatusCode());
          verifyStatusCode(l_response, 200);
          
          String l_resp = l_response.asString();
          String l_root = "Envelope.Body.findPersonsResponse.return";
          XmlPath l_path = new XmlPath( l_resp ).setRoot( l_root );        
          System.out.println(l_path.get( "item.personId.id[0]").toString());
          return Integer.parseInt(l_path.get( "item.personId.id[0]").toString());      
      
         
      }
      catch( Exception l_exception )
      {
         throw new RuntimeException( l_exception );
      }

   }
    
   
   
   
   
   /**
    * Method 
    * @param centerId
    * @param className
    * @param studioName
    * @param capacity
    * @return
    */
   public 
   int 
   createClassInExerp( int centerId, String className, 
		   			   String studioName,
		   			   int capacity )
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/BookingAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         SimpleDateFormat scheduleDate = new SimpleDateFormat("yyyy-MM-dd");
         String currdate = scheduleDate.format(new Date());
         
        String activityKey = new WebServiceUtil().getExerpActivityKey(centerId, className);
 		String resourceId = new WebServiceUtil().getExerpResourceId(centerId, activityKey, studioName);
 		int staffId = new WebServiceUtil().getExerpPersonId(centerId, "STAFF");	
         
      
         for(int i=1;i<=12;i++)
         {
        	 Calendar now = Calendar.getInstance();
              
        	 if(Calendar.HOUR > 5 && now.get(Calendar.HOUR_OF_DAY) + i < 24)
        	 {
        		 now.add(Calendar.HOUR, i);
        	 }
        	 else
        	 {
        		 now.add(Calendar.HOUR, 1);
        	 }
        	 String timeIn24HrsFormat = now.get(Calendar.HOUR_OF_DAY) + ":00";
         
        	 System.out.println("timeIn24HrsFormat "+timeIn24HrsFormat);
        	 System.out.println("date "+ Calendar.DATE);
                                                 //Set the Header Information
                                                 //for Exerp Soap request
        	 HashMap<String, String> l_headermap = new HashMap<>();
        	 l_headermap.put( "Content-Type", "text/xml" );
        	 l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
        	String l_reqbody = "<soapenv:Envelope\r\n" + 
        			"    xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"\r\n" + 
        			"    xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
        			"    <soapenv:Header/>\r\n" + 
        			"    <soapenv:Body>\r\n" + 
        			"        <v5:createClass>\r\n" + 
        			"            <parameters>\r\n" + 
        			"                <activityKey>" + activityKey + "</activityKey>\r\n" + 
        			"                <centerId>" + centerId + "</centerId>\r\n" + 
        			"                <date>" + currdate + "</date>\r\n" + 
        			"                <description>" + className + "</description>\r\n" + 
        			"                <duration>45</duration>\r\n" + 
        			"                <externalId>?</externalId>\r\n" + 
        			"                <maxCapacity>" + Integer.toString(capacity) + "</maxCapacity>\r\n" + 
        			"                <name>" + className + "</name>\r\n" + 
        			"                <resourceKeys>\r\n" + 
        			"                    <center>" + centerId + "</center>\r\n" + 
        			"                    <id>" + resourceId + "</id>\r\n" + 
        			"                </resourceKeys>\r\n" + 
        			"                <staffPersonKeys>\r\n" + 
        			"                    <center>" + centerId + "</center>\r\n" + 
        			"                    <id>" + staffId + "</id>\r\n" + 
        			"                </staffPersonKeys>\r\n" + 
        			"                <time>" + timeIn24HrsFormat + "</time>\r\n" + 
        			"            </parameters>\r\n" + 
        			"        </v5:createClass>\r\n" + 
        			"    </soapenv:Body>\r\n" + 
        			"</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
        										 //Post the request and 
                                                 //get the exerp response back
        	l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
        	System.out.println(""+l_response.getStatusCode());
        	try
        	{
        		verifyStatusCode(l_response, 200);
        		break;
        	}catch(Exception e)
        	{
        		continue;
        	}
         }

         String l_resp = l_response.asString();
         String l_root = "Envelope.Body.createClassResponse.return";
         XmlPath l_path = new XmlPath( l_resp ).setRoot( l_root );
         System.out.println(l_resp);

         System.out.println("BookingId : "+l_path.get("bookingId.id").toString());

         return Integer.parseInt(l_path.get("bookingId.id")); 

      }
      catch( Exception l_exception )
      {
    	  throw new RuntimeException( l_exception );
      }

   }
   
   
   public 
   void 
   cancelBookingInExerp( int centerId, int bookingKey )
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/BookingAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         
         
                                                 //Set the Header Information
                                                 //for Exerp Soap request
         HashMap<String, String> l_headermap = new HashMap<>();
         l_headermap.put( "Content-Type", "text/xml" );
         l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
         String l_reqbody = "<soapenv:Envelope "
         		+ "xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
         		+ "xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
         		"   <soapenv:Header/>\r\n" + 
         		"   <soapenv:Body>\r\n" + 
         		"      <v5:cancelBooking>\r\n" + 
         		"         <bookingKey>\r\n" + 
         		"            <center>" + centerId + "</center>\r\n" + 
         		"            <id>" + bookingKey + "</id>\r\n" + 
         		"         </bookingKey>\r\n" + 
         		"         <notifyParticipants>false</notifyParticipants>\r\n" + 
         		"         <notifyStaff>false</notifyStaff>\r\n" + 
         		"         <message>Cancelled by automation</message>\r\n" + 
         		"      </v5:cancelBooking>\r\n" + 
         		"   </soapenv:Body>\r\n" + 
         		"</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
                                       //Post the request and 
                                                 //get the exerp response back
          l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
          System.out.println(""+l_response.getStatusCode());
          verifyStatusCode(l_response, 200);         
      }
      catch( Exception l_exception )
      {
         throw new RuntimeException( l_exception );
      }

   }
   
   
   public 
   void 
   verifyReservationsExerp( int centerId, int personId, String className, int bookingKey )
   {
      try
      {
                                                 
         String l_url = "https://lifetime-qa.exerp.com/api/v5"
                                            + "/BookingAPI?wsdl"; 
         String l_authheader = "Basic MTAwZW1wODAxOnRGWjNkOGdyODA=";
         Response l_response = null;
         
         
                                                 //Set the Header Information
                                                 //for Exerp Soap request
         HashMap<String, String> l_headermap = new HashMap<>();
         l_headermap.put( "Content-Type", "text/xml" );
         l_headermap.put( "Authorization", l_authheader );
                                                 //soap request body     
         String l_reqbody = "<soapenv:Envelope\r\n" + 
         		"    xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"\r\n" + 
         		"    xmlns:v5=\"http://v5.api.eclub.procard.dk/\">\r\n" + 
         		"    <soapenv:Header/>\r\n" + 
         		"    <soapenv:Body>\r\n" + 
         		"        <v5:findPersonParticipations>\r\n" + 
         		"            <personKey>\r\n" + 
         		"                <center>"+ centerId +"</center>\r\n" + 
         		"                <id>"+ personId +"</id>\r\n" + 
         		"            </personKey>\r\n" + 
         		"        </v5:findPersonParticipations>\r\n" + 
         		"    </soapenv:Body>\r\n" + 
         		"</soapenv:Envelope>";
                                                 //Waits for sometime until
                                                 //expected status code
                                       //Post the request and 
                                                 //get the exerp response back
          l_response = RestAssured.given().log().all().headers( l_headermap )
                                .body( l_reqbody ).post( l_url ).andReturn();
          System.out.println(""+l_response.getStatusCode());
          verifyStatusCode(l_response, 200);    
          
          String l_resp = l_response.asString();
          String l_root = "Envelope.Body.findPersonParticipationsResponse.return";
          XmlPath l_path = new XmlPath( l_resp ).setRoot( l_root );
          System.out.println(l_resp);

          System.out.println("class Name : "+l_path.get("item.booking.activity.name").toString());
          System.out.println("class Name : "+l_path.get("item.booking.bookingId.id").toString());
          
          Assert.assertTrue(l_path.get("item.booking.activity.name").toString().equals(className));
          Assert.assertTrue(l_path.get("item.booking.bookingId.id").toString().equals(Integer.toString(bookingKey)));
          
          
      }
      catch( Exception l_exception )
      {
         throw new RuntimeException( l_exception );
      }

   }
   

   
 
   
/*******************************************************************************
 * Method to verify Status Code of the Exerp Soap response
 * @param Soap Response, Expected Status code
 * @return boolean true or false
 */
   public 
   Boolean 
   verifyStatusCode( Response a_response, int a_statuscode )
   {
      try
      {
                                                 //Compares the actual status 
                                                 //code with expected status
         Assert.assertTrue( "Verify Status code", a_response.getStatusCode()
                                                          == a_statuscode );
         return true;
      }
      catch( AssertionError l_exception )
      {
         throw new RuntimeException( l_exception );
      }
   }
   


  }