package net.lt.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import net.lt.config.EnvConfig;

/*******************************************************************************
 * Database Util class for database interaction
 */
public class DatabaseUtil {

	/*******************************************************************************
	 * Method to make the DB connection with the provided datasource
	 * 
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */

	private static Connection getDBConnection()
			throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		Connection conn = null;
		String dsn = "";
		Properties envproperties = EnvConfig.getInstance().getEnvProperties();
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
			dsn = envproperties.getProperty("datasource.name");
			if (!dsn.isEmpty()) {
				conn = System.getProperty("sqluser").equals("")
						? DriverManager.getConnection(dsn + "integratedSecurity=true;")
						: DriverManager.getConnection(dsn, System.getProperty("sqluser"), System.getProperty("sqlpwd"));

			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return conn;
	}

	/*******************************************************************************
	 * Method to execute a select query and return the result
	 */
	public static List<HashMap<String, Object>> selectQuery(String sqlQuery)
			throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
		Statement stmt = null;
		ResultSet resultSet = null;
		ResultSetMetaData metaData = null;
		Connection dbConn = getDBConnection();
		// Execute a query
		stmt = dbConn.createStatement();
		resultSet = stmt.executeQuery(sqlQuery);
		metaData = resultSet.getMetaData();

		int columns = metaData.getColumnCount();
		List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		while (resultSet.next()) {
			HashMap<String, Object> row = new HashMap<String, Object>(columns);
			for (int i = 1; i <= columns; ++i) {
				row.put(metaData.getColumnName(i), resultSet.getObject(i));
			}
			list.add(row);
			System.out.println("list size " + list.get(0).size());
			for (Map<String, Object> tblRow : list) {
				for (Map.Entry<String, Object> rowEntry : tblRow.entrySet()) {
					System.out.print(rowEntry.getKey() + " = " + rowEntry.getValue() + ", ");
				}
			}
		}

		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception l_ex) {
				throw new RuntimeException(l_ex);
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception l_ex) {
				throw new RuntimeException(l_ex);
			}
		}

		if (dbConn != null) {
			try {
				dbConn.close();
			} catch (Exception l_ex) {
				throw new RuntimeException(l_ex);
			}
		}
		return list;
	}

	/*******************************************************************************
	 * Method to execute a delete query and return the count of updated records
	 */
	public static int deleteQuery(String sqlQuery)
			throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
		Statement stmt = null;
		Connection dbConn = getDBConnection();
		int deletedRecordcount;
		// Execute a query
		stmt = dbConn.createStatement();

		deletedRecordcount = stmt.executeUpdate(sqlQuery);

		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception l_ex) {
				throw new RuntimeException(l_ex);
			}
		}

		if (dbConn != null) {
			try {
				dbConn.close();
			} catch (Exception l_ex) {
				throw new RuntimeException(l_ex);
			}
		}
		return deletedRecordcount;
	}

	/*******************************************************************************
	 * Method to execute a insert query and gets the inserted record id
	 */
	public static int insertQuery(String sqlQuery)
			throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
		Statement stmt = null;
		Connection dbConn = getDBConnection();
		// Execute a query
		stmt = dbConn.createStatement();

		stmt.executeUpdate(sqlQuery, Statement.RETURN_GENERATED_KEYS);
		try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
			if (generatedKeys.next()) {
				return generatedKeys.getInt(1);
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception l_ex) {
					throw new RuntimeException(l_ex);
				}
			}

			if (dbConn != null) {
				try {
					dbConn.close();
				} catch (Exception l_ex) {
					throw new RuntimeException(l_ex);
				}
			}

			return generatedKeys.getInt(1);
		}
	}
}
