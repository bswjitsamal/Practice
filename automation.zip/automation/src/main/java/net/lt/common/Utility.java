package net.lt.common;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.fortuna.ical4j.data.CalendarBuilder;
import net.fortuna.ical4j.model.Component;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.Version;

/*******************************************************************************
 * Common page class to use in all page classes
 */
public class Utility {

	protected WebDriver driver;
	protected WebDriverWait wait;

	public Utility(WebDriver a_driver) {
		wait = new WebDriverWait(a_driver, Constants.TIME_OUT);
		this.driver = a_driver;
	}

	/**
	 * Method to make the script to wait until the Java script is loaded and in
	 * ready state
	 */
	public void waitUntilJavaScriptLoads() {
		JavascriptExecutor jsExec = (JavascriptExecutor) driver;
		ExpectedCondition<Boolean> jsLoad = driver -> ((JavascriptExecutor) driver)
				.executeScript("return document.readyState").toString().equals("complete");

		// Get JS is Ready
		boolean jsReady = (Boolean) jsExec.executeScript("return document.readyState").toString().equals("complete");

		if (!jsReady) {
			System.out.println("JavaScript is not loaded completely");
			// Wait for Javascript to load
			wait.until(jsLoad);
		} else {
			System.out.println("JavaScript is loaded completely");
		}
	}

	/**
	 * Method to wait for the angular load
	 */
	public void waitForAngularLoad() {

		JavascriptExecutor jsExec = (JavascriptExecutor) driver;

		String angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";

		// Wait for ANGULAR to load
		ExpectedCondition<Boolean> angularLoad = driver -> Boolean
				.valueOf(((JavascriptExecutor) driver).executeScript(angularReadyScript).toString());

		// Get Angular is Ready
		boolean angularReady = Boolean.valueOf(jsExec.executeScript(angularReadyScript).toString());

		// Wait ANGULAR until it is Ready!
		if (!angularReady) {
			System.out.println("ANGULAR is NOT loaded");
			// Wait for Angular to load
			wait.until(angularLoad);
		} else {
			System.out.println("ANGULAR is loaded");
		}
	}

	/**
	 * Method to make the script to wait until the element is present in the
	 * application
	 */
	public WebElement waitForElement(By locator) {
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			return driver.findElement(locator);
		} catch (Exception l_ex) {
			throw new RuntimeException(l_ex);
		}
	}

	/**
	 * Method to make the script to wait until the element is present in the
	 * application
	 * @param a_xpath
	 * @return
	 */
	public WebElement waitForElement(String a_xpath) {
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(a_xpath)));
			return driver.findElement(By.xpath(a_xpath));
		} catch (Exception l_ex) {
			throw new RuntimeException(l_ex);
		}
	}

	/**
	 * Method to make the script to wait until the element is clickable in the
	 * application
	 */
	public WebElement waitForElementToBeClickable(By locator) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(locator));			
			return driver.findElement(locator);
		} catch (Exception l_ex) {
			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(locator));
				return driver.findElement(locator);
			} catch (Exception l_ex1) {				
				throw new RuntimeException(l_ex1);
			}

		}
	}

	/**
	 * Method to make the script to wait until the element is clickable in the
	 * application
	 */
	public WebElement waitForElementToBeClickable(WebElement element) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(element));			
			return element;
		} catch (Exception l_ex) {
			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(element.getAttribute("xpath"))));
				return element;
			} catch (Exception l_ex1) {				
				throw new RuntimeException(l_ex1);
			}

		}
	}

	/**
	 * Method to make the script to wait until the element is clickable in the
	 * application
	 */
	public WebElement waitForElementToBeClickable(String a_xpath) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(a_xpath)));
			return driver.findElement(By.xpath(a_xpath));
		} catch (Exception l_ex) {
			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(a_xpath)));
				return driver.findElement(By.xpath(a_xpath));
			} catch (Exception l_ex1) {
				throw new RuntimeException(l_ex1);
			}
		}
	}

	/**
	 * Method to make the script to wait until the element is clickable in the
	 * application
	 * returns list of webelements
	 */
	public List<WebElement> waitForElementsToBeClickable(String a_xpath) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath(a_xpath)));
			return driver.findElements(By.xpath(a_xpath));
		} catch (Exception l_ex) {
			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(a_xpath)));
				return driver.findElements(By.xpath(a_xpath));
			} catch (Exception l_ex1) {
				throw new RuntimeException(l_ex1);
			}
		}
	}

	/**
	 * Method to make the script to wait until the element is displayed / visible in
	 * the application
	 */
	public WebElement waitForElementToBeVisible(By locator) {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return driver.findElement(locator);
		} catch (Exception l_ex) {
			throw new RuntimeException(l_ex);
		}
	}

	/**
	 * Method to make the script to wait until the element is displayed / visible in
	 * the application
	 * @param element
	 * @return list of webelements
	 */
	public List<WebElement> waitForElementsToBeVisible(By locator) {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return driver.findElements(locator);
		} catch (Exception l_ex) {
			throw new RuntimeException(l_ex);
		}
	}

	/**
	 * Method to make the script to wait until the element is displayed / visible in
	 * the application
	 */
	public WebElement waitForElementToBeVisible(String a_xpath) {
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(a_xpath)));
			return driver.findElement(By.xpath(a_xpath));
		} catch (Exception l_ex) {
			throw new RuntimeException(l_ex);
		}
	}

	/**
	 * Method to Switch to frame/mulitple frames
	 */
	public void switchMultipleFrames(String a_frame) {
		try {
			String[] l_arrframes = a_frame.split(",");
			for (int l_val = 0; l_val < l_arrframes.length; l_val++) {
				if (l_arrframes[l_val].trim().length() == 1) {
					driver.switchTo().frame(Integer.parseInt(l_arrframes[l_val].trim()));
				} else {
					driver.switchTo().frame(l_arrframes[l_val].trim());
				}
			}
		} catch (Exception l_ex) {
			throw new RuntimeException(l_ex);
		}
	}

	/**
	 * Method to click hidden elements using java script executor
	 */
	public void clickHiddenElement(WebElement element) {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);

	}

	/**
	 * Method to verifyPageTitle
	 */
	public void verifyPageTitle(String expPageTitle) {

		wait.until(ExpectedConditions.titleContains(expPageTitle));
		try {
			Assert.assertEquals("Verify Landing Page Title", expPageTitle, driver.getTitle());
		} catch (AssertionError e) {
			Assert.assertTrue("Verify Landing Page Title", driver.getTitle().contains(expPageTitle));
		}
	}

	/**
	 * Method to wait for specific time
	 * @param a_ms_wait
	 */
	public void wait(int a_ms_wait) {
		a_ms_wait = a_ms_wait * 1000;
		try {
			Thread.sleep(a_ms_wait);
		} catch (InterruptedException l_ex) {
			l_ex.printStackTrace();
		}
	}	

	/**
	 * Method to wait for an element to be clickable and click on the element
	 * @param element
	 */
	public void waitAndClickElement(WebElement element) {

		boolean clicked = false;
		int attempts = 0;
		while (!clicked && attempts < 20) {
			try {
				clickElement(element);
				System.out.println("Successfully clicked on the WebElement: " + "<" + element.toString() + ">");
				wait(5);
				clicked = true;
			} catch (Exception e) {
				System.out.println("Unable to wait and click on WebElement, Exception: " + e.getMessage());
				Assert.assertFalse(
						"Unable to wait and click on the WebElement, using locator: " + "<" + element.toString() + ">",
						true);
			}
			attempts++;
		}

	}

	/**
	 * Method to refresh the browser
	 * @param noOfTimesBrowserNeedsToBerefreshed
	 */
	public void browserRefresh(int noOfTimesBrowserNeedsToBerefreshed) {

		for (int i = 0; i <= noOfTimesBrowserNeedsToBerefreshed; i++) {
			driver.navigate().refresh();
			System.out.println("The browser is getting refresh" + i + "time");
		}

	}

	/**
	 * Method to wait for an element to be clickable and click on the element
	 * @param locator
	 */
	public void waitAndClickElement(By locator) throws InterruptedException {

		boolean clicked = false;
		int attempts = 0;
		List<WebElement> btnAvlElement = driver.findElements(locator);
		for (WebElement btnAvlEle : btnAvlElement) {
			String text = btnAvlEle.getText();
			if (!(text.equalsIgnoreCase("Reserved"))) {

				while (!clicked && attempts < 15) {
					try {

						this.wait.until(ExpectedConditions.elementToBeClickable(btnAvlEle)).click();
						System.out
						.println("Successfully clicked on the WebElement: " + "<" + btnAvlEle.toString() + ">");
						clicked = true;
					} catch (Exception e) {
						System.out.println("Unable to wait and click on WebElement, Exception: " + e.getMessage());
						Assert.assertFalse("Unable to wait and click on the WebElement, using locator: " + "<"
								+ btnAvlEle.toString() + ">", true);
					}
					attempts++;
				}
				break;

			}
		}
	}

	/**
	 * Method to check if the event if paid or free
	 * @param element
	 * @throws InterruptedException
	 */
	public void checkEvent(By element) throws InterruptedException {

		boolean clicked = false;
		int attempts = 0;
		List<WebElement> btnAvlElement = driver.findElements(element);
		for (WebElement btnAvlEle : btnAvlElement) {
			System.out.println("List of items are -->" + btnAvlEle);
			// Clicking on the element
			btnAvlEle.click();

			// Navigating to details page
			String text = driver.findElement(By.xpath("//header//strong[contains(.,'$')]")).getText();
			System.out.println("The price is " + text);
			if ((text.startsWith("$")) == false) {

				while (!clicked && attempts < 5) {
					try {

						driver.findElement(By.xpath("//header//button[text()='Reserve']")).click();
						clicked = true;
						System.out.println("Found and clicked on the reserve button ");
					} catch (Exception e) {
						driver.navigate().back();
						System.out.println("Not Found and unable to click ");

					}
					attempts++;
				}
				break;
			} else {
				driver.navigate().back();
			}
		}
	}

	/*public void checkAndClickElement(List<WebElement> elements, WebElement cancelLink, WebElement reserveButton)
			throws InterruptedException {

		boolean clicked = false;
		int attempts = 0;

		// List<WebElement> btnAvlElement = driver.findElements(By.xpath(elements));
		for (WebElement btnAvlEle : elements) {

	 * String text = btnAvlEle.getText(); if (!(text.equalsIgnoreCase("Reserved")))
	 * {
	 * 
			  while (!clicked && attempts < 12) {
				try {

					this.wait.until(ExpectedConditions.elementToBeClickable(btnAvlEle)).click();

					// Verify the reserve button/cancel link present as the user is on class details
					// page.

					String actualText = cancelLink.getText();
					String expText = "Cancel Reservation";

					if (actualText.contains(expText)) {
						System.out.println("Expected text " + expText + " Present in the web page");
						Log.info("Expected text " + expText + " Present in the web page");
						browserBack();

					} else {

						this.wait.until(ExpectedConditions.elementToBeClickable(reserveButton)).click();
						System.out.println(
								"Successfully clicked on the WebElement: " + "<" + reserveButton.toString() + ">");
						Log.info("Successfully clicked on the WebElement: " + "<" + reserveButton.toString() + ">");
						clicked = true;

					}
				} catch (Exception e) {
					System.out.println("Unable to wait and click on WebElement, Exception: " + e.getMessage());
				}
				attempts++;
			}
			break;

		}
	}*/
	// }

	/*public void _waitAndClickElement(String btnAvl) throws InterruptedException {

		boolean clicked = false;
		int attempts = 0;
		List<WebElement> btnAvlElement = driver.findElements(By.xpath(btnAvl));
		for (WebElement btnAvlEle : btnAvlElement) {
			String text = btnAvlEle.getText();
			if (!(text.equalsIgnoreCase("Reserved"))) {

				while (!clicked && attempts < 15) {
					try {

						this.wait.until(ExpectedConditions.elementToBeClickable(btnAvlEle)).click();
						System.out
								.println("Successfully clicked on the WebElement: " + "<" + btnAvlEle.toString() + ">");
						Log.info("Successfully clicked on the WebElement: " + "<" + btnAvlEle.toString() + ">");
						clicked = true;
					} catch (Exception e) {
						System.out.println("Unable to wait and click on WebElement, Exception: " + e.getMessage());
						Log.info("Unable to wait and click on WebElement, Exception: " + e.getMessage()
								+ btnAvlEle.toString());
						Assert.assertFalse("Unable to wait and click on the WebElement, using locator: " + "<"
								+ btnAvlEle.toString() + ">", true);
					}
					attempts++;
				}
				break;

			}
		}
	}*/

	/**
	 * Method to enter text
	 * @param e
	 * @param text
	 */
	public void enterText(WebElement element, String text) {
		try {
			element.sendKeys(text);
		} catch (Exception ex) {
			try {
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].value='" + text + "';", element);
			} catch (Exception exp) {
				ex.printStackTrace();
			}
		}

	}

	/*	public void isTextPresent(String expText) {

		// System.out.println(driver.getPageSource().contains("actualText"));
		String sctualText = driver.findElement(By.xpath("//ul[@class='list-unstyled reservation-list']")).getText();

		if (sctualText.contains(expText)) {
			System.out.println("Expected text " + expText + " Present in the web page");
			Log.info("Expected text " + expText + " Present in the web page");
		} else {
			System.out.println("Expected text " + expText + " is not Present in the web page");
			Log.info("Expected text " + expText + " is not Present in the web page");
		}

	}

	public boolean isTextPresent_(String expText) {

		// System.out.println(driver.getPageSource().contains("actualText"));
		String sctualText = driver.findElement(By.xpath("//ul[@class='list-unstyled reservation-list']")).getText();

		if (sctualText.contains(expText)) {
			System.out.println("Expected text " + expText + " Present in the web page");
			Log.info("Expected text " + expText + " Present in the web page");
			return true;
		} else {
			System.out.println("Expected text " + expText + " is not Present in the web page");
			Log.info("Expected text " + expText + " is not Present in the web page");
			return false;
		}

	}*/

	/**
	 * Method to verify whether the text is present in the page
	 * @param text
	 */
	public Boolean isElementPresent(String text) {

		if (driver.getPageSource().contains(text)) {
			System.out.println("Expected text " + text + " Present in the web page");
			return true;
		} else {
			System.out.println("Expected text " + text + " is not Present in the web page");
			return false;
		}

	}

	/**
	 * Method to verify whether the text is present
	 * @param element
	 * @param expText
	 * @return
	 */
	public Boolean isTextPresent(WebElement element, String expText) {
		String actualText = element.getText();

		if (actualText.contains(expText)) {
			System.out.println("Expected text " + expText + " Present in the web page");

			return true;
		} else {
			System.out.println("Expected text " + expText + " is not Present in the web page");
			return false;
		}

	}

	/**
	 * Method to verify whether the text is present and clicking that element
	 * @param element
	 * @param expText
	 * @return
	 */
	public Boolean isTextPresentAndClickText(WebElement element, String expText) {
		String actualText = element.getText();

		if (actualText.contains(expText)) {
			System.out.println("Expected text " + expText + " Present in the web page");
			element.click();
			return true;
		} else {
			System.out.println("Expected text " + expText + " is not Present in the web page");
			return false;
		}

	}

	/**
	 * Method to verify whether the text is present
	 * @param element
	 * @param expText
	 * @return
	 */
	public Boolean isTextPresent(By locator, String expText) {
		WebElement element = driver.findElement(locator);
		String actualText = element.getText();

		if (actualText.indexOf(expText) != -1 ? true : false) {
			System.out.println("Expected text " + expText + " Present in the web page");
			return true;
		} else {
			System.out.println("Expected text " + expText + " is not Present in the web page");
			return false;
		}

	}

	/**
	 * Method to verify whether the element is present
	 * @param element
	 * @return
	 */
	public Boolean isElementPresent(By locator) {		
		Boolean isPresent = driver.findElements(locator).size() > 0;
		if (isPresent) {
			System.out.println("Element is present");
			return true;
		} else {
			System.out.println("Element is not present");
			return false;
		}	
	}


	/**
	 * Method to verify whether the element is present
	 * @param element
	 * @return
	 */
	public Boolean isElementPresent(WebElement element) {
		try
		{
			if(element.isDisplayed())
			{			
				return true;
			} else {				
				return false;
			}
		}
		catch(Exception e)
		{
			return false;
		}
	}

	/**
	 * Method to compare array of text
	 * @param actualText
	 * @param expText
	 */
	public void compareArrayOfText(ArrayList<String> actualText, ArrayList<String> expText) {

		for (String expected : actualText) {
			if (expText.contains(expected)) {
				System.out.println("Search function verified");
			} else {
				System.out.println("Search function verification failed");
			}
		}

	}

	/**
	 * Select value from dropdown
	 * @param element
	 */
	public void selectFromDropDown(WebElement element) {

		WebElement drpDwnList = element;

		// Using Select Class to fetch the count
		Select objSel = new Select(drpDwnList);
		List<WebElement> weblist = objSel.getOptions();

		// Taking the count of items
		int iCnt = weblist.size();

		// Using Random class to generate random values
		Random num = new Random();
		int iSelect = num.nextInt(iCnt);

		// Selecting value from DropDownList
		objSel.selectByIndex(iSelect);
		if (iSelect == 0) {
			iSelect++;
			objSel.selectByIndex(iSelect);
		}
		// Selected Value
		System.out.println("--->" + drpDwnList.getAttribute("value"));
	}

	//select the dropdown using "select by visible text", so pass VisibleText as 'Yellow' to funtion
	public void fn_Select(WebElement WE, String VisibleText){
		Select selObj=new Select(WE);
		selObj.selectByVisibleText(VisibleText);
	}

	//select the dropdown using "select by index", so pass IndexValue as '2'
	public void fn_Select(WebElement WE, int IndexValue){
		Select selObj=new Select(WE);
		selObj.selectByIndex(IndexValue);
	}

	//select the dropdown using "select by value", so pass Value as 'thirdcolor'
	/*public void fn_Select(WebElement WE, String Value){
	Select selObj=new Select(WE);
	selObj.selectByValue(Value);
	}
	 */
	/**
	 * method to compare the value if its between max and min values
	 * @param value
	 * @param min
	 * @param max
	 * @return
	 */
	public boolean isBetween(int value, int min, int max) {
		return ((value > min) && (value < max));
	}

	/**
	 * Method to get the list of values
	 * @param element
	 * @return
	 */
	public ArrayList<String> getValue(By element) {

		String text = null;
		ArrayList<String> allValues = new ArrayList<String>();
		List<WebElement> btnAvlElement = driver.findElements(element);

		for (WebElement btnAvlEle : btnAvlElement) {
			text = btnAvlEle.getText();
			System.out.println("-->" + text);

			allValues.add(text);
		}

		System.out.println(allValues);
		return allValues;
	}

	/**
	 * Method to read from Calendar (.ics file)
	 * @param file
	 * @return
	 * @throws Exception
	 */
	public String getCalInfoFromIcs(File file) throws Exception {

		net.fortuna.ical4j.model.Calendar calendar = new net.fortuna.ical4j.model.Calendar();
		calendar.getProperties().add(new ProdId("-//Ben Fortuna//iCal4j 1.0//EN"));
		calendar.getProperties().add(Version.VERSION_2_0);
		calendar.getProperties().add(CalScale.GREGORIAN);

		FileInputStream fin = new FileInputStream(file);
		CalendarBuilder builder = new CalendarBuilder();
		calendar = builder.build(fin);
		List result = new ArrayList<String>();

		for (Iterator i = calendar.getComponents().iterator(); i.hasNext();) {
			Map<String, String> calenderinfo = new HashMap<String, String>();
			Component component = (Component) i.next();

			for (Iterator j = component.getProperties().iterator(); j.hasNext();) {
				try {
					String startdate = null, enddate = null, event = null, description = null;
					Property property = (Property) j.next();
					if ("DTSTART".equals(property.getName())) {
						startdate = property.getValue();
						calenderinfo.put("startDate", modifyDateLayoutOfIcs(startdate));
					}
					if ("DTEND".equals(property.getName())) {
						enddate = property.getValue();
						calenderinfo.put("endDate", modifyDateLayoutOfIcs(enddate));
					}
					if ("SUMMARY".equals(property.getName())) {
						event = property.getValue();
						calenderinfo.put("event", event);
					}

					if ("DESCRIPTION".equals(property.getName())) {
						description = property.getValue();
						calenderinfo.put("Description", description);
					}

					if (!calenderinfo.isEmpty()) {
						if (calenderinfo.get("event") != null) {
							result.add(calenderinfo);
						}
					}
				} catch (Exception ex) {

				}
			}
		}
		return result.toString();
	}

	/**
	 * Method to modify the date layout of calendar
	 * @param inputDate
	 * @return
	 */
	private String modifyDateLayoutOfIcs(String inputDate) {
		try {

			SimpleDateFormat inDateFormat = new SimpleDateFormat("yyyyMMdd");
			java.util.Date fromDate = inDateFormat.parse(inputDate);

			SimpleDateFormat outDateForm = new SimpleDateFormat("dd-MMM-yyyy");
			return outDateForm.format(fromDate);
		} catch (Exception e) {
			return inputDate;
		}

	}

	/**
	 * Method to get the last modified file from the directory
	 * @param dir
	 * @return
	 */
	public File lastFileModified(String dir) {
		File fl = new File(dir);
		File[] files = fl.listFiles(new java.io.FileFilter() {
			public boolean accept(File file) {
				return file.isFile();
			}
		});
		long lastMod = Long.MIN_VALUE;
		File choice = null;
		for (File file : files) {
			if (file.lastModified() > lastMod) {
				choice = file;
				lastMod = file.lastModified();
			}
		}
		return choice;
	}

	/**
	 * Method to click Element
	 * @param element
	 */
	public void clickElement(WebElement element) {
		try {
			element.click();

		} catch (Exception e) {
			try {
				clickHiddenElement(element);
			} catch (Exception ex) {
				{
					ex.printStackTrace();
				}
			}
		}
	}

	/**
	 * Method to click element using locator
	 * @param locator
	 */
	public void clickElement(By locator) {
		try {
			WebElement element = waitForElement(locator);
			element.click();
		} catch (Exception e) {
			try {
				clickHiddenElement(waitForElement(locator));
			} catch (Exception ex) {
				{
					ex.printStackTrace();
				}
			}
		}
	}

	/**
	 * Method to select a radio button
	 * @param element
	 */
	public void selectRadioButton(WebElement element) {
		try {
			System.out.println("" + element.getAttribute("checked"));
			if (element.getAttribute("checked") == null) {
				element.click();
			} else if (element.getAttribute("checked") == "checked") {
				System.out.println("Radio button is already checked");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}




	public void waitUntilSpinnerDisappears() {
		int loadingImage = 0;
		By locator = By.xpath("//div[@class='spinner-overlay' and not(contains(@style,'none'))]");

		System.out.println("1" + loadingImage);
		int loopCnt = 0;
		try {
			do {
				if (driver.findElements(locator).size() > 0) {
					loadingImage = 1;
					loopCnt = loopCnt + 1;
				} else {
					loadingImage = 0;
					System.out.println("2" + loadingImage);
					break;

				}

			} while (loadingImage == 1 && loopCnt < 200);

		} catch (Exception l_ex) {
			System.out.println("5" + loadingImage);
		}
	}

	/*
	public static void status(WebElement element) {
		try {
			Log.info("Step Executed Successfully" + element);
		} catch (Exception e) {
			Log.info("Step Not Executed Successfully" + element);
			System.out.println(e);
		}
	}*/

	/**
	 * Method to get the newly created file
	 * @param filePath
	 * @param ext
	 * @param driver
	 * @param capabilities
	 * @param className
	 * @return
	 */
	public static File getTheNewestFile(String filePath, String ext, WebDriver driver, Capabilities capabilities,
			String className) {

		Utility util = new Utility(driver);
		JavascriptExecutor jse = (JavascriptExecutor) driver;

		if (capabilities.getCapability("platform").toString() == "XP"
				&& capabilities.getCapability("webdriver.remote.sessionid") != null) {
			util.wait(10);

			// check if file exists
			System.out.println(jse.executeScript(
					"browserstack_executor: {\"action\": \"fileExists\", \"arguments\": {\"fileName\": \"" + className
					+ ext + "\"}}"));

			// Download the file
			String base64EncodedFile = (String) jse.executeScript(
					"browserstack_executor: {\"action\": \"getFileContent\", \"arguments\": {\"fileName\": \""
							+ className + ext + "\"}}");
			byte[] data = Base64.getDecoder().decode(base64EncodedFile);
			OutputStream stream;
			try {
				stream = new FileOutputStream(filePath + "\\" + className + ext);
				try {
					stream.write(data);
				} catch (IOException e) {
					e.printStackTrace();
				}

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

		File theNewestFile = null;
		File dir = new File(filePath);
		FileFilter fileFilter = new WildcardFileFilter("*." + ext);
		File[] files = dir.listFiles(fileFilter);

		if (files.length > 0) {
			/** The newest file comes first **/
			Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
			theNewestFile = files[0];
			System.out.println(theNewestFile);
		}

		return theNewestFile;
	}

	/*public void browserBack() {
		driver.navigate().back();

	}*/

	/**
	 * Method to dismiss the alert
	 */
	public void alertDismiss() {
		if (isAlertPresent()) {
			driver.switchTo().alert().dismiss();
		}
	}

	/**
	 * Method to verify whether a alert is present
	 * @return
	 */
	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception Ex) {
			return false;
		}
	}

	/**
	 * Method to convert the date string to required date format
	 * @param strDate
	 * @param dateFormat
	 * @return
	 */
	public static Date dateFormatter(String strDate, String dateFormat) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			Date date = sdf.parse(strDate);

			return date;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Method to convert the date to string
	 * @param date
	 * @param dateFormat
	 * @return
	 */
	public static String dateToStringConverter(Date date, String dateFormat) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			String strFormattedDate = sdf.format(date);
			System.out.println("" + strFormattedDate);
			return strFormattedDate;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Method to accept Alert if it's present
	 */
	public void acceptIfAlertPresent() {
		try {
			if (ExpectedConditions.alertIsPresent() != null) {
				driver.switchTo().alert().accept();
			}
		} catch (Exception l_exception) {

		}
	}

	/**
	 * This method reads the Json files
	 * @param filename
	 * @return
	 */
	public JSONObject readJsonFile(String filename) {
		try {
			JSONParser parser = new JSONParser();
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream is = classloader.getResourceAsStream(filename);
			Object object = parser.parse(new InputStreamReader(is));
			// convert Object to JSONObject
			JSONObject jsonObject = (JSONObject) object;

			// Reading the String
			String build_url = (String) jsonObject.get("build_url");
			System.out.println("build_url: " + build_url);
			return jsonObject;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Method to get the SSOId required for API calls
	 * @param Auth
	 * @param userName
	 * @param password
	 * @return
	 */
	public String getSSOId(RequestSpecification Auth, String userName, String password) {
		JSONObject jobj = new JSONObject();
		jobj.put("username", userName);
		jobj.put("password", password);
		Auth.body(jobj);
		Response postResponse = Auth.when().post(RestAssured.baseURI + "/auth/login");
		return getJsonResponse(postResponse, "ssoid");

	}

	/**
	 * This method gets the Json Response
	 * @param response
	 * @param key
	 * @return
	 */
	public String getJsonResponse(Response response, String key) {
		String json = response.getBody().asString();
		JsonPath jPath = new JsonPath(json);
		return jPath.getString(key);
	}

	/**
	 * This method gets the Device and return if it's mobile device or not
	 * @return
	 */
	public String getDevice() {
		Capabilities capabilities = ((RemoteWebDriver) driver).getCapabilities();
		if (capabilities.getCapability("deviceName") == null)
			return "NonMobile";
		else
			return "Mobile";
	}

	/**
	 * This method gets the platform the script is executing duing run time
	 * @return
	 */
	public String getPlatform() {
		Capabilities capabilities = ((RemoteWebDriver) driver).getCapabilities();
		String platform = capabilities.getCapability("platform").toString();
		return platform;
	}

	/**
	 * \ This method gets the capabilities of driver and returns them
	 * @return
	 */
	public Capabilities getCapabilities() {
		Capabilities capabilities = ((RemoteWebDriver) driver).getCapabilities();
		return capabilities;
	}

	/**
	 * This method gets the day of the week
	 * @return
	 */
	public int getDayOfWeek() {
		Calendar calendar = Calendar.getInstance();
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		return dayOfWeek;
	}

	/**
	 * Method to get the name of the day 
	 * @param dayOfWeek
	 * @return
	 */
	public String getWeekDayName(int dayOfWeek) {
		DateFormatSymbols dfs = new DateFormatSymbols();
		return dfs.getWeekdays()[dayOfWeek];
	}

	/**
	 * This method adds days to date
	 * @param days
	 * @return
	 */
	public int addDaysToDate(int days) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, days);
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		return dayOfMonth;
	}

	/**
	 * This method gets the random integer and returns as a string
	 * @return
	 */
	public String getRandomIntegerAsString() {

		Random rand = new Random();
		// Generate random integers in range 0 to 999
		int rand_int1 = rand.nextInt(1000);
		String numberAsString = Integer.toString(rand_int1);
		return numberAsString;
	}

	/**
	 * This method deletes the calendar downloads depending up on the class name
	 * @param capabilities
	 * @param className
	 */
	public void deleteCalendarDownloads(Capabilities capabilities, String className) {
		String filePath = "";
		try {
			if (capabilities.getCapability("platform").toString() == "XP") {
				filePath = System.getenv("USERPROFILE") + "\\Downloads\\" + className + ".ics";
			} else if (capabilities.getCapability("webdriver.remote.sessionid") != null
					&& capabilities.getCapability("platform").toString() == "MAC") {
				filePath = "/Users/test1/Downloads/" + className + ".ics";
			}

			File file = new File(filePath);
			file.delete();

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * This method validates that the calendar download has all the correct data or not.
	 * @param capabilities
	 * @param className
	 */
	public void validateAddToCalendar(Capabilities capabilities, String className) {
		Utility util = new Utility(driver);
		String filePath = System.getenv("USERPROFILE") + "\\Downloads";
		String ext = "ics";
		try {
			if (capabilities.getCapability("platform").toString() == "XP") {
				filePath = System.getenv("USERPROFILE") + "\\Downloads";
			} else if (capabilities.getCapability("webdriver.remote.sessionid") != null
					&& capabilities.getCapability("platform").toString() == "MAC") {
				filePath = "/Users/test1/Downloads";
			}

			String result = util
					.getCalInfoFromIcs(Utility.getTheNewestFile(filePath, ext, driver, capabilities, className));
			System.out.println(result);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Method to insert string
	 * @param originalString
	 * @param stringToBeInserted
	 * @param index
	 * @return
	 */
	public String insertString(String originalString, String stringToBeInserted, int index) {

		// Create a new string
		String newString = originalString.substring(0, index + 1) + stringToBeInserted
				+ originalString.substring(index + 1);

		// return the modified String
		return newString;
	}



	String pattern = "EEEE, MMM dd";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);



	String date = simpleDateFormat.format(new Date());
	// System.out.println(date);




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		getFormattedDate(new Date(), "EEEE, MMM dd");

		Calendar cal = Calendar.getInstance(); 
		cal.add(Calendar.DATE, 90);
		Date newdate = cal.getTime();
		getFormattedDate(newdate, "EEEE, MMM dd");

	}

	public static String getFormattedDate(Date newdate, String pattern)
	{


		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);



		String date = simpleDateFormat.format(newdate);
		System.out.println(date);
		return date;
	}


	public String getElementColor(WebElement element)
	{

		String color = element.getCssValue("color");
		String ColorInHex = Color.fromString(color).asHex();
		System.out.println(""+ColorInHex);
		return ColorInHex;
	}


	public void selectDropdownValue(WebElement element, String OptionToSelect) {
		try {

			Select selObj = new Select(element);
			if(OptionToSelect.isEmpty())
			{
				selObj.selectByIndex(1);
			}else
			{
				selObj.selectByVisibleText(OptionToSelect);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void selectDropdownValue(By locator, String OptionToSelect) {
		try {
			WebElement element = driver.findElement(locator);
			Select selObj = new Select(element);
			selObj.selectByVisibleText(OptionToSelect);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void selectDropdownValue(WebElement element, int index) {
		try {
			Select selObj = new Select(element);
			selObj.selectByIndex(index);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public int getDropDownCount(WebElement element) {
		try {
			Select selObj = new Select(element);
			List<WebElement> valueList = selObj.getOptions();
			return valueList.size();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}



	public String getEndTime(String startTime, int duration) throws ParseException
	{
		SimpleDateFormat df = new SimpleDateFormat("HH:mm");
		java.util.Date d;
		d = df.parse(startTime);
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.add(Calendar.MINUTE, duration);
		String newTime = df.format(cal.getTime());
		System.out.println("NewTime: " + newTime);
		String NewTime = newTime.toString();
		String endTime = NewTime.substring(1);
		return endTime;
	}




}