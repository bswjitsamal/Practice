package net.lt.common;

import java.util.Properties;

import net.lt.config.EnvConfig;

/*******************************************************************************
 * Maintains all SQL constants in this class
 */
public interface SQLConstants {
	/*******************************************************************************
	 * Name of the SQL constants maintained here
	 ******************************************************************************/
	public static Properties SQL_PROPERTIES = EnvConfig.getInstance().getSqlProperties();
	public static final String CREATE_EVENT_SQL = SQL_PROPERTIES.getProperty("CREATE_EVENT_SQL");
	public static final String DELETE_EVENT_SQL = SQL_PROPERTIES.getProperty("DELETE_EVENT_SQL");
}
