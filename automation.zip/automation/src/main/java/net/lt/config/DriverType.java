package net.lt.config;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public enum DriverType implements DriverSetup {


	FIREFOX {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			FirefoxOptions options = new FirefoxOptions();
			options.merge(capabilities);
			return new FirefoxDriver(options);
		}
	},
	CHROME {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			HashMap<String, Object> chromePreferences = new HashMap<>();
			chromePreferences.put("profile.password_manager_enabled", false);

			ChromeOptions options = new ChromeOptions();
			options.merge(capabilities);
			options.addArguments("--no-default-browser-check");
			options.setExperimentalOption("prefs", chromePreferences);

			return new ChromeDriver(options);
		}
	},
	IE {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			InternetExplorerOptions options = new InternetExplorerOptions();

			capabilities.setCapability( 
                     InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION,
                     true );         
			capabilities.setCapability( 
                  InternetExplorerDriver
                  .INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
                  true );
			options.merge( capabilities );
	        return new InternetExplorerDriver( options );
	        
		}
	},
	EDGE {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			EdgeOptions options = new EdgeOptions();
			options.merge(capabilities);

			return new EdgeDriver(options);
		}
	},
	SAFARI {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			SafariOptions options = new SafariOptions();
			options.merge(capabilities);

			return new SafariDriver(options);
		}
	},
	CHROME_HEADLESS {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			HashMap<String, Object> chromePreferences = new HashMap<>();
			chromePreferences.put("profile.password_manager_enabled", false);

			ChromeOptions options = new ChromeOptions();
			options.merge(capabilities);
			options.setHeadless(true);
			options.addArguments("--no-default-browser-check");
			options.setExperimentalOption("prefs", chromePreferences);

			return new ChromeDriver(options);
		}
	},
	FIREFOX_HEADLESS {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {
			FirefoxOptions options = new FirefoxOptions();
			options.merge(capabilities);
			options.setHeadless(true);

			return new FirefoxDriver(options);
		}
	},
	WINDOWS_10_CHROME {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new RemoteWebDriver(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	},
	WINDOWS_10_IE {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new RemoteWebDriver(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	},
	WINDOWS_10_FIREFOX {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new RemoteWebDriver(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	},
	WINDOWS_10_EDGE {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new RemoteWebDriver(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	},	
	WINDOWS_7_CHROME {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new RemoteWebDriver(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	},	
	IPHONE_XS_13_SAFARI {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new IOSDriver<WebElement>(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	},
	GALAXY_S9_PLUS_9_0_CHROME {
		public RemoteWebDriver getWebDriverObject(DesiredCapabilities capabilities) {  
			try {
				return new AndroidDriver<WebElement>(new URL(DriverFactory.browserstackUrl), capabilities);
			} catch (MalformedURLException e) {
				return null;
			}	                      		
		}
	}
};
