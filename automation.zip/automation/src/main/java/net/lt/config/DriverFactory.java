package net.lt.config;

import static net.lt.config.DriverType.FIREFOX_HEADLESS;
import static net.lt.config.DriverType.valueOf;
import static org.openqa.selenium.Proxy.ProxyType.MANUAL;
import static org.openqa.selenium.remote.CapabilityType.PROXY;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Rule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.remote.MobileCapabilityType;


public class DriverFactory {

	protected RemoteWebDriver driver;
	private DriverType selectedDriverType;

	private final String operatingSystem = System.getProperty("os.name").toUpperCase();
	private final String systemArchitecture = System.getProperty("os.arch");
	private final boolean proxyEnabled = Boolean.getBoolean("proxyEnabled");
	private final String proxyHostname = System.getProperty("proxyHost");
	private final Integer proxyPort = Integer.getInteger("proxyPort");
	private final String proxyDetails = String.format("%s:%d", proxyHostname, proxyPort);
	private static final String browserstackUsername = "rekhabhupatiraju2";
	private static final String browserstackPassword = "UyazqxwcwmNi2JRVH9Kf";
	public static final String browserstackUrl = "http://hub-cloud.browserstack.com/wd/hub/";
	String testName;
    Object Obj = null;

	public DriverFactory() {

		DriverType driverType = FIREFOX_HEADLESS;
		String browser = System.getProperty("browser", driverType.toString()).toUpperCase();
		try {
			driverType = valueOf(browser);
		} catch (IllegalArgumentException ignored) {
			System.err.println("Unknown driver specified, defaulting to '" + driverType + "'...");
		} catch (NullPointerException ignored) {
			System.err.println("No driver specified, defaulting to '" + driverType + "'...");
		}
		selectedDriverType = driverType;
	}

	public RemoteWebDriver getDriver() throws Exception {
		if (null == driver) {
			if(selectedDriverType.name().contains("_")
					&& !selectedDriverType.name().toUpperCase().contains("HEADLESS") )
			{
				Long session = 0L;
				int threadCount = 0;
				//Gets all the active threads
				Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
				for ( Thread t : threadSet){				
					if ( t.getThreadGroup() == Thread.currentThread().getThreadGroup() && 
							t.getName().contains("pool") ){
						//System.out.println("Thread :"+t+":"+"state:"+t.getState());
						if(t.getState().toString().contains("RUNNABLE"))
						{
							++threadCount;
						}
					}
				}			
				do
				{				
					Obj = GET("https://api.browserstack.com/automate/plan.json");
					if(Obj!= null)
					{
						JSONObject jso = (JSONObject) Obj;												 
						session = (Long) jso.get("queued_sessions");
						if(threadCount +  session >= 31)
						{
							Thread.sleep(20000);
						}						
					}
					//System.out.print("Queued Sessions in Browserstack " + session);					
				}while (threadCount +  session >= 31 && Obj == null);
			}
			instantiateWebDriver(selectedDriverType);
		}		
		return driver;
	}

	public static Object GET(String url) throws IOException
	{
		HttpURLConnection con = null;
		InputStream os;
		BufferedReader buffer = null;
		try
		{
			URL obj = new URL(url);
			con = (HttpURLConnection) obj.openConnection();			
			con.setRequestMethod("GET");			
			String authString = browserstackUsername + ":" + browserstackPassword;
			byte[] authEncBytes = Base64.encodeBase64(authString.getBytes());
			String authStringEnc = new String(authEncBytes);
			con.setRequestProperty ("Authorization", "Basic " +authStringEnc );
			con.setRequestProperty("Content-Type", "application/json");		
			con.setDoOutput(true);
			con.connect();			
			os = con.getInputStream();		
			buffer = new BufferedReader(new InputStreamReader(os));
			String inputLine;			
			inputLine = buffer.readLine();
			Object Obj = new JSONParser().parse(inputLine);				
			buffer.close();	
			con.disconnect();
			return Obj;
		}catch(Exception e)
		{			
			return null;
		}
	}

	public void quitDriver() {
		if (null != driver) {
			driver.quit();
			driver = null;
		}
	}

	private void instantiateWebDriver(DriverType driverType) throws MalformedURLException {
		System.out.println(" ");
		System.out.println("Current Operating System: " + operatingSystem);
		System.out.println("Current Architecture: " + systemArchitecture);
		System.out.println("Current Browser Selection: " + selectedDriverType);
		System.out.println(" ");

		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

		if (proxyEnabled) {
			Proxy proxy = new Proxy();
			proxy.setProxyType(MANUAL);
			proxy.setHttpProxy(proxyDetails);
			proxy.setSslProxy(proxyDetails);
			desiredCapabilities.setCapability(PROXY, proxy);
		} 

		desiredCapabilities = getCapabilities(driverType.name());      
		driver =  driverType.getWebDriverObject(desiredCapabilities);

	}

	public DesiredCapabilities getBrowserstackConfig(String OS, String OSVersion, String browser, String browserVersion)
	{
		DesiredCapabilities capability = new DesiredCapabilities();

		capability.setCapability("browser", browser);
		capability.setCapability("browser_version", browserVersion);
		capability.setCapability("resolution", "1920x1080");
		capability.setCapability("os", OS);
		capability.setCapability("os_version", OSVersion);
		capability.setCapability("name", testName);
		capability.setCapability("project","SchedReg");        
		capability.setCapability("browserstack.local", "true"); 
		capability.setCapability("browserstack.debug", "true"); 
		capability.setCapability("browserstack.user", browserstackUsername);// add username
		capability.setCapability("browserstack.key", browserstackPassword); //add automate-key


		return capability;
	}

	public DesiredCapabilities getBrowserstackMobConfig(String device, String platform,String version,String browser, boolean realDevice )
	{
		DesiredCapabilities capability = new DesiredCapabilities();

		capability.setCapability(MobileCapabilityType.BROWSER_NAME, browser);
		capability.setCapability(MobileCapabilityType.PLATFORM_VERSION, version);
		capability.setCapability("platformVersion", version);
		capability.setCapability("platformName", platform); 
		capability.setCapability("deviceName", device); 
		capability.setCapability("name", testName); 		
		capability.setCapability("project","SchedReg");		 
		capability.setCapability("realMobile", realDevice); 
		capability.setCapability("browserstack.local", "true"); 
		capability.setCapability("browserstack.debug", "true"); 
		capability.setCapability("browserstack.user", browserstackUsername);// add username
		capability.setCapability("browserstack.key", browserstackPassword); //add automate-key
		
		return capability;
	}


	@Rule
	public TestWatcher watcher = new TestWatcher()
	{
		@Override
		protected void starting(Description description)
		{
			testName = description.getDisplayName();
		}
	};

	public DesiredCapabilities getCapabilities(String browserName)
	{
		DesiredCapabilities capabilities = new DesiredCapabilities();     
		switch (browserName.toUpperCase()) {
		case "CHROME_HEADLESS" : 
			break;

		case "FIREFOX_HEADLESS" :
			break;

		case "CHROME" : 
			break;

		case "FIREFOX" : 
			break;

		case "EDGE" : 
			break;

		case "IE" :
			break;

		case "SAFARI" : 
			break;

		case "WINDOWS_10_CHROME" : 
			capabilities = getBrowserstackConfig("windows","10", "chrome","");
			break;

		case "WINDOWS_10_FIREFOX" : 
			capabilities = getBrowserstackConfig("windows","10", "firefox","");
			break;

		case "WINDOWS_10_EDGE" : 
			capabilities = getBrowserstackConfig("windows","10", "Edge","");	
			break;

		case "WINDOWS_10_IE" : 
			capabilities = getBrowserstackConfig("windows","10", "ie","");
			break;

		case "WINDOWS_7_CHROME" : 
			capabilities = getBrowserstackConfig("windows","7", "chrome","");
			break;

		case "GALAXY_S9_8_0_CHROME" : 
			capabilities = getBrowserstackMobConfig("Samsung Galaxy S9","Android", "8.0", "chrome", true);
			break;
			
		case "GALAXY_S9_PLUS_9_0_CHROME" : 
			capabilities = getBrowserstackMobConfig("Samsung Galaxy S9 Plus","Android", "9.0", "chrome", true);
			break;

		case "IPHONE_XS_13_SAFARI" : 
			capabilities = getBrowserstackMobConfig("iPhone XS","iOS", "13", "safari", true);
			break;		

		case "OS_X_SIERRA" : 
			capabilities = getBrowserstackConfig("OS X","Sierra", "Safari", "");
			break;

		case "IPAD_6TH_11_3_SAFARI" : 
			capabilities = getBrowserstackMobConfig("iPad 6th","iOS", "", "safari", true);
			break;

		case "IPAD_PRO_13_SAFARI" : 
			capabilities = getBrowserstackMobConfig("iPad Pro 12.9 2018","iOS", "13", "safari", true);
			break;
			
			
			
		default: capabilities = getBrowserstackConfig("windows","10", "chrome","");
		break;
		}
		return capabilities;
	}

}
