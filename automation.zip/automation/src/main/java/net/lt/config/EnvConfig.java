package net.lt.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;



public class EnvConfig {

	private final static EnvConfig INSTANCE = new EnvConfig();
	private String envitonmentPrefix;
	private String environment;

	Properties envProperties, sqlProperties;

	private EnvConfig() {
		// Private Constructor		

		setupEnvironmentPrefix();
		loadEnvironmentProperties();
		loadSqlProperties();
	}

	public static final EnvConfig getInstance() {
		return INSTANCE;
	}

	private void setupEnvironmentPrefix() {
		environment = System.getProperty("env");
		switch (environment) {
		case "stg":
			envitonmentPrefix = "https://stg-";
			break;
		case "qa":
			envitonmentPrefix = "https://qa-";
			break;
		case "int":
			envitonmentPrefix = "https://int-";
			break;
		case "dev":
			envitonmentPrefix = "https://dev-";
			break;
		default:
			envitonmentPrefix = "https://";
		}
	}

	public String getEnvironment() {
		return environment;
	}

	private void loadEnvironmentProperties() {
		System.out.println("loading properties");
		envProperties = new Properties();
		InputStream in = null;
		try {
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			in = classloader.getResourceAsStream(environment + ".properties");
			envProperties.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// This will load the sql properties
	private void loadSqlProperties() {
		System.out.println("loading sql properties");
		sqlProperties = new Properties();
		InputStream in = null;
		try {
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			in = classloader.getResourceAsStream("sql.properties");
			sqlProperties.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Properties getEnvProperties() {
		return envProperties;
	}

	public String getPrefix() {
		return envitonmentPrefix;
	}

	// Retrns the sql properties
	public Properties getSqlProperties() {
		return sqlProperties;
	}

}
