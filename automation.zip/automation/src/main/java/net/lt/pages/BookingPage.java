package net.lt.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Constants;
import net.lt.common.Utility;

public class BookingPage extends Utility {

	public BookingPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */

	// span[@class='c-indicator']
	private static final By SPN_SELECTPARTICIPANT = By.xpath("//div[@class='c-inputs-stacked']//span[@class='c-indicator']");
	private static final By CLICK_NEXT = By.xpath("//button[contains(text(),'Next')]");
	private static final By CLICK_FINISH = By.xpath("//button[contains(text(),'Finish')]");
	private static final By CLICK_NEXT_DAY = By.xpath("//span[text()='Next Day']/preceding-sibling::span");
	private static final By BTN_AVAILABLETIME = By.xpath(
			".//*[@id='main-content']//ui-view/section//div[@class='facility-container facility-container-main']/div/div[@class='facilities']//ul//a");
	private static final By TXT_ALERT = By.xpath(".//*[@id='notification-schreg-deferred']//div[@role='alert']");
	private static final By MESSAGE_ALERT = By.xpath(
			".//*[@id='notification-schreg-deferred']//button/following-sibling::div[contains(.,'User is already registered.')]");
	private static final By ERROR_YOUMUSTSELECTONEPARTICIPANTS = By.xpath("//div[@class='row p-t-2']//div[@class='card-section-cell']//div[@class='form-group alert alert-danger alert-icon']//li[contains(.,'You must select at least one participant.')]");
	private static final By ERROR_YOUMUSTSELECTONEADULTANDONEJUNIOR = By.xpath("//div[@class='row p-t-2']//div[@class='card-section-cell']//div[@class='form-group alert alert-danger alert-icon']//li[contains(.,'You must select one adult and one junior.')]");
	private static final By lnkCancel = By.xpath("//button/preceding-sibling::a[contains(text(),'Cancel')]");	
	private static final By btnYes = By.xpath("//button[text()='Yes']");
	

	
	public WebElement getLinkCancel() {
		return waitForElementToBeClickable(lnkCancel);
	}	
	
	
	
	
	public WebElement getAlertMsg() {
		return waitForElementToBeClickable(MESSAGE_ALERT);
	}
	
	public WebElement getErrorTxtYouMustSelectOneParticipants() {
		return waitForElementToBeClickable(ERROR_YOUMUSTSELECTONEPARTICIPANTS);
	}
	
	public WebElement getErrorTxtYouMustSelectOneAdultAndJunior() {
		return waitForElementToBeClickable(ERROR_YOUMUSTSELECTONEADULTANDONEJUNIOR);
	}

	public WebElement getTxtAlert() {
		return waitForElementToBeClickable(TXT_ALERT);
	}

	public WebElement getBtnAvailTime() {
		return waitForElementToBeClickable(BTN_AVAILABLETIME);
	}

	/**
	 * @return the Next day button
	 */
	public WebElement getSpnClickNextDay() {
		return waitForElementToBeClickable(CLICK_NEXT_DAY);
	}

	/**
	 * @return the Reserve button
	 */
	public WebElement getSelectParticipant() {
		return waitForElementToBeClickable(SPN_SELECTPARTICIPANT);
	}

	/**
	 * Select Multiple Participants
	 */
	public void selectMultipleParticipants() {

		List<WebElement> els = driver.findElements(SPN_SELECTPARTICIPANT);
		for (WebElement el : els) {
			if (!el.isSelected()) {
				clickElement(el);
			}
		}
	}

	/**
	 * @return the Next btn
	 */
	public WebElement getBtnNext() {
		return waitForElementToBeClickable(CLICK_NEXT);
	}

	public WebElement getBtnFinish() {
		return waitForElementToBeClickable(CLICK_FINISH);
	}
	
	/**
	 * Select available conference room (selecting the date and time)
	 */
	public void selectAvailableConferenceRoom() {
		Utility util = new Utility(driver);
        BookingPage bookingPg = new BookingPage(driver);
		ProgramsPage progPg = new ProgramsPage(driver);
		
		ReservationsPage myResvPg = new ReservationsPage(driver);
		
	    util.waitAndClickElement(myResvPg.getLnkBooking());
	    util.waitAndClickElement(bookingPg.getSpnClickNextDay());
	    util.clickElement(progPg.getBtnAvailableTimeConferenceRoom());
        util.verifyPageTitle(Constants.ConferenceRoomCreateReservationPageTitle);
	}
	
	/**
	 * Reserve a Conference room
	 */
	public void reserveConferenceRoom() {
		PendingReservationPage pResvPg = new PendingReservationPage(driver);		
		selectAvailableConferenceRoom();
		pResvPg.confirmReservation();	
	
	}
	
	/**
	 * Method to cancel Reservation
	 */
	public void cancelConferenceRoomReservation() {
		clickElement(getLinkCancel());
		clickElement(btnYes);
		verifyPageTitle("Booking");
		
	}
}
