package net.lt.pages;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Utility;


public class EventPage extends Utility {

	public EventPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */
	private static final By btnHideFilters = By.xpath("//button[contains(.,'Hide Filters')]");
	private static final By DOWHATMOVESYOUAUTOMATION = By.xpath(
			".//*[@id='main-content']//a[@class='card card-event ng-scope is-featured']//p[text()='DoWhatMovesYouQAAutomation']/ancestor::a");
	private static final By SPOOKTACULAR = By.xpath(
			".//*[@id='main-content']//a[@class='card card-event ng-scope is-featured']//p[contains(.,'Spooktacular')]/following-sibling::p[contains(.,'Paid Event')]/ancestor::a");
	private static final By SPOOKTACULARFREE = By.xpath(
			"(.//*[@id='main-content']//a[@class='card card-event ng-scope is-featured']//p[contains(.,'Spooktacular')]/following-sibling::p[not(contains(.,'Paid Event'))]/ancestor::a)[1]");
	private static final By RESERVATION3RDPARTY = By.xpath("(.//*[@id='main-content']//a[@class='card card-event ng-scope is-featured']//p[contains(.,'Commitment')]/following-sibling::p[not(contains(.,'Paid Event'))]/ancestor::a)[1]");
			
	private static final By BREAKFASTWITHSANTA = By.xpath(
			".//*[@id='main-content']//a[@class='card card-event ng-scope is-featured']//p[contains(.,'Break')]/ancestor::a");
	private static final By FIRSTEVENTONSCREEN = By
			.xpath(".//*[@id='main-content']//a[@class='card card-event ng-scope is-featured']//ancestor::a");
	private static final By BTNCALENDAR = By.xpath("//label[text()='Start Date']/following-sibling::div");
	private static final By BTNINTEREST = By.xpath("//button[text()='Interest']");
	private static final By BTNhideFilters = By.xpath("//button[@class='btn btn-primary btn-xs']");
	private static final By StartDate = By.xpath("(//span[@class='btn-icon-text'])[1]");
	private static final By EndDate = By.xpath("(//span[@class='btn-icon-text'])[2]");
	private static final By interest = By.xpath("//button[text()='Interest']");
	private static final By age = By.xpath("//button[text()='Age']");
	private static final By addClubLocation = By.xpath("//button[text()='Add Club Location']");
	private static final By showOnlyFree = By.xpath("//span[text()='Show only FREE events']");
	
	
	
	
	
	
	
	public WebElement drpdwnStartdate() {
		return waitForElement(StartDate);
	}
	
	public WebElement drpdwnEnddate() {
		return waitForElement(EndDate);
	}
	public WebElement drpdwnInterest() {
		return waitForElement(interest);
	}
	public WebElement drpdwnAge() {
		return waitForElement(age);
	}
	
	public WebElement drpdwnAddClubLoc() {
		return waitForElement(addClubLocation);
	}
	public WebElement ChkBoxShowOnlyFree() {
		return waitForElement(showOnlyFree);
	}
	
	public WebElement BtnHideFilters() {
		return waitForElement(BTNhideFilters);
	}

	/**
	 * @return the 3rd party reservation
	 */
	public WebElement getLnk3rdParty() {
		return waitForElement(RESERVATION3RDPARTY);
	}

	/**
	 * @return the Calendar link
	 */
	public WebElement getBtnFirstEventOnScreen() {
		return waitForElement(FIRSTEVENTONSCREEN);
	}

	/**
	 * @return the Calendar link
	 */
	public WebElement getBtnInteerest() {
		return waitForElement(BTNINTEREST);
	}

	/**
	 * @return the Calendar link
	 */
	public WebElement getBtnCalendar() {
		return waitForElement(BTNCALENDAR);
	}


	/**
	 * @return the "Do what moves you automation" link
	 */
	public WebElement getDoWhatMovesYou() {
		return waitForElement(DOWHATMOVESYOUAUTOMATION);
	}

	/**
	 * @return the "Breakfast With Santa" link
	 */
	public WebElement getBreakfastWithSanta() {
		return waitForElement(BREAKFASTWITHSANTA);
	}

	/**
	 * @return the "Spooktacular" link
	 */
	public WebElement getSpooktacular() {
		return waitForElement(SPOOKTACULAR);
	}

	/**
	 * @return the "Spooktacular Free" link
	 */
	public WebElement getSpooktacularFree() {
		return waitForElement(SPOOKTACULARFREE);
	}
	
	/**
	 * Select date from Multiple date
	 * @param date
	 */
	public void selectDatefromMultiDate(int dateToBeAdded) {
		clickElement(driver.findElement(By.id("date-from")));
		String date = String.valueOf(addDaysToDate(1));
		By calendarXpath = By.xpath("//td[not(contains(@class,'ui-datepicker-other-month')) and text()='" + date
				+ "' and not(@class='disabled day' or @class='old disabled day')]");
		clickElement(driver.findElement(calendarXpath));
	}
	
	/**
	 * Method to check if the event is free or Paid
	 * @return
	 */
	public EventPage checkFreeOrPaid() {
		try {
			checkEvent(SPOOKTACULAR);
			System.out.println("Selecting all webelements ");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new EventPage(driver);
	}
	
	public void verifyDropdownsPresentInEventsPage() {
		Utility util = new Utility(driver);

		Assert.assertTrue(util.isElementPresent(drpdwnStartdate()));
		Assert.assertTrue(util.isElementPresent(drpdwnEnddate()));
		Assert.assertTrue(util.isElementPresent(drpdwnInterest()));
		Assert.assertTrue(util.isElementPresent(drpdwnAge()));
		Assert.assertTrue(util.isElementPresent(drpdwnAddClubLoc()));
		Assert.assertTrue(util.isElementPresent(ChkBoxShowOnlyFree()));
	}
	
	public void verifyDropdownsNotvisibleInEventsPage() {
		Utility util = new Utility(driver);

		Assert.assertFalse(util.isElementPresent(drpdwnStartdate()));
		Assert.assertFalse(util.isElementPresent(drpdwnEnddate()));
		Assert.assertFalse(util.isElementPresent(drpdwnInterest()));
		Assert.assertFalse(util.isElementPresent(drpdwnAge()));
		Assert.assertFalse(util.isElementPresent(drpdwnAddClubLoc()));
		//Assert.assertFalse(util.isElementPresent(ChkBoxShowOnlyFree()));
	}
	
	
	

}