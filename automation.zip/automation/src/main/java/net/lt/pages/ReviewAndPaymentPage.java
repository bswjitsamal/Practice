package net.lt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Utility;

public class ReviewAndPaymentPage extends Utility {
	Utility util = new Utility(driver);


	public ReviewAndPaymentPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */

	private static final By btnCompletePurchase = By.xpath("//button[text()='Complete Purchase']");	
	private static final By txtCardName = By.xpath(".//*[@id='nameoncard']");
	private static final By TEXT_CARDNU = By.xpath(".//*[@id='cardnumber']");
	private static final By DDL_MONTH = By.xpath(".//*[@id='month']");
	private static final By DDL_YEAR = By.xpath(".//*[@id='year']");
	private static final By TEXT_SECURITYCODE = By.xpath(".//*[@id='securitycode']");
	private static final By TEXT_BILLINGZIP = By.xpath("//input[@id='billingZip']");
	private static final By CHKBX_TANDC = By.xpath("//div[@class='form-group']//span[@class='c-indicator']");
	private static final By CHKBX_TANDCOND = By.xpath("//div[@class='form-group form-group-spacer']//span[@class='c-indicator']");
	private static final By PAYMENT_TYPE_CREDITCARD = By.xpath("//input[@id='paymentNewCreditCard']/ancestor::label");
	private static final By PAYMENT_TYPE_CLUB = By.xpath("//input[@id='paymentClubTab']/ancestor::label");
	private static final By LNK_CHANGE = By.xpath("//a[contains(.,'Change')]");
	private static final By LNK_ADDANOTHERFROMOFPAYMENT = By.xpath("//a[contains(.,'Add another form of payment')]");
	private static final By BTN_UPDATEPAYMENT = By.xpath(".//button[contains(.,'Update Payment')]");
	
	private static final By LinkChange = By.xpath("//a[text()='Change ']");
	private static final By LinkAddAnotherPayment = By.xpath("//a[text()=' Add another form of payment']");
	private static final By LinkCancel = By.xpath("//a[text()='Cancel']");
	private static final By OrderTotal = By.xpath("//strong[text()='Total']/../../td[@class='text-xs-right']/strong");

	
	
	
	
	public WebElement orderTotal() {
		return waitForElementToBeVisible(OrderTotal);
	}
	
	
	public WebElement LinkCancel() {
		return waitForElementToBeVisible(LinkCancel);
	}
	
	public WebElement LinkAnotherPayment() {
		return waitForElementToBeVisible(LinkAddAnotherPayment);
	}
	public WebElement LinkChange() {
		return waitForElementToBeVisible(LinkChange);
	}
	public WebElement getBtnUpdatePayment() {
		return waitForElementToBeVisible(BTN_UPDATEPAYMENT);
	}
	
	public WebElement getLnkAntherFormPayment() {
		return waitForElementToBeVisible(LNK_ADDANOTHERFROMOFPAYMENT);
	}
	
	public WebElement getLnkChange() {
		return waitForElementToBeVisible(LNK_CHANGE);
	}

	
	public WebElement getSelectCreditCardTab() {
		return waitForElementToBeVisible(PAYMENT_TYPE_CREDITCARD);
	}

	public WebElement getSelectClubTab() {
		return waitForElementToBeVisible(PAYMENT_TYPE_CLUB);
	}

	public WebElement getInputBillingZip() {
		return waitForElementToBeVisible(TEXT_BILLINGZIP);
	}

	public WebElement getInputSecurityCode() {
		return waitForElementToBeVisible(TEXT_SECURITYCODE);
	}

	public WebElement getInputYear() {
		return waitForElementToBeVisible(DDL_YEAR);
	}

	public WebElement getInputMonth() {
		return waitForElementToBeVisible(DDL_MONTH);
	}

	public WebElement getInputCardNu() {
		return waitForElementToBeVisible(TEXT_CARDNU);
	}

	public WebElement getInputName() {
		return waitForElementToBeVisible(txtCardName);
	}

	/**
	 * @return view all Reservation btn
	 */
	public WebElement getBtnCompletePurchase() {
		return waitForElementToBeVisible(btnCompletePurchase);
	}

	/**
	 * @return I Agree to the Life Time Terms and Condition
	 */
	public WebElement getChkBoxTandC() {
		return waitForElementToBeVisible(CHKBX_TANDC);
	}
	
	public WebElement getChkBoxNewTandC() {
		return waitForElementToBeVisible(CHKBX_TANDCOND);
	}

	public void selectTandC() {
		clickElement(getChkBoxTandC());
	}

	
	
	public void updatePaymentInformation(String userName, String cardNu, String month, String year, String zip) {
		ReviewAndPaymentPage revPaymentPage = new ReviewAndPaymentPage(driver);
	
	isElementPresent(LinkCancel);
	revPaymentPage.getInputName().sendKeys(userName);
	revPaymentPage.getInputCardNu().sendKeys(cardNu);
	revPaymentPage.getInputMonth().sendKeys(month);
	revPaymentPage.getInputYear().sendKeys(year);
	//revPaymentPage.getInputSecurityCode().sendKeys(envProperties.getProperty("member.user.securitycode"));
	revPaymentPage.getInputBillingZip().sendKeys(zip);
	util.clickElement(revPaymentPage.getBtnUpdatePayment());

}
}
