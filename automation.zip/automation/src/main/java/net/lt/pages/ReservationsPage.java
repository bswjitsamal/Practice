package net.lt.pages;

import java.lang.System;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import net.lt.common.DatabaseUtil;
import net.lt.common.SQLConstants;
import net.lt.common.Utility;

public class ReservationsPage extends Utility {

	public ReservationsPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */
	
	private static final By TXT_SPOT = By.xpath("//ul[@class='list-unstyled reservation-list']//span[contains(.,'Spot')]");
	private static final By BTN_PICKSPOT = By.xpath("//div[@class='card-section-cell']//*[name()='svg']//*[name()='g' and @class='svg-spot']");
	private static final By CLICK_FINISH = By.xpath("//button[contains(text(),'Finish')]");
	private static final By RESERVATIONPOLICYWAIVER = By.xpath("//span[@class='c-indicator']");
	
	private static final By BTN_RESERVATIONS = By.xpath("//*[text()='Reservations']");
	private static final By BTN_MAKENEWRESERVATION = By.xpath("//*[text()='Make New Reservation']");
	public final By btnCancelReservation = By.xpath("(//div[contains(@class,'hidden')]//button[text()='Cancel'])[2]");
	public final By btnMobCancelReservation = By.xpath("(//div[contains(@class,'hidden')]//button[text()='Cancel'])[1]");
	public final By CANCELRESERVATION = By.xpath("//button[text()='Cancel Reservation']");

	private static final By BTN_YES = By.xpath(".//*[text()='Cancel Confirmation']/../following-sibling::div[2]//button[text()='Yes']");
	
	private static final By UI_ACTIAL_TEXT = By.xpath("//ul[@class='list-unstyled reservation-list']");
	private static final By LNK_LISTRESERVATIONS = By
			.xpath(".//*[@id='main-content']//ui-view/section//ul[@class='list-unstyled reservation-list']//h2");
	
	private static final By BTN_OUTLOOKCALENDAR = By.xpath("//*[@id=\'ltfcAdd\']/div/a[1]");
	
	private static final By LNK_BOOKINGS = By.xpath("//a[text()='Booking']");
	private static final By LNK_MEMBERS = By.xpath(".//*[@id='headerNav']//a[text()='Members']");
	private static final By BTN_HEADER_RESERVATIONS = By.xpath(".//*[@id='headerNav']//a[text()='Reservations']");
	private static final By LIFETIME = By.xpath(".//*[@id='headerNav']//img[@alt='Life Time']");
	
	private static final By hdrReservation = By.xpath("//h1[text()='Your reservation is complete.']");
	private static final By txtCourtName = By.xpath("(//div[contains(@class,'reservation')]//span)[1]");
	private static final By btnAddToCalendar = By.xpath("//button[text()='Add to Calendar']");
	//div[contains(@class,'reservation')]
	private static final By btnModalAddToCalendar = By
			.xpath("//div[contains(@class,'modal')]//button[text()='Add to Calendar']");
	private static final By BTN_EDITRESERVATION = By.xpath("//h2[contains(.,'')]//ancestor::div[@class='cmpt-row']/div[@class='cmpt-col-xs-12 cmpt-col-sm-6 cmpt-col-md-4 cmpt-col-lg-3 cta-column']//button[contains(.,'Edit Reservation')]");
	private static final By BTN_AVAILABLETIME = By.xpath(
			".//*[@id='main-content']//ui-view/section//div[@class='facility-container facility-container-main']/div/div[@class='facilities']//ul//a[contains(@href,'/account/')]");
	private static final By lnkReservationRules = By
			.xpath("//span[@class='ico-document']");
	private static final By TextMsg = By
			.xpath("//p[text()='If you have any special needs for your meeting (technology, catering, or otherwise) please contact the Front Desk or the Life Time Work Manager. Please cancel at least 60 minutes in advance of start time, otherwise standard charges will occur.']");
	private static final By HideIcoDoc = By
			.xpath("//span[text()='Hide']");
	private static final By drpDwnFacilit = By
			.xpath("(//div[@class='cmpt-row']//select[@title='Facility'])[2]");
	private static final By drpDwnFacilitMob = By
			.xpath("(//div[@class='cmpt-row']//select[@title='Facility'])[1]");
	private static final By BTN_RESERVEACOURT = By.xpath("//a[starts-with(text(),'Reserve')]");
	private static final By BTN_EDITRESERVATION_1 = By.xpath("//button[contains(.,'Edit Reservation')]");
	
	
	public WebElement getTxtSpot() {
		return waitForElement(TXT_SPOT);
	}
	
	
	public WebElement getBtnEditReservation_1() {
		return waitForElement(BTN_EDITRESERVATION_1);
	}
	
	public WebElement getReservationPolicy() {
		return waitForElementToBeClickable(RESERVATIONPOLICYWAIVER);
	}
	
	public WebElement getPickSpot() {
		return waitForElementToBeClickable(BTN_PICKSPOT);
	}
	
	public WebElement getBtnFinish() {
		return waitForElementToBeClickable(CLICK_FINISH);
	}
	
	public WebElement getFacilitiesDropDown() {
        //return waitForElementToBeVisible(drpDwnFacilit);
        
        if(getDevice().equals("NonMobile"))
		{
			return waitForElementToBeVisible(drpDwnFacilit);
		}else
		{
			return waitForElementToBeVisible(drpDwnFacilitMob);
		}
    }
	
	public WebElement getBtnEditReservation() {
		return waitForElement(BTN_EDITRESERVATION);
	}
	
	
    public WebElement HideReservationRules() {
        return waitForElementToBeVisible(HideIcoDoc);
    }
	
    public WebElement TextMsg() {
        return waitForElementToBeVisible(TextMsg);
    }

	public WebElement getLnkReservationRules() {
		return waitForElementToBeVisible(lnkReservationRules);
	}

	public WebElement getMakeNewReservation() {
		return waitForElementToBeVisible(BTN_MAKENEWRESERVATION);
	}

	public WebElement getImgLifetime() {
		return waitForElementToBeVisible(LIFETIME);
	}

	public WebElement getLnkMembers() {
		return waitForElementToBeVisible(LNK_MEMBERS);
	}

	public WebElement getLnkBooking() {
		return waitForElementToBeVisible(LNK_BOOKINGS);
	}


	public ArrayList<String> getValues() {
		return getValue(LNK_LISTRESERVATIONS);
	}

	public ArrayList<String> getTextValues() {
		return getValues();
	}

	
	/**
	 * @return the MyReservation button
	 */
	public WebElement getBtnMyReservations() {
		return waitForElement(BTN_RESERVATIONS);
	}

	/**
	 * @return the Cancel Reservation
	 */
	
	public By getBtnCancelReservation() {
		if(getDevice().equals("NonMobile"))
		{
			return btnCancelReservation;
		}else
		{
			return btnMobCancelReservation;
		}
	}
	
	/**
	 * @return the Cancel Reservation
	 */
	public WebElement getLnkCancelReservation() {
		return waitForElement(CANCELRESERVATION);
	}


	public WebElement getBtnYes() {
		return waitForElement(BTN_YES);
	}


	/**
	 * Cancel All Reservations
	 * @param value
	 * @return
	 */
	public ReservationsPage cancelAllReservations(String value) {
		try {

			List<WebElement> links = driver.findElements(By.xpath("//button[text()='Cancel Reservation']"));

			for (WebElement element : links) {
				if (element.getText().contains(value)) {
					element.click();
					System.out.println("Successfully clicked on the WebElement: " + "<" + element.toString() + ">");

					driver.switchTo().activeElement();
					waitAndClickElement(getBtnYes()); // Clicking on the YES button for confirmation
					// selectYes();
					wait(15);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to wait and click on WebElement, Exception: " + e.getMessage());
		}

		return new ReservationsPage(driver);
	}

	/**
	 * Method to verify Confirmation and cancel reservation
	 * @param value
	 * @return
	 */
	public ReservationsPage verifyConfirmationAndCancellationReservation(String value) {
		try {

			isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);

			waitAndClickElement(getLnkCancelReservation()); // Clicking on the cancel reservation
			driver.switchTo().activeElement();
			waitAndClickElement(getBtnYes()); // Clicking on the YES button for confirmation
			wait(3);

			isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);
			return new ReservationsPage(driver);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public void verifyCourtReservationInUI(String courtName)
	{
		Assert.assertTrue(isElementPresent(hdrReservation));
		Assert.assertTrue(isTextPresent(txtCourtName, courtName));
	}
	
	public void verifyAddToCalendar(Capabilities capabilities, String className) {		
		waitForElementToBeVisible(btnAddToCalendar);
		clickElement(btnAddToCalendar);
		waitForElementToBeVisible(btnModalAddToCalendar);
		clickElement(btnModalAddToCalendar);
		validateAddToCalendar(capabilities , className);
	}

	public ReservationsPage verifyCancelButtonPresentIfLessThen24Hr(String value) {
		try {

			waitForElement("//button[text()='Add to Calendar']");
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
			Date date = new Date();
			System.out.println(formatter.format(date));
			System.out.println(date.toString());

			String text = null;
			ArrayList<String> allValues = new ArrayList<String>();
			List<WebElement> btnAvlElement = driver.findElements(By.xpath(
					"//button[text()='Add to Calendar']/../../..//time"));

			for (WebElement btnAvlEle : btnAvlElement) {
				text = btnAvlEle.getText();
				System.out.println("-->" + text);

				allValues.add(text);
			}

			System.out.println(allValues);
			String newDate = allValues.get(0) + " " + allValues.get(1);
			System.out.println(newDate);

			// reservation Date from the application
			String strDate = newDate;

			// Convert the date string to required date format
			Date formattedDate = dateFormatter(strDate, "EEEE, MMMM dd, yyyy HH:mm");
			// String strFormattedDate = dateToStringConverter(formattedDate, "E, MMM dd,
			// yyyy HH:mm");

			// Convert the current DateTime to the required date format
			String strCurrentDate = dateToStringConverter(new Date(), "E, MMM dd, yyyy HH:mm");
			Date currDate = dateFormatter(strCurrentDate, "EEEE, MMMM dd, yyyy HH:mm");

			// Find the date difference and convert into seconds
			Long TimeDiff = currDate.getTime() - formattedDate.getTime();
			System.out.println("" + TimeDiff / 1000);
			// Check the condition in seconds
			if ((TimeDiff / 1000) < (24 * 60 * 60)) {
				System.out.println("Time Difference is less than 24 hours");
				Assert.assertFalse(isElementPresent(By.xpath("//div[contains(@class,'reservations-container')]//li[1]//button[text()='Cancel Reservation']")));
			}else
			{
				System.out.println("Time Difference is greater than 24 hours");
				Assert.assertTrue(isElementPresent(By.xpath("//button[text()='Cancel Reservation']")));
			}
	
			return new ReservationsPage(driver);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	// This Method will cancel all the FitMetrix Reservations through API
	public ReservationsPage CancelAllFitMetrixReservations(String externalId, RequestSpecification Auth) {
		try {

			String profileId = getProfileId(Auth, externalId, "PROFILEID");
			String appointmentIds = getAllAppointmentIds(Auth, externalId, "APPOINTMENTID");
			if (deleteAppointments(Auth, profileId, appointmentIds)) {
				System.out.println("Cancelled all appointments for the member");
			} else {
				System.out.println("appointments not cancelled for the member");
			}
			return new ReservationsPage(driver);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// This Method gets the profile Id through API
	public String getProfileId(RequestSpecification Auth, String externalId, String key) {

		// To use the GET method and get back the response for validation
		Response response = Auth.when().get(RestAssured.baseURI + "/profiles?externalid=" + externalId);

		String json = response.getBody().asString();
		JsonPath jPath = new JsonPath(json);
		return jPath.getString(key).replace("[", "").replace("]", "");
	}

	// This Method gets all the appointments for the provided externalId through API
	public String getAllAppointmentIds(RequestSpecification Auth, String externalId, String key) {
		// To use the GET method and get back the response for validation
		Response response = Auth.when().get(RestAssured.baseURI + "/profile/0/appointments?externalid=" + externalId
				+ "&startdate=" + LocalDate.now() + "&enddate=" + LocalDate.now().plusDays(10) + "&pagesize=1000");

		String jsonResponse = response.getBody().asString();
		if (!jsonResponse.contains("No profile appointment records")) {
			JsonPath jPath = new JsonPath(jsonResponse);
			String appointmentIds = jPath.getString(key);
			System.out.println(appointmentIds.replace("[", "").replace("]", ""));
			return appointmentIds.replace("[", "").replace("]", "");
		}
		return "";
	}

	// This Method deletes all the appointments for the provided profileId through
	// API
	public boolean deleteAppointments(RequestSpecification Auth, String profileId, String appointmentIds) {
		boolean deleteSuccess = true;
		if (!appointmentIds.isEmpty()) {
			String[] appointments = appointmentIds.split(",");
			// To use the GET method and get back the response for validation

			for (String appointmentid : appointments) {
				Response response = Auth.when()
						.delete(RestAssured.baseURI + "/appointment/" + appointmentid.trim() + "/profile/" + profileId);
				String json = response.getBody().asString();
				JsonPath jPath = new JsonPath(json);
				if (jPath.getBoolean("Success") == false) {
					deleteSuccess = false;
				}
			}
		}
		return deleteSuccess;
	}

	// This method verifies the FitMetrix Reservations through API
	public void verifyFitMetrixReservation(String externalId, RequestSpecification Auth, String expReservationName) {
		try {

			Response response = Auth.when().get(RestAssured.baseURI + "/profile/0/appointments?externalid=" + externalId
					+ "&startdate=" + LocalDate.now() + "&enddate=" + LocalDate.now().plusDays(10) + "&pagesize=1000");

			String jsonResponse = response.getBody().asString();
			if (!jsonResponse.contains("No profile appointment records")) {
				JsonPath jPath = new JsonPath(jsonResponse);
				String reservationName = jPath.getString("NAME");
				System.out.println(reservationName.replace("[", "").replace("]", ""));
				if (reservationName.contains(expReservationName)) {
					System.out.println(expReservationName + " reservation done successfully");
				} else {
					System.out.println(expReservationName + " reservation not done");
				}

			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// This method deletes all the court reservations through API
	public void deleteReservations(RequestSpecification Auth, String depatmentName, int memberid, String SSOID) {
		try {
			boolean deleteSuccess = false;
			// read Json object / Json Array from Json file
			JSONObject JsonPOST = readJsonFile("reservations.json");
			JSONParser parser = new JSONParser();
			String JsonString = JsonPOST.toString().replace("$departmentName", depatmentName);
			JsonString = JsonString.replace("$startdate", "" + LocalDate.now());
			JsonString = JsonString.replace("$enddate", "" + LocalDate.now().plusDays(10));
			JsonString = JsonString.replace("$memberId", "" + memberid);
			JsonPOST = (JSONObject) parser.parse(JsonString);
			Auth.header("X-LTF-SSOID", SSOID);
			Auth.body(JsonPOST);
			Response response = Auth.when().post(
					RestAssured.baseURI + "/edge/api/scheduling/events/search?facet=tags:department&sort=ascending");
			String jsonResponse = response.getBody().asString();
			JsonPath jPath = new JsonPath(jsonResponse);
			if (jPath.getInt("page.numberOfResults") > 0) {
				for (int x = 0; x < jPath.getInt("page.numberOfResults"); x++) {
					String summary = jPath.getString("results[" + x + "].eventData.products.sku");
					if (summary.contains("COURT")) {
						String attendeesIds = jPath.getString("results[" + x + "].eventData.attendees.id");
						attendeesIds = attendeesIds.replace("[", "").replace("]", "");
						System.out.println(attendeesIds.replace("[", "").replace("]", ""));
						response = Auth.when()
								.delete(RestAssured.baseURI + "/registration/v2/" + (attendeesIds.split(","))[0].trim()
										+ "/resource/" + (attendeesIds.split(","))[1].trim());
						wait(30);
						String json = response.getBody().asString();

						if (json.isEmpty()) {
							deleteSuccess = true;
						}
					}
				}

			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// This Method validates the court reservations through API
	public void validateCourtReservations(RequestSpecification Auth, String depatmentName, int memberid, String SSOID) {
		try {

			// read Json object / Json Array from Json file
			JSONObject JsonPOST = readJsonFile("reservations.json");
			JSONParser parser = new JSONParser();
			String JsonString = JsonPOST.toString().replace("$departmentName", depatmentName);
			JsonString = JsonString.replace("$startdate", "" + LocalDate.now());
			JsonString = JsonString.replace("$enddate", "" + LocalDate.now().plusDays(10));
			JsonString = JsonString.replace("$memberId", "" + memberid);
			JsonPOST = (JSONObject) parser.parse(JsonString);
			Auth.header("X-LTF-SSOID", SSOID);
			Auth.body(JsonPOST);
			Response response = Auth.when().post(
					RestAssured.baseURI + "/edge/api/scheduling/events/search?facet=tags:department&sort=ascending");
			String jsonResponse = response.getBody().asString();
			JsonPath jPath = new JsonPath(jsonResponse);
			for (int x = 0; x < jPath.getInt("page.numberOfResults"); x++) {
				String summary = jPath.getString("results[" + x + "].eventData.products.sku");
				if (summary.contains("COURT")) {
					System.out.println("court reservation done successfully");

				}
			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// This method cancels the reservations in UI	  
	  public void cancelReservationInUI(String value) {
		  try {			
			  while(isElementPresent(getBtnCancelReservation()))
			  {
				  String currPageTitle = driver.getTitle();
				  clickElement(getBtnCancelReservation()); // Clicking on the cancel reservation				  
				  clickElement(getBtnYes()); // Clicking on the YES button for confirmation
				  wait(2);
				  driver.navigate().refresh();
				  verifyPageTitle(currPageTitle);
			  }
		  } catch (Exception e) {

		}
	}	
	  
	  
	  public void verifyEditReservation(String value) {
			try {

				isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);

				waitAndClickElement(getBtnEditReservation()); // Clicking on the Edit reservation				
				

			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

	  public ReservationsPage selectASpot() {
			try {
				
				//clickElement(getPickSpot());
				
				WebElement svgObj = getPickSpot();
				Actions actionBuilder = new Actions(driver);
				actionBuilder.click(svgObj).build().perform();
				Thread.sleep(200);
				clickElement(getReservationPolicy());
				clickElement(getBtnFinish());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return new ReservationsPage(driver);
		}
	  
	  public ReservationsPage verifyEditPickaSpotReservation(String value) {
			try {
				 
				ClassSchedulesPage clsSchPg = new ClassSchedulesPage(driver);
				DetailsPage detlPg =  new DetailsPage(driver);
				Utility util= new Utility(driver);
				ReservationConfirmationPage resvConfPg = new ReservationConfirmationPage(driver);
				
				clsSchPg.navigateToSchedulesPageAndSelectFilters("Chanhassen", "Cycling", "EDG Cycle (Pick a Spot)");
				clsSchPg.navigateToNextWeekandClick();	
				detlPg.reservePickSpotClass();
				util.isElementPresent("Spot ");
				util.waitAndClickElement(resvConfPg.geBtnViewAllReservations());
				isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);
				
				/*ReservationsPage resvePg = new ReservationsPage(driver);
				isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);

				waitAndClickElement(getBtnEditReservation_1()); // Clicking on the Edit reservation
				resvePg.selectASpot();*/
				
				
				return new ReservationsPage(driver);

			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
}