package net.lt.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;

/*******************************************************************************
 * Class for Class Schedules Page
 */
public class ClassSchedulesPage extends Utility {

	public ClassSchedulesPage(WebDriver driver) {
		super(driver);
	}

	public final By LOADER = By.xpath("//div[@class='spinner-container']/div[@class='spinner']");
	private static final By BTN_FILTERS_EXPAND = By.xpath("//button[text()='Filters']");
	private static final By BTN_NEXTWEEK = By.xpath("//button[@class='btn btn-date-page btn-date-page-next']");
	private static final By BTN_PREVIOUSWEEK = By.xpath("//button[@class='btn btn-date-page btn-date-page-prev']");
	private static final By BTN_NEXT_AVAILABLE_DATE = By.xpath("(//div[@class='day-heading']//input)[1]");
	private static final By BTN_INSTRUCTOR = By.xpath("//button[text()='Instructor']");
	private static final By SPN_TAMMIP = By.xpath("//*[@id='ltf-multiselect-7']/fieldset//span[text()='Emma G.']/.."); //
	private static final By BTN_TIME_OF_DAY = By.xpath("//button[text()='Time of Day']");
	private static final By LBL_MIDDAY = By.xpath("//button[text()='Time of Day']/..//label/span");
	private static final By SPN_EDGRT = By.xpath(
			"//*[@id=\'main-content\']/div[3]/ui-view/section/div[2]/div[2]/div[2]/div[2]/div/div[3]/div/div[2]/a");
	private static final By HDR_EDGRT = By
			.xpath("//*[@id=\'main-content\']/div[3]/ui-view/section/div[1]/header/div/div[1]/div/h1");

	private static final By LBL_INTEREST_CYCLING_FILTER = By
			.xpath(".//*[@id='ltf-multiselect-1']/fieldset//span[text()='Cycling']");
	private static final By LBL_CLASSNAME_EDGCYCLING_FILTER = By
			.xpath(".//*[@id='ltf-multiselect-2']/fieldset//span[text()='EDG Cycle']");
	private static final By DIV_EDGCYCLING = By.xpath(
			" //div[@ui-view='calendar']//div[@class='calendar']//a[@class='card card-notecard card-block ng-scope']/p[contains(.,'Reserve')]/ancestor::a");
	private static final By tileWithoutReserve = By.xpath(
			" //div[@ui-view='calendar']//div[@class='calendar']//a[@class='card card-notecard card-block ng-scope']/p[not(contains(.,'Reserve'))]/ancestor::a");
	private static final By BTN_RESERVE = By.xpath("//header//button[text()='Reserve']");
	private static final By LNK_CANCELRESERVATION = By.xpath("//header//button[text()='Cancel Reservation']");
	private static final By BTN_RESERVATIONS = By.xpath("//*[text()='Reservations']");
	private static final By BTN_CASSNAME = By.xpath("//button[text()='Class Name']");
	private static final By BTN_INTEREST = By.xpath("//button[text()='Interest']");
	private static final By SPN_BOOKASEAT = By.xpath(".//div[starts-with(@id, 'seat-')]");
	private static final By BTN_CANCELRESERVATION = By.xpath("//button[text()='Cancel Reservation']");
	private static final By BTN_YES = By.xpath("(//div[contains(@id,'cancel')]//button[text()='Yes'])[1]");
	private static final By LBL_INTEREST_YOGA_FILTER = By
			.xpath(".//*[@id='ltf-multiselect-1']/fieldset//span[text()='Yoga']");
	private static final By LBL_CLASSNAMR_ASHTANGAVINYASA_FILTER = By
			.xpath(".//*[@id='ltf-multiselect-2']/fieldset//span[text()='Ashtanga Vinyasa']");
	private static final By DIV_ASHTANGAVINYASA = By.xpath(
			" //div[@ui-view='calendar']//div[@class='calendar']//a[@class='card card-notecard card-block ng-scope']//span[text()='Ashtanga Vinyasa']");
	private static final By BTN_PICKSPOT = By.xpath(".//*[@id='pmdBtn']");
	private static final By BTN_FAVORITES = By.xpath("//button[text()='Favorites']");
	private static final By LNK_LOGIN = By.xpath("//a[text()='log in']");
	private static final By BTN_ADDSCHEDULETOFAV = By.xpath(
			"//div[@class='tooltip-wrap toggletip hidden-sm-down']/button[contains(.,'Add Schedule to Favorites')]");
	private static final By SPN_CHICLETS = By.xpath("//div[@class='tooltip-wrap toggletip hidden-sm-down']/button");

	private static final By spnMobChiclet = By.xpath("//div[@class='tooltip-wrap toggletip hidden-md-up']/button");
	private static final By INPUT_TEXT = By
			.xpath(".//*[@id='addSearch']//div[@class='modal-body']//input[@id='text-add']");
	private static final By EDIT_TEXT = By.xpath(".//*[@id='editSearch']//input[@id='text-edit']");
	private static final By BTN_ADD = By.xpath(".//*[@id='add-submit']");
	private static final By BTN_EDIT = By.xpath(".//*[@id='edit-submit']");
	private static final By BTN_DEL_YES = By
			.xpath(".//*[@id='deleteSearch']//button[text()='No']/following-sibling::button");
	private static final By TEXT_PRESENT_CONTAINER = By
			.xpath(".//*[@id='notification-schreg']/div[@class='container']//p");

	private static final By EDIT_FAVORITE = By
			.xpath("//div[@class='favorite-block']//button[contains(.,'Edit Favorite')]");
	private static final By BTN_FAVORITE = By
			.xpath("//div[@class='favorite-block']//button[contains(.,'Edit Favorite')]/preceding-sibling::button");
	private static final By DELETE_FAVORITE = By
			.xpath("//div[@class='favorite-block']//button[contains(.,'Delete Favorite')]");
	private static final By BTN_NO = By.xpath(".//*[@id='deleteSearch']//button[contains(.,'No')]");
	private static final By BTN_HIDEORDISPLAYFAV = By.xpath("//button[contains(.,'Favorites')]");
	private static final By BTN_SAVEDFAVORITENAME = By.xpath(
			".//*[@id='main-content']//ui-view/section//div[@class='cmpt-row']//div[@class='favorite-block']/button[1]");
	private static final By ALL_FILTERORDERING = By
			.xpath(".//*[@id='main-content']//div[@class='cmpt-row']/div[@class='cmpt-col-md-4']//button");
	private static final By DIV_ALERTMESSAGE = By.xpath("//div[@class='container']//div[@role='alert']");
	private static final By LOGO_LIFETIME = By.xpath("(//img[@src='/content/dam/mylt/logos/life-time-logo-xs.svg'])[2]");
	private static final By FavName = By.xpath("(//button[@class='btn btn-link btn-link-simple btn-sm btn-add-favorite ng-binding'])[2]");
	private static final By AlertMsgNoFavSched = By.xpath("//div[text()='You have no favorite schedules. Save a favorite schedule for next time by applying filters and then selecting “Add Schedule to Favorites” below.']");
	// Then you can use String.format to insert the variable you want:
	private static final String CHILD_FILTER_ITEM = ".//fieldset//span[text()='%s']";
	private static final String PARENT_FILTER_ITEM = ".//*[@id='main-content']//div[@class='cmpt-row']//button[text()='%s']";
	private static final String DIV_EDGCYCLING_XPATH = "//div[@ui-view='calendar']//div[@class='calendar']//a[@class='card card-notecard card-block ng-scope']/p[contains(.,'Reserve')]/ancestor::a";
	private static final By TcxXpath = By.xpath("//div[@ui-view='calendar']//div[@class='calendar']");
	private static final By lnkFavName = By.xpath("//div[@class='favorite-block']//button[1]");
	private static final By errMsgSameFavName = By.xpath("//span[text()='This schedule name already exists. Please try a different one.']");
	private static final By btnCancel = By.xpath("(//button[text()='Cancel'])[2]");
	private static final By btnMobCancel = By.xpath("(//button[text()='Cancel'])[1]");
	private static final By lnkClasses = By.xpath("//a[text()='Classes']");
	private static final By lnkFacilities = By.xpath("//a[text()='Facilities']");
	//private static final By lnkHelp = By.xpath("//div[@class='page-head-buttons']//a[text()='Help']");
	private static final By lnkHelp = By.xpath("//button[text()='Print Week']/following-sibling::a[text()='Help']");
	private static final By ErrMsgRemoveLoc = By.xpath("//div[@id='noLocation']//div[@class='modal-body']/p");
	private static final By ErrMsgRemoveLocChkBox = By.xpath("//div[@id='lastLocation']//div[@class='modal-body']/p");
	private static final By btnYesPopupRemoveLoc = By.xpath("//div[@id='noLocation']//button[text()='Yes']");

	private static final By btnYesPopupRemoveLocChkBox = By.xpath("//div[@id='lastLocation']//button[text()='Yes']");

	private static final By ErrMsgNoLoc = By.xpath("//div[@class='cmpt-row ng-scope']//p");

	private static final By drpdwnInterest = By.xpath("//button[text()='Interest']");
	private static final By drpdwnClassname = By.xpath("//button[text()='Class Name']");
	private static final By drpdwnAddclubLocation = By.xpath("//button[text()='Add Club Location']");
	private static final By drpdwnTimeOfDay = By.xpath("//button[text()='Time of Day']");
	private static final By drpdwnAge = By.xpath("//button[text()='Age']");
	private static final By drpdwnSkillLevel = By.xpath("//button[text()='Skill Level']");
	private static final By drpdwnIntensity = By.xpath("//button[text()='Intensity']");
	private static final By drpdwnInstructor = By.xpath("//button[text()='Instructor']");

	private static final By hdrClassSchedules = By.xpath("//h2[text()='Class Schedules']");
	private static final By btnPrintWeek = By.xpath("//button[text()='Print Week']");

	//private static final By chicletLoc = By.xpath("//button[@class='chiclet ng-scope']");

	private static final By chicletLoc = By.xpath("//button[@class='chiclet ng-scope']//span[text()='Chanhassen']");
	private static final By addfav = By.xpath("(//button[@class='btn btn-link btn-link-simple btn-sm btn-add-favorite ng-binding'])[1]");

	/******************************************************************************/



	public WebElement getAddFav() {
		return waitForElement(addfav);
	}
	public WebElement getErrMsgRemoveLocChkBox() {
		return waitForElement(ErrMsgRemoveLocChkBox);
	}
	public WebElement getbtnYesPopupRemoveLocChkBox() {
		return waitForElement(btnYesPopupRemoveLocChkBox);
	}
	public WebElement getchicletLoc() {
		return waitForElement(chicletLoc);
	}
	public WebElement getbtnPrintWeek() {
		return waitForElement(btnPrintWeek);
	}

	public WebElement gethdrClassSchedules() {
		return waitForElement(hdrClassSchedules);
	}
	public WebElement getErrMsgNoLoc() {
		return waitForElement(ErrMsgNoLoc);
	}
	public WebElement getbtnYesPopupRemoveLoc() {
		return waitForElement(btnYesPopupRemoveLoc);
	}
	public WebElement getErrMsgRemoveLoc() {
		return waitForElement(ErrMsgRemoveLoc);
	}
	public WebElement getLnkHelp() {
		return waitForElement(lnkHelp);
	}
	public WebElement getLnkClasses() {
		return waitForElement(lnkClasses);
	}

	public WebElement getLnkFacilities() {
		return waitForElement(lnkFacilities);
	}
	public WebElement getDrpdwnInterest() {
		return waitForElement(drpdwnInterest);
	}
	public WebElement getDrpdwnClassName() {
		return waitForElement(drpdwnClassname);
	}
	public WebElement getDrpdwnAddClubLoc() {
		return waitForElement(drpdwnAddclubLocation);
	}
	public WebElement getDrpdwnTimeOfDay() {
		return waitForElement(drpdwnTimeOfDay);
	}
	public WebElement getDrpdwnAge() {
		return waitForElement(drpdwnAge);
	}
	public WebElement getDrpdwnSkillLevel() {
		return waitForElement(drpdwnSkillLevel);
	}
	public WebElement getDrpdwnIntensity() {
		return waitForElement(drpdwnIntensity);
	}
	public WebElement getDrpdwnInstructor() {
		return waitForElement(drpdwnInstructor);
	}
	public WebElement getBtnCancel() {
		return waitForElement(btnCancel);
	}

	public WebElement getTxtErrMsgSameFavName() {
		return waitForElement(errMsgSameFavName);
	}
	public WebElement getlnkFavName() {
		return waitForElement(lnkFavName);
	}
	public WebElement getTcxXpath() {
		return waitForElement(TcxXpath);
	}
	public WebElement getlifetimelogo() {
		return waitForElement(LOGO_LIFETIME);
	}
	public WebElement alertMsgNoFavSched() {
		return waitForElementToBeVisible(AlertMsgNoFavSched);
	}
	public WebElement FavName() {
		return waitForElement(FavName);
	}
	public WebElement getAlertMessage() {
		return waitForElement(DIV_ALERTMESSAGE);
	}


	public WebElement getCancelLink() {
		return waitForElement(LNK_CANCELRESERVATION);
	}

	/**
	 * @return the list of saved fav present on HTML
	 */

	public List<WebElement> getFilterItem() {
		return waitForElementsToBeVisible(ALL_FILTERORDERING);
	}

	public WebElement getBtnSavedFavName() {
		return waitForElement(BTN_SAVEDFAVORITENAME);
	}

	public ArrayList<String> getValues() {
		return getValue(BTN_SAVEDFAVORITENAME);
	}

	public ArrayList<String> getTextValues() {
		return getValues();
	}

	public WebElement getLoader() {
		return waitForElement(LOADER);
	}

	/**
	 * @return the Saved Favorite item
	 */

	public WebElement getBtnFavoriteItem() {
		return waitForElement(BTN_FAVORITE);
	}

	/**
	 * @return the text filed on HTML
	 */

	public WebElement getBtnSavEdit() {
		return waitForElement(BTN_EDIT);
	}

	/**
	 * @return the text filed on HTML
	 */

	public WebElement getTextContainer() {
		return waitForElement(TEXT_PRESENT_CONTAINER);
	}

	/**
	 * @return the Edit fav Button on modal
	 */

	public WebElement getInputEdit() {
		return waitForElement(EDIT_TEXT);
	}

	/**
	 * @return the Delete fav Button on modal
	 */

	public WebElement getBtnDelFav() {
		return waitForElement(BTN_DEL_YES);
	}

	/**
	 * @return the Hide/display fav Button on modal
	 */

	public WebElement getBtnShowOrHideFav() {
		return waitForElementToBeClickable(BTN_HIDEORDISPLAYFAV);
	}



	/**
	 * @return the No Button on modal
	 */

	public WebElement getBtnNo() {
		return waitForElement(BTN_NO);
	}

	/**
	 * @return the Edit Fav Button in the modal
	 */

	public WebElement getBtnDeletFav() {
		return waitForElement(DELETE_FAVORITE);
	}

	/**
	 * @return the Edit Fav Button in the modal
	 */

	public WebElement getBtnEditFav() {
		return waitForElement(EDIT_FAVORITE);
	}

	/**
	 * @return the Add Button in the modal
	 */

	public WebElement getBtnAdd() {
		return waitForElement(BTN_ADD);
	}

	/**
	 * @return the input text box in the modal
	 */

	public WebElement getInInputext() {
		return waitForElement(INPUT_TEXT);
	}

	/**
	 * @return the chiclets
	 */

	//	public WebElement getSpnChiclets() {
	//		return waitForElementToBeVisible(SPN_CHICLETS);
	//	}

	public WebElement getSpnChiclets() {
		if(getDevice().equals("NonMobile"))
		{
			return waitForElementToBeVisible(SPN_CHICLETS);
		}else
		{
			return waitForElementToBeVisible(spnMobChiclet);
		}

	}

	/**
	 * @return the Add Schedule To Fav link
	 */

	public WebElement geBtnAddScheduleToFav() {
		return waitForElement(BTN_ADDSCHEDULETOFAV);
	}

	/**
	 * @return the Login link
	 */

	public WebElement getLnkLogin() {
		return waitForElement(LNK_LOGIN);
	}

	/**
	 * @return the Favorite button
	 */

	public WebElement getBtnFavorite() {
		return waitForElement(BTN_FAVORITES);
	}

	/**
	 * @return the AshtangaVinyasa filter button
	 */
	public WebElement getBtnPickASpot() {
		return waitForElement(BTN_PICKSPOT);
	}

	/**
	 * @return the AshtangaVinyasa filter button
	 */
	public WebElement getDivAshtangaVinyasa() {
		return waitForElement(DIV_ASHTANGAVINYASA);
	}

	/**
	 * @return the AshtangaVinyasa filter button
	 */
	public WebElement getLblAshtangaVinyasa() {
		// return waitForElement(LBL_CLASSNAMR_ASHTANGAVINYASA_FILTER);
		return waitForElement(LBL_CLASSNAMR_ASHTANGAVINYASA_FILTER);
	}

	/**
	 * @return the Yoga filter button
	 */
	public WebElement getLblYoga() {
		return waitForElement(LBL_INTEREST_YOGA_FILTER);
	}

	/**
	 * @return the Yes button
	 */
	public WebElement getBtnYes() {
		return waitForElement(BTN_YES);
	}

	/**
	 * @return the Cancel Reservation
	 */
	public WebElement getBtnCancelReservation() {
		return waitForElement(BTN_CANCELRESERVATION);
	}

	/**
	 * @return the booking of seat nu-65
	 */
	public WebElement getBookASeat() {
		return waitForElement(SPN_BOOKASEAT);
	}

	/**
	 * @return the next Week
	 */
	public WebElement getBtnNextWeek() {
		return waitForElement(BTN_NEXTWEEK);
	}

	public WebElement getBtnPreviousWeek() {
		return waitForElement(BTN_PREVIOUSWEEK);
	}

	public WebElement getNextAvailableDate(int dayOfWeek) {
		return waitForElement(By.xpath("(//div[@class='day-heading']//input)["+dayOfWeek+"]"));
	}

	/**
	 * @return the nterest Filter
	 */
	public WebElement getBtnInterest() {
		return waitForElement(BTN_INTEREST);
	}

	/**
	 * @return the Cycling under Interest Filter
	 */
	public WebElement getLblinterestCyclingFilter() {
		return waitForElement(LBL_INTEREST_CYCLING_FILTER);
	}

	/**
	 * @return the Class Name Filter
	 */
	public WebElement getBtnClassNameFilter() {
		return waitForElement(BTN_CASSNAME);
	}

	/**
	 * @return the EDG Cycling under ClassName Filter
	 */
	public WebElement getLblClassNameEDGCyclingFilter() {
		return waitForElement(LBL_CLASSNAME_EDGCYCLING_FILTER);
	}

	/**
	 * @return the 1st occurance of EDG Cycling tile
	 */
	public WebElement getDivEdgeCycling() {
		return waitForElementToBeVisible(DIV_EDGCYCLING);
	}

	/**
	 * @return all occurance of event
	 */
	public List<WebElement> getDivEdgesCycling() {
		return waitForElementsToBeClickable(DIV_EDGCYCLING_XPATH);
	}

	/**
	 * @return the Reserve button
	 */
	public WebElement getBtnResrve() {
		return waitForElement(BTN_RESERVE);
	}

	/**
	 * @return the MyReservation button
	 */
	public WebElement getBtnMyReservations() {
		return waitForElement(BTN_RESERVATIONS);
	}

	/**
	 * @return the Filters button
	 */
	public WebElement getBtnFilters() {
		return waitForElement(BTN_FILTERS_EXPAND);
	}

	public ClassSchedulesPage clickOnFilter() throws InterruptedException {
		clickElement(getBtnFilters());
		return new ClassSchedulesPage(driver);
	}

	/**
	 * @return the Instructor button
	 */
	public WebElement getBtnInstructor() {
		return waitForElement(BTN_INSTRUCTOR);
	}

	/**
	 * @return the Tammi P checkbox
	 */
	public WebElement getSpnTammiP() {
		return waitForElement(SPN_TAMMIP);
	}

	/**
	 * @return the Time Of day button
	 */
	public WebElement getBtnTimeOfDay() {
		return waitForElement(BTN_TIME_OF_DAY);
	}

	/**
	 * @return the Midday checkbox
	 */
	public WebElement getLblMidday() {
		return waitForElement(LBL_MIDDAY);
	}

	/**
	 * @return the Team Boot Camp span
	 */
	public WebElement getSpnEdgRt() {
		return waitForElement(SPN_EDGRT);
	}

	/**
	 * @return the Team Boot Camp header
	 */
	public WebElement getHdrEdgRt() {
		return waitForElement(HDR_EDGRT);
	}


	/**
	 * Select Items from filter
	 * @param parentFilterItem
	 * @param childFilterItem
	 */
	public void selectItemFromFilter(String parentFilterItem, String childFilterItem) {

		String mainFullXpath = String.format(PARENT_FILTER_ITEM, parentFilterItem);
		String sunFullXpath = String.format(CHILD_FILTER_ITEM, childFilterItem);

		new Utility(driver).wait(2);
		clickElement(driver.findElement(By.xpath(mainFullXpath)));
		new Utility(driver).wait(2);
		clickElement(driver.findElement(By.xpath(sunFullXpath)));
	}

	/**
	 * Method to reserve a spot
	 * @return
	 */
	public ClassSchedulesPage reserveASpot() {
		try {
			clickElement(getBtnPickASpot());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ClassSchedulesPage(driver);
	}


	/**
	 * Method to navigate to next week
	 * @return
	 */
	public ClassSchedulesPage navigateToNextWeek() {
		try {
			clickElement(getBtnNextWeek());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ClassSchedulesPage(driver);
	}

	/**
	 * Method to navigate to next fifteenth day 
	 * @return
	 */
	public ClassSchedulesPage navigateToNextFifteenDay() {
		try {
			clickElement(getBtnNextWeek());
			clickElement(getBtnNextWeek());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ClassSchedulesPage(driver);
	}



	/**
	 * Method to Select the Instructor
	 * 
	 * @return
	 */
	public ClassSchedulesPage selectInstructor() {
		try {
			clickElement(getBtnInstructor()); // Click the Instructors button

			clickElement(getSpnTammiP()); // Click the TammiP checkbox

			clickElement(getBtnInstructor()); // Click the Instructors button

			wait(2); // waits for 2 seconds for application load

			return new ClassSchedulesPage(driver);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Method to Select the TimeOfDay
	 * 
	 * @return
	 */
	public ClassSchedulesPage selectTimeOfDay() {
		try {
			clickElement(getBtnTimeOfDay()); // Click the TimeOfDay button

			clickElement(getLblMidday()); // Click the Midday

			wait(2);

			return new ClassSchedulesPage(driver);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Method to verify the confirmation and Cancel reservations
	 * @param value
	 * @return
	 */
	public ClassSchedulesPage verifyConfirmationAndCancellationReservation(String value) {
		try {

			isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);

			clickElement(getBtnCancelReservation()); // Clicking on the cancel reservation
			clickElement(getBtnYes()); // Clicking on the YES button for confirmation

			isTextPresent(By.xpath("//ul[@class='list-unstyled reservation-list']"), value);

			return new ClassSchedulesPage(driver);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Method to navigate to next 30 days
	 * @return
	 */
	public ClassSchedulesPage navigateToNext30Day() {
		try {
			for (int i = 0; i <= 4; i++) {
				clickElement(getBtnNextWeek());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ClassSchedulesPage(driver);
	}

	/**
	 * Method to selectTime
	 * @return
	 */
	public ClassSchedulesPage selectTime() {
		clickElement(DIV_EDGCYCLING);
		return new ClassSchedulesPage(driver);
	}

	/**
	 * Method to Select the available class
	 * @param location
	 */
	public void selectAvailableClass(String location) {
		// TODO Auto-generated method stub
		try
		{
			wait(2);
			int dayOfWeek = getDayOfWeek();
			List<WebElement> tiles = driver.findElements(By.xpath("//div[@ui-view='calendar']//div[@class='calendar']"
					+ "//a[@class='card card-notecard card-block ng-scope']"
					+ "/p[contains(.,'Reserve')]/ancestor::a"));
			String weekDayName = getWeekDayName(dayOfWeek);
			if(tiles.size() == 0 && !getDevice().equals("Mobile"))
			{
				clickElement(getBtnNextWeek());
				tiles = driver.findElements(By.xpath("//div[@ui-view='calendar']//div[@class='calendar']"
						+ "//a[@class='card card-notecard card-block ng-scope']"
						+ "/p[contains(.,'Reserve')]/ancestor::a"));
				if(tiles.size() == 0)
				{
					for( int i=1;i<=tiles.size();i++)
					{

						if(!driver.findElement(By.xpath("(//div[@ui-view='calendar']//div[@class='calendar']"
								+ "//a[@class='card card-notecard card-block ng-scope']"
								+ "/p[contains(.,'Reserve')]/ancestor::a/../..)["+ i +"]")).getText().contains(weekDayName))
						{
							clickElement(tiles.get(i-1));
							break;
						}
					}
				}else
				{
					clickElement(tileWithoutReserve);
				}
			}else
			{
				for( int i=1;i<=tiles.size();i++)
				{

					if(!driver.findElement(By.xpath("(//div[@ui-view='calendar']//div[@class='calendar']"
							+ "//a[@class='card card-notecard card-block ng-scope']"
							+ "/p[contains(.,'Reserve')]/ancestor::a/../..)["+ i +"]")).getText().contains(weekDayName))
					{
						clickElement(tiles.get(i-1));
						break;
					}
				}
			}




			if (getDevice().equals("Mobile")) {
				if(dayOfWeek < 5)
				{
					clickElement(getNextAvailableDate(dayOfWeek + 1));
				}else
				{
					clickElement(getBtnNextWeek());
					clickElement(getNextAvailableDate(1));
				}
				boolean tile = false;
				for(int j=1;j<3;j++)
				{

					int i = dayOfWeek;
					while(i < 5)
					{
						if(isElementPresent(DIV_EDGCYCLING) == false)
						{
							clickElement(getNextAvailableDate(i + 1));
						}else
						{
							tile = true;
							break;
						}
						i++;
					}

					if(tile == false)
					{
						clickElement(getBtnNextWeek());
					}
					else
					{
						break;
					}
				}
				if(isElementPresent(getDivEdgeCycling()))
				{
					clickElement(getDivEdgeCycling());				
				}else
				{
					clickElement(tileWithoutReserve); // Selecting the 1st occurance of the EDG Cycling after
				}
			}

			/*if (dayOfWeek > 2) {
				clickElement(getBtnNextWeek());
			}*/



			verifyPageTitle("Class Details"); // Verifying the page title

			new ReservationsPage(driver).cancelReservationInUI("cancel");

			//verifyPageTitle("Class Details - " + location); // Verifying the page title
			verifyPageTitle("Class Details"); // Verifying the page title


		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	/**
	 * Method to login and navigate to Class Schedules page and select filters
	 * @param location
	 * @param interest
	 * @param className
	 */
	public void navigateToSchedulesPageAndSelectFilters(String location, String interest, String className) 
	{
		try {
			if(location.equalsIgnoreCase("chanhassen"))
			{
				driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
			}else
			{
				new HomePage(driver).searchLocation(location);
			}			

			//verifyPageTitle(location);
			new HomePage(driver).navigateToClassSchPage(); // Navigate to Class Schedule page from member page
			//verifyPageTitle("Schedules - " + location); // Verifying the page title

			clickOnFilter().wait(5);

			selectItemFromFilter("Interest", interest);
			selectItemFromFilter("Class Name", className);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	/**
	 * Method to login and navigate to Class Schedules page and select filters with instructor
	 * @param location
	 * @param interest
	 * @param className
	 * @param instructor
	 */
	public void navigateToSchedulesPageAndSelectFilters(String location, String instructor, String interest, String className) 
	{
		try {
			if(location.equalsIgnoreCase("chanhassen"))
			{
				driver.navigate().to(EnvConfig.getInstance().getPrefix() + "www.mylt.life/clubs/mn/chanhassen.html");
			}else
			{
				new HomePage(driver).searchLocation(location);
			}			

			verifyPageTitle(location);
			new HomePage(driver).navigateToClassSchPage(); // Navigate to Class Schedule page from member page
			//verifyPageTitle("Schedules - " + location); // Verifying the page title

			clickOnFilter().wait(5);

			selectItemFromFilter("Instructor", instructor);
			selectItemFromFilter("Interest", interest);
			selectItemFromFilter("Class Name", className);

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	/**
	 * Method to verify the Favorites
	 */
	public void verifyFavourites()
	{
		Properties envProperties = EnvConfig.getInstance().getEnvProperties();
		clickElement(getBtnFavorite());
		clickElement(geBtnAddScheduleToFav());
		clickElement(getLnkLogin());

		new LoginPage(driver).login(envProperties.getProperty("login.member.user"), 
				envProperties.getProperty("login.member.password"));

		String numberAsString = getRandomIntegerAsString();
		String name = Constants.SaveAsFavText + numberAsString;

		enterText(getInInputext(), name);

		clickElement(getBtnAdd());

		isTextPresent(getTextContainer(), Constants.SuccessMessage);

		clickElement(getBtnShowOrHideFav());

		clickElement(getBtnEditFav());

		String numberAsString1 = getRandomIntegerAsString();
		String editedName = Constants.EditFavText + numberAsString1;

		enterText(getInputEdit(), editedName);
		clickElement(getBtnSavEdit());

		isTextPresent(getTextContainer(), Constants.EditSuccessMessage);

		clickElement(getBtnDeletFav());
		clickElement(getBtnDelFav());
	}

	public String addFavourites()
	{

		clickElement(geBtnAddScheduleToFav());
		String numberAsString = getRandomIntegerAsString();
		String name = Constants.SaveFavText + numberAsString;
		enterText(getInInputext(), name);
		clickElement(getBtnAdd());
		isTextPresent(getTextContainer(), Constants.SuccessMessage);
		return name;


	}

	public void DeleteFavourites()
	{
		Utility util = new Utility(driver);
		clickElement(getBtnShowOrHideFav());
		clickElement(getBtnDeletFav());
		clickElement(getBtnDelFav());
		//alertMsgNoFavSched();
		//clickElement(getBtnShowOrHideFav());
		Assert.assertTrue(util.isTextPresent(alertMsgNoFavSched(), Constants.YOU_HAVE_N0_FAV_MSG));

	}

	public void deleteAllFavourites()
	{
		Utility util = new Utility(driver);
		String pageTitle = driver.getTitle();
		wait(5);       
		waitForElementToBeClickable(getBtnShowOrHideFav());
		List<WebElement> removeLinks = driver.findElements(DELETE_FAVORITE);
		System.out.println(removeLinks.size());
		if( removeLinks.size() != 0)
		{
			int counter = removeLinks.size();
			for(int i=0; i< counter; i++)
			{               
				List<WebElement> removeItems = driver.findElements(DELETE_FAVORITE);
				for(WebElement removeItem : removeItems )
				{
					/*if(verifyElementVisible(removeItem) == false)
                    {
                        waitForElementToBeClickable(ImgCart);
                        clickElement(ImgCart);
                    }*/
					wait(5);
					waitForElementToBeClickable(getBtnShowOrHideFav());
					clickElement(removeItem);
					waitForElementToBeClickable(BTN_DEL_YES);
					clickElement(BTN_DEL_YES);
					wait(5);

					verifyPageTitle(pageTitle);
					break;
				}
			}
		}
		clickElement(getBtnShowOrHideFav());
		util.wait(5);
		Assert.assertTrue(util.isTextPresent(alertMsgNoFavSched(), Constants.YOU_HAVE_N0_FAV_MSG));
	}
	public void verifyLinksAreSupppressed() {
		Utility util = new Utility (driver);


		Assert.assertTrue(util.isTextPresent(gethdrClassSchedules(), Constants.hdrClassSchedules));
		Assert.assertFalse(util.isElementPresent(BTN_HIDEORDISPLAYFAV));
		Assert.assertFalse(util.isElementPresent(lnkHelp));
		Assert.assertFalse(util.isElementPresent(btnPrintWeek));
		Assert.assertFalse(util.isElementPresent(addfav)); 
	}

	public void verifyDropdowns() {
		Utility util = new Utility (driver);
		Assert.assertTrue(util.isElementPresent(getDrpdwnInterest()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnClassName()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnAddClubLoc()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnTimeOfDay()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnAge()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnSkillLevel()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnIntensity()));
		Assert.assertTrue(util.isElementPresent(getDrpdwnInstructor()));
	}

	public ClassSchedulesPage navigateToNextWeekandClick() {
		try {
			waitAndClickElement(getBtnNextWeek());
			waitAndClickElement(getDivEdgeCycling()); 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ClassSchedulesPage(driver);
	}
}


