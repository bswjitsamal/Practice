package net.lt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import net.lt.common.Constants;
import net.lt.common.Utility;

/*******************************************************************************
 * Class for Login Page
 */
public class LoginPage extends Utility {

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */
	private static final By txtUserName = By.xpath(".//input[@id='account-username']");
	private static final By txtPassword = By.xpath(".//input[@id='account-password']");
	private static final By btnLogin = By.xpath(".//button[@id='login-btn']");	

	/******************************************************************************/

	/**
	 * Method for login functionality
	 */
	public void login(String a_username, String a_password) {
		try {
			verifyPageTitle(Constants.LOGIN_PAGE_TITLE);			
			enterText(waitForElement(txtUserName), a_username);		
			enterText(waitForElement(txtPassword), a_password);		
			clickElement(waitForElement(btnLogin));			
			wait(3);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
