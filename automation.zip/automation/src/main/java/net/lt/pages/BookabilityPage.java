package net.lt.pages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Utility;

public class BookabilityPage extends Utility {

	public BookabilityPage(WebDriver driver) {
		super(driver);
	}

	private static final By LBL_SELECTpARTICIPANT = By
			.xpath(".//*[@id='main-content']//fieldset/span/legend/following-sibling::label");
	private static final By SELECT_DATE = By.xpath(".//*[@id='ff-selectDate']");
	private static final By SELECT_TIME = By.xpath(".//*[@id='ff-selectTime']");
	// private static final String CLICK_NEXT="//button[contains(text(),'Next')]";
	private static final By CLICK_NEXT = By.xpath("//button[contains(text(),'Next')]");
	private static final By FIRST_PARTICIPANT_NAME = By
			.xpath(".//*[@id='main-content']//fieldset/span/legend/following-sibling::label[1]");
	private static final By PARTICIPANT_NAME = By.xpath(".//*[@id='headerNav']//span[@class='js-login-label']");
	private static final By BTN_LOGOUT = By.xpath(".//*[@id='utilAccount']//a[text()='Log Out']");

	/**
	 * @return the Loged in user name
	 */
	public WebElement getBtnLogOut() {
		return waitForElementToBeClickable(BTN_LOGOUT);
	}

	/**
	 * @return the Loged in user name
	 */
	public WebElement getloggedInName() {
		return waitForElementToBeClickable(PARTICIPANT_NAME);
	}

	/**
	 * @return the 1st participant name
	 */
	public WebElement get1stName() {
		return waitForElementToBeClickable(FIRST_PARTICIPANT_NAME);
	}

	/**
	 * @return the Next btn
	 */
	public WebElement getBtnNext() {
		return waitForElementToBeClickable(CLICK_NEXT);
	}

	/**
	 * @return the participant from the screen
	 */
	public WebElement getLblParticipant() {
		return waitForElementToBeClickable(LBL_SELECTpARTICIPANT);
	}

	/**
	 * @return the date from the drop-down
	 */
	public WebElement getSelectDate() {
		return waitForElementToBeClickable(SELECT_DATE);
	}

	/**
	 * @return the time from the drop-down
	 */
	public WebElement getSelectTime() {
		return waitForElementToBeClickable(SELECT_TIME);
	}

	public ArrayList<String> getParticipantName() {
		// System.out.println(getValue(LBL_SELECTpARTICIPANT));
		return getValue(LBL_SELECTpARTICIPANT);
	}
}
