package net.lt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Utility;

public class ReservationConfirmationPage extends Utility {

	public ReservationConfirmationPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */

	private static final By BTN_VIEW_ALLRESERVATIONS = By.xpath("//a[text()='View All Reservations']");
	private static final By BTN_MAKR_ANOTHER_RESERVATIONS = By
			.xpath("//a[contains(text(),'Make Another Reservation')])");
	private static final By BTN_ADDTOCALENDAR = By.xpath("//button[text()='Add to Calendar']");
	private static final By ADDTOCALENDAR = By.xpath("//div[@class='modal-dialog']//button[text()='Add to Calendar']");
	private static final By ConfirmationMsg = By.xpath("//h1[text()='Your reservation is complete.']");
	
	private static final By ConfirmationThankyou = By.xpath("//p[@class='alert alert-info m-b-0']");
	
	
	
	
	public WebElement getConfirmation() {
		return waitForElementToBeVisible(ConfirmationThankyou);
	}
	
	
	
	
	public WebElement getConfirmationText() {
		return waitForElementToBeVisible(ConfirmationMsg);
	}
	
	/**
	 * @return view all Reservation btn
	 */
	public WebElement geBtnViewAllReservations() {
		return waitForElementToBeVisible(BTN_VIEW_ALLRESERVATIONS);
	}

	/**
	 * @return view Make another Reservation btn
	 */
	public WebElement getBtnMakeAnotherReservation() {
		return waitForElementToBeVisible(BTN_MAKR_ANOTHER_RESERVATIONS);
	}

	/**
	 * @return view Make another Reservation btn
	 */
	public WebElement geBtnAddToCalendar() {
		return waitForElementToBeVisible(BTN_ADDTOCALENDAR);
	}

	public WebElement geBtnAddToCalendarModal() {
		return waitForElementToBeVisible(ADDTOCALENDAR);
	}

}
