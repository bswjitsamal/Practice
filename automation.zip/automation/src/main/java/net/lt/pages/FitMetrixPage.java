package net.lt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Utility;

public class FitMetrixPage extends Utility {

	public FitMetrixPage(WebDriver driver) {
		super(driver);
	}

	private static final By SPN_BOOKASEAT = By.xpath(".//div[starts-with(@id, 'seat-')]");
	private static final By BTN_PICKSPOT = By.xpath(".//*[@id='pmdBtn']");
	private static final By BTN_RESERVATIONS = By.xpath("//*[text()='Reservations']");
	private static final By BTN_ADDTOCALENDAR = By.xpath(".//*[@id='ltfcAdd']");
	private static final By BTN_OUTLOOK = By.xpath(".//*[@id='ltfcAdd']//a[text()='Outlook Calendar']");

	/******************************************************************************************************/

	public WebElement getBtnAddToOutLookCalendar() {
		return waitForElementToBeClickable(BTN_OUTLOOK);
	}

	public WebElement getBtnAddToCalendar() {
		return waitForElementToBeClickable(BTN_ADDTOCALENDAR);
	}

	/**
	 * @return the MyReservation button
	 */
	public WebElement getBtnMyReservations() {
		return waitForElementToBeClickable(BTN_RESERVATIONS);
	}

	/**
	 * @return the booking of seat nu-65
	 */
	public WebElement getBookASeat() {
		return waitForElementToBeClickable(SPN_BOOKASEAT);
	}

	public FitMetrixPage selectASpot() {
		try {
			clickElement(getBookASeat());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new FitMetrixPage(driver);
	}

	/**
	 * @return the AshtangaVinyasa filter button
	 */
	public WebElement getBtnPickASpot() {
		return waitForElement(BTN_PICKSPOT);
	}

	public FitMetrixPage reserveASpot() {
		try {
			clickElement(getBtnPickASpot());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new FitMetrixPage(driver);
	}

}