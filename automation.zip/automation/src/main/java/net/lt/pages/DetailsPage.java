package net.lt.pages;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Constants;
import net.lt.common.Utility;
import net.lt.config.EnvConfig;

public class DetailsPage extends Utility {

	public DetailsPage(WebDriver driver) {
		super(driver);
	}

	Properties envProperties = EnvConfig.getInstance().getEnvProperties();
	/*******************************************************************************
	 * Parameter xpath variables
	 */

	//private final By btnReserve = By.xpath("//button[contains(text(),'Reserve')]");
	//private final By btnReserve = By.xpath("(//button[text()='Reserve'])[2]");
	//private final By btnAddToCalendar  = By.xpath("//p/button[contains(text(),'Add to Calendar')]");
	private final By btnAddToCalendar  = By.xpath("(//button[text()='Add to Calendar'])[1]");
	private static final By BTN_EDITRESERVATIONS = By.xpath("//header//button[text()='Edit Reservation']");
	public final By LNK_CANCELRESERVATION = By.xpath("//header//button[text()='Cancel Reservation']");
	private static final By P_SPOTSREMAINING = By.xpath("//header//p[contains(.,'spots remaining')]");
	private static final By SPN_STSRT_DATE = By.xpath("//span[@class='ico-calendar']/following-sibling::span");
	private static final By PRICE = By
			.xpath("//header//button[text()='Reserve']/ancestor::p//preceding-sibling::p/strong");
	private static final String BTN_YES_ = ".//*[@id='0cancel']//button[text()='No']/following-sibling::button";
	private static final String BTN_YES = ".//*[@aria-hidden='false']//button[text()='Yes']";
	private static final String _BTN_YES_ = ".//*[contains(@id,'cancel')]//button[text()='Yes']";
	private static final By BTN_LOGINDETAIL = By.xpath("//span[@class='js-login-label']");
	private static final By LNK_VIEWACCOUNT = By.xpath("//a[contains(.,'View Account')]");
	private static final By LNK_RELATESTITEMS = By.xpath("//div[@class='row p-b-grid']//div[@class='bg-white p-a-1 m-b-sm']");
	private static final By LNK_HEADING_RELATEDITEMS = By.xpath("//div[@class='row p-b-grid']//div[@class='bg-white p-a-1 m-b-sm']//a[@class='font-weight-bold']//time");
	private static final By TXT_REGISTRATIONRECOMMENDED = By.xpath("(//p[contains(text(),'Registration Recommended')])[2]");
	private static final By TXT_REGISTRATIONREQUIRED = By.xpath("//p[contains(text(),'Registration Required')]");
	private static final By LnkClassSchedules = By.xpath("//a[text()='Class Schedules']");

	private static final By txtEndDate = By.xpath("//p[contains(text(),'Ends')]");
	//private static final By hdrRegistration = By.xpath("//div[@class='details-section hidden-sm-down col-xs-4']//h2[text()='Registration']");
	private static final By hdrRegistration = By.xpath("(//h2[text()='Registration'])[2]");

	private static final By hdrWhatToExpect = By.xpath("//h2[text()='What to Expect']");
	//private static final By btnLoginToReserve = By.xpath("//button[text()='Log in to Register']");
	private static final By btnLoginToReserve = By.xpath("(//button[text()='Log in to Reserve'])[2]");
	private static final By btnMobLoginToReserve = By.xpath("(//button[text()='Log in to Reserve'])[1]");
	private static final By lnkInstructor = By.xpath("//button[text()='Add to Calendar']/..//a");
	private static final By txtMoreSection = By.xpath("//div[@class='row p-t-2']//h2");
	//private static final By txtInstructor = By.xpath("//a[text()='Aaron W.']");
	private static final By txtInstructor = By.xpath("//button[text()='Add to Calendar']/preceding-sibling::p[2]/span/span");
	private static final By btnOutlook = By.xpath(".//*[@id='ltfcAdd']//a[text()='Outlook Calendar']");
	private static final By txtSpotsAvailable = By.xpath("(//p[contains(text(), 'spot')])[2]");
	private static final By txtMobSpotsAvailable = By.xpath("(//p[contains(text(), 'spot')])[1]");
	private static final By PostEdgCycle = By.xpath("//div[@class='vjs-poster']");
	private static final By btnReserve = By.xpath("(//button[contains(text(),'Reserve')])[2]");
	private static final By btnMobReserve = By.xpath("(//button[contains(text(),'Reserve')])[1]");
	private static final By hdrMobRegistration = By.xpath("(//h2[text()='Registration'])[1]");
	public final By BTN_EDIT = By.xpath("//div[@class='details-section hidden-sm-down col-xs-4']//button[contains(text(),'Edit')]");
	public final By BTN_RESERVE = By.xpath("//div[@class='details-section hidden-sm-down col-xs-4']//button[contains(text(),'Reserve')]");



	public WebElement PostEDGcycle() {
		return waitForElement(PostEdgCycle);
	}

	public WebElement getTxtSpotsAvailable() {
		//		return waitForElement(txtSpotsAvailable);


		if(getDevice().equals("NonMobile"))
		{
			return waitForElementToBeVisible(txtSpotsAvailable);
		}else
		{
			return waitForElementToBeVisible(txtMobSpotsAvailable);
		}
	}
	
	public WebElement getBtnResrve() {
		return waitForElement(BTN_RESERVE);
	}

	public WebElement getBtnEdit() {
		return waitForElement(BTN_EDIT);
	}
	
	public WebElement getTxtInstructor() {
		return waitForElement(txtInstructor);
	}
	public WebElement getMoreSection() {
		return waitForElement(txtMoreSection);
	}
	public WebElement getLnkInstructor() {
		return waitForElement(lnkInstructor);
	}
	public WebElement getBtnLoginToReserve() {
		if(getDevice().equals("NonMobile"))
		{
			return waitForElementToBeVisible(btnLoginToReserve);
		}else
		{
			return waitForElementToBeVisible(btnMobLoginToReserve);
		}
	}
	public WebElement getHdrWhatToExpect() {
		return waitForElement(hdrWhatToExpect);
	}
	

	public WebElement getHdrRegistration() {
		if(getDevice().equals("NonMobile"))
		{
			return waitForElementToBeVisible(hdrRegistration);
		}else
		{
			return waitForElementToBeVisible(hdrMobRegistration);
		}
	}


	public WebElement getClassEndDate() {
		return waitForElement(txtEndDate);
	}

	public WebElement getLnkClassSchedules() {
		return waitForElement(LnkClassSchedules);
	}

	public WebElement getbtnAddToCalendar() {

		return waitForElementToBeVisible(btnAddToCalendar);
	}


	/**
	 * @return the view related items
	 */

	public WebElement getViewHeadingRelatedItems() {
		return waitForElement(LNK_HEADING_RELATEDITEMS);
	}


	public WebElement getViewRegistrationRequired() {
		return waitForElement(TXT_REGISTRATIONREQUIRED);
	}

	/**
	 * @return the text under Registration
	 */

	public WebElement getViewRegistrationRecommended() {
		return waitForElement(TXT_REGISTRATIONRECOMMENDED);
	}


	/**
	 * @return the view related items
	 */

	public List<WebElement> getViewRelatedItems() {
		return waitForElementsToBeVisible(LNK_RELATESTITEMS);
	}

	/**
	 * @return the view Account
	 */
	public WebElement getViewAccount() {
		return waitForElement(LNK_VIEWACCOUNT);
	}

	/**
	 * @return the LoginDetails
	 */
	public WebElement getLoginDetails() {
		return waitForElement(BTN_LOGINDETAIL);
	}

	/**
	 * @return the Price
	 */
	public WebElement getEditReservation() {
		return waitForElement(BTN_EDITRESERVATIONS);
	}

	/**
	 * @return the Price
	 */
	public WebElement getCancelReservation() {
		return waitForElement(LNK_CANCELRESERVATION);
	}

	/**
	 * @return the Price
	 */
	public WebElement getPrice() {
		return waitForElement(PRICE);
	}

	/**
	 * @return the Reserve button
	 */
	public WebElement getSpnStartDate() {
		return waitForElement(SPN_STSRT_DATE);
	}

	/**
	 * @return the Reserve button
	 */
	public WebElement getBtnReserve() {
		if(getDevice().equals("NonMobile"))
		{
			return waitForElementToBeVisible(btnReserve);
		}else
		{
			return waitForElementToBeVisible(btnMobReserve);
		}

	}

	/**
	 * @return the Reserve button
	 */
	public By getBtnReserveByLocator() {
		return btnReserve;
	}



	/**
	 * @return the spots remaining
	 */
	public By getParSpotsRemaining() {
		return P_SPOTSREMAINING;
	}

	public String eventPrice() {
		return (getPrice().getText().replaceAll("\\\\$", ""));
	}

	public DetailsPage _checkReserveButton() {
		isElementPresent(btnReserve);
		return new DetailsPage(driver);
	}

	public WebElement getBtnYes() {
		return waitForElementToBeClickable(BTN_YES);
	}

	/**
	 * Method to verify Confirmation and Cancel reservation
	 * @param value
	 * @return
	 */
	public ReservationsPage verifyConfirmationAndCancellationReservation(String value) {
		try {

			waitAndClickElement(getCancelReservation()); // Clicking on the cancel reservation
			driver.switchTo().activeElement();
			waitAndClickElement(getBtnYes()); // Clicking on the YES button for confirmation
			wait(3);
			browserRefresh(1);
			waitAndClickElement(getBtnReserve()); // Clicking on the cancel reservation
			return new ReservationsPage(driver);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public DetailsPage clickOnAnyRelatedItems() throws InterruptedException {
		clickElement(getViewHeadingRelatedItems());
		return new DetailsPage(driver);
	}



	public void reserveClass()
	{
		FitMetrixPage fitmetrixPg = new FitMetrixPage(driver);
		if (isElementPresent(getBtnReserve())) {			
			clickElement(getBtnReserve()); // The page redirects to the class detail page , clicking
			// on the reserve button
			
			if(driver.getTitle().contains("Login"))
			{
				new LoginPage(driver).login(envProperties.getProperty("login.member.user"),
						envProperties.getProperty("login.member.password"));
				verifyPageTitle("Class Details");
				new ReservationsPage(driver).cancelReservationInUI("cancel");
				clickElement(getBtnReserve());
			}
			if(!driver.getTitle().contains(Constants.LifeTimeFitnessReservations))
			{
				fitmetrixPg.selectASpot(); // Selecting an available seat
				fitmetrixPg.reserveASpot();
			}
		}
		else
		{
			new ReservationsPage(driver).cancelReservationInUI("cancel");
			//verifyPageTitle("Reservations");
		}
		//verifyPageTitle(Constants.LifeTimeFitnessReservations);
		verifyPageTitle("Reservations");
	}

	public void reservePickSpotClass() throws InterruptedException
	{
		System.out.println("WE are in Details page and redy to perform some action ");
		ReservationsPage resvePg = new ReservationsPage(driver);
		
		if (isElementPresent(BTN_EDIT)) {
			clickElement(getBtnEdit()); // The page redirects to the class detail page , clicking
			// on the reserve button
	
			resvePg.selectASpot();
			
		}else
		{
			clickElement(getBtnResrve()); // The page redirects to the class detail page , clicking
			// on the reserve button
			
			resvePg.selectASpot();
		}
		
	}


}