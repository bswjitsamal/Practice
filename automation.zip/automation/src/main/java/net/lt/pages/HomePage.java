package net.lt.pages;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Constants;
import net.lt.common.Utility;

/*******************************************************************************
 * Class for Members Page
 */
public class HomePage extends Utility {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */
	private static final By lnkClassSchedules = By.xpath(".//*[@id='primaryNav']//a[contains(.,'Schedules')]");
	private static final By lnkAllClasses = By.xpath("//a[contains(text(),'All Classes')]");
	private static final By lnkMembers = By.xpath("//a[text()='Members']");
	private static final By LNK_ACCOUNT = By
			.xpath(".//*[@id='headerNav']/div[@class='header-utility']//a[@class='nav-link dropdown-toggle']");
	private static final By BTN_LOGIN = By.xpath("//a[text()='Log In']");
	private static final By LNK_VIEW_ACCOUNT = By.xpath("//a[text()='View Account']");
	private static final By LNK_CREATE_ACCOUNT = By.xpath("//a[text(),'Create Account']");
	private static final By LNK_RESERVATION = By.xpath(
			".//*[@id='headerNav']/div[@class='header-utility']/nav[@class='header-utility-minor']/ul//a[contains(.,'Reservations')]");
	private static final By LNK_PROGRAMS = By.xpath("//a[text()='Programs']");

	private static final String PARENT_MENU = ".//*[@id='primaryNav']//a[contains(.,'%s')]";
	private static final String CHILD_MENU = ".//*[@id='primaryNav']//preceding-sibling::ul//a[contains(.,'%s')]";

	private static final By DRPDWN_CLUBSELECTOR = By.xpath(".//*[@id='headerNav']//button");
	private static final By DRPDWN_MOBVIEW_CLUBSELECTOR = By.xpath("//a[@aria-controls='clubLocator']");
	private static final String DIV_LOCATION = "//div[@class='col-xs-12 b-b b-b-lg-0 p-b-sm']//li[@class='m-b-sm']/a[text()='%s']";

	//private static final By INPUT_LOCATION = By.xpath(".//*[@id='clubsearch']");
	private static final By INPUT_LOCATION = By.xpath("//input[@id='clubsearch']");
	private static final By BTN_SEARCH = By.xpath("//span[@class='ico-search']");
	private static final By LNK_CLASS_DETAILS = By.xpath("//div[@class='results-scroll']//a[text()='Details']");
	private static final By LNK_FAVORITES_CASS_SCHEDULES = By.xpath(
			".//*[@id='main-content']/div[@class='content-section p-t-5']/div/div[@class='row']/div[@class='col-xs-12 col-lg-4 m-b-2']//a");
	private static final By LNK_UPCOMMINGRESRVATIONS = By.xpath(
			".//*[@id='main-content']/div[@class='content-section p-t-5']//div[@class='col-xs-12 col-lg-8 m-b-2']//h4");
	private static final By P_YOUHAVENOUpCoMMINGRESERVATIONS = By.xpath(
			".//*[@id='main-content']/div[@class='content-section p-t-5']//div[@class='col-xs-12 col-lg-8 m-b-2']//p[contains(text(),'You have no')]");
	private static final By LINK_EVENTS = By.xpath("//a[text()='Events']");
	private static final By LNK_ALLEVENTS = By.xpath("//a[text()='All Events']");
	private static final By BRIEFRESERVATION = By.xpath(".//*[@id='main-content']//ui-view/section/ul//div[1]/h4");
	
	private static final By ADDTOCAlENDAR = By
			.xpath(".//*[@id='main-content']//ui-view/section/ul//div[@class='res-block res-block-secondary']//a");
	private static final By MODALADDTOCALENDAR = By
			.xpath(".//*[@id='my-reservations-modal-0']/div//div/button[contains(.,'Add to Calendar')]");
	private static final By PAYMENT_OPTIOS = By.xpath("//a[contains(.,'Payment Options')]");
	private static final By ADDFORMOFPAYMENT = By
			.xpath("//div/h2[contains(.,'Club Tab')]/following-sibling::div/a[contains(.,' Add Form of Payment')]");
	private static final By textNoFavClassSched = By
			.xpath("//span[text()='No favorite class schedules']");
	private static final By LnkAddAfavorite = By
			.xpath("//a[text()='Add a Favorite']");
	private static final By LnkFavName = By
			.xpath("//a[@class='font-weight-bold hp-saved-sched']");
	private static final By membershipLevel = By
			.xpath("//p[@class='small text-muted']");
	//HomePage Components brief  xpath
	private static final By HomePgrescomp = By
			.xpath("//div[@id='schedules-component-element-62385eacb017e']");
	private static final By managereservation = By
			.xpath("//a[text()='Manage Reservations']");


	private static final By Tennis = By
			.xpath("(//p[@class='m-b-0'])[2]");
	private static final By Ashtang1 = By
			.xpath("(//p[@class='m-b-0'])[4]");
	private static final By Ashtang2 = By
			.xpath("(//p[@class='m-b-0'])[6]");
	private static final By court1Centennial = By
			.xpath("(//p[@class='m-b-0'])[3]");
	private static final By yogastudiochnhsn1 = By
			.xpath("(//p[@class='m-b-0'])[5]");
	private static final By yogastudiochnhsn2 = By
			.xpath("(//p[@class='m-b-0'])[7]");
	private static final By time1 = By
			.xpath("(//time[@class='time-start'])[4]");
	private static final By time2 = By
			.xpath("(//time[@class='time-start'])[5]");
	private static final By time3 = By
			.xpath("(//time[@class='time-start'])[6]");






	public WebElement Time1() {
		return waitForElement(time1);
	}
	public WebElement Time2() {
		return waitForElement(time2);
	}
	public WebElement Time3() {
		return waitForElement(time3);
	}
	public WebElement Court1Centennial() {
		return waitForElement(court1Centennial);
	}
	public WebElement Yogastudiochnhsn1() {
		return waitForElement(yogastudiochnhsn1);
	}

	public WebElement Yogastudiochnhsn2() {
		return waitForElement(yogastudiochnhsn2);
	}
	public WebElement TennisComponents() {
		return waitForElement(Tennis);
	}
	public WebElement Ashtanga1Components() {
		return waitForElement(Ashtang1);
	}
	public WebElement Ashtanga2Components() {
		return waitForElement(Ashtang2);
	}
	public WebElement HomePgResComponents() {
		return waitForElement(HomePgrescomp);
	}
	public WebElement MembershipLevel() {
		return waitForElement(membershipLevel);
	}
	public WebElement ManageReservations() {
		return waitForElement(managereservation);
	}

	public WebElement LinkFavoriteName() {
		return waitForElement(LnkFavName);
	}
	public WebElement LinkAddaFavorite() {
		return waitForElement(LnkAddAfavorite);
	}
	public WebElement gettextNoFavClassSched() {
		return waitForElement(textNoFavClassSched);
	}

	public WebElement getPYouHaveNoUpComingReservations() {
		return waitForElement(P_YOUHAVENOUpCoMMINGRESERVATIONS);
	}

	/**
	 * @return the Events link
	 */
	public WebElement getLnkEvent() {
		return waitForElement(LINK_EVENTS);
	}

	/**
	 * @return the All Events link
	 */
	public WebElement getLnkAllEvent() {
		return waitForElement(LNK_ALLEVENTS);
	}


	public ArrayList<String> getTextValuesUpComingReservations() {
		return getValue(LNK_UPCOMMINGRESRVATIONS);
	}

	public ArrayList<String> getTextValues() {
		return getValue(LNK_FAVORITES_CASS_SCHEDULES);
	}

	public WebElement getLnkReservation() {
		return waitForElement(LNK_RESERVATION);
	}

	public WebElement getResevationBrief() {
		return waitForElement(BRIEFRESERVATION);
	}

	/**
	 * Method to Select Location
	 * @param location
	 */
	public void selectLocation(String location) {

		String locationXpath = String.format(DIV_LOCATION, location);
		clickElement(getLocationMenu());
		clickElement(driver.findElement(By.xpath(locationXpath)));
	}

	/**
	 * Method to search for a location
	 * @param location
	 */
	public void searchLocation(String location) {

		clickElement(getLocationMenu());
		wait(2);
		enterText(waitForElement(INPUT_LOCATION),location);
		wait(2);
		clickElement(BTN_SEARCH);
		clickElement(LNK_CLASS_DETAILS);
	}


	/**
	 * @return the Programs menu
	 */
	public WebElement getLocationMenu() {
		if (getDevice().equals("Mobile")) {
			return waitForElement(DRPDWN_MOBVIEW_CLUBSELECTOR);
		} else {
			return waitForElement(DRPDWN_CLUBSELECTOR);
		}
	}


	/**
	 * Method to navigate to Class Schedules page
	 */
	public void navigateToClassSchPage() {
		try {
			if (driver.getTitle().contains(Constants.JOIN_PAGE_TITLE)) {
				clickElement(lnkMembers);
			} // Click the Members Link

			clickElement(lnkClassSchedules); // Click the ClassSchedule link

			clickElement(lnkAllClasses); // Click the All Classes link

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}


	/**
	 * Method to navigate to Program page
	 */
	public void navigateToPrograms(String programName) {
		try {
			clickElement(LNK_PROGRAMS); // Click the Programs Link

			clickElement(By.xpath("//a[text()='Programs']"
					+ "/parent::li/div//li/a[contains(text(),'" + programName + "')]"));	

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	

	/**
	 * Method to navigate to Program page
	 */
	public void verifyHomePageComponentsBrief() {
		HomePage homPg = new HomePage(driver);
		ClassSchedulesPage clsSchPg = new ClassSchedulesPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);



		List<String> Classes = new ArrayList<String>();
		Classes.add("Tennis Centennial Court");
		Classes.add("Ashtanga Vinyasa1");
		Classes.add("Ashtanga Vinyasa2");


		for( String obj : Classes)
		{



			if ( obj == "Tennis Centennial Court") {
				util.isElementPresent(TennisComponents().getText()); //verifying the first element 
				Assert.assertTrue(util.isTextPresent(Court1Centennial(), Constants.centennial));// verifying the location of first reserved class 
				//Assert.assertTrue(util.isTextPresent(homPg.Time1(), Constants.centennial));
				util.isElementPresent(Time1().getText());
			}


			else if (obj == "Ashtanga Vinyasa1") {
				util.isElementPresent(Ashtanga1Components().getText()); //verify second elemt
				Assert.assertTrue(util.isTextPresent(homPg.Yogastudiochnhsn1(), Constants.YogaChanhassen1)); //location
				util.isElementPresent(Time2().getText()); //time 
			}


			else if (obj == "Ashtanga Vinyasa2") {
				util.isElementPresent(homPg.Ashtanga2Components().getText()); //third element
				Assert.assertTrue(util.isTextPresent(homPg.Yogastudiochnhsn2(), Constants.YogaChanhassen2)); //location
				util.isElementPresent(homPg.Time3().getText()); //time
				util.isTextPresentAndClickText(homPg.Ashtanga2Components(), "Ashtanga Vinyasa");
				util.verifyPageTitle(Constants.Chanhassen);
				util.waitAndClickElement(clsSchPg.getlifetimelogo());
				util.waitAndClickElement(homPg.ManageReservations());
				util.verifyPageTitle(Constants.CourtReservations);
			}

		}
	}
	/**
	 * Method 
	 */
	public void verifyReservationNotPresent() {
		HomePage homPg = new HomePage(driver);
		ClassSchedulesPage clsSchPg = new ClassSchedulesPage(driver);
		LoginPage lgnPg = new LoginPage(driver);
		Utility util = new Utility(driver);
	Assert.assertFalse(util.isTextPresent(By.xpath(".//*[@id='main-content']//ui-view/section"), "Conference Room"));
	}
}
