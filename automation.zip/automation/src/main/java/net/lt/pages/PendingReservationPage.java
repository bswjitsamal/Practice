package net.lt.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Constants;
import net.lt.common.Utility;
import okhttp3.internal.Util;

public class PendingReservationPage extends Utility {

	public PendingReservationPage(WebDriver driver) {
		super(driver);
	}

	/*******************************************************************************
	 * Parameter xpath variables
	 */
	private static final By chkBoxTermsAndCondition = By
			.xpath(".//*[@id='main-content']//input[@id='acceptwaiver']/following-sibling::span");
	private static final By btnContinueToPayment = By.xpath("//button[contains(text(),'Continue to Payment')]");
	private static final By lnkCancel = By.xpath("//button/preceding-sibling::a[contains(text(),'Cancel')]");	
	private static final By btnFinish = By.xpath("//button[contains(text(),'Finish')]");


	private static final By txtTimeLeftToComplete = By
			.xpath(".//*[@id='main-content']//p[contains(.,'Time left to complete:')]//strong");

	private static final By lnkResPolicyWaiver = By.xpath("//a[@class='link-underlined small text-nowrap']");
	//private static final By txtResPolicyWaiver = By.xpath("//h2[contains(text(),'Reservation Policy and Waiver')]");
	private static final By txtResPolicyWaiver = By.xpath("//div[@class='modal-header']//h5[text()='Reservation Policy and Waiver']");


	private static final By txtTax = By.xpath("//p[@class='card-price']");
	private static final By txtTitle = By.xpath("//span[@class='h3 card-title']");
	private static final By txtParticipant = By.xpath("//legend[contains(text(),'Participant')]");
	private static final By chkBoxParticipants = By.xpath("//div[@class='c-inputs-stacked']//span[@class='c-indicator']");
	private static final By btnClose = By.xpath("//button[text()='Close']");

	private static final By hdrPendingResr = By.xpath("//section[@class='reservation']//h1");
	private static final By navLinkWork = By.xpath("//a[text()='Work']");

	private static final By txtStartTime = By.xpath("//div[@class='form-control-static']//time");
	private static final By txtCourt = By.xpath("//h2[@class='card-title-wrapper']//span[2]");
	private static final By drpdwnDuration = By.xpath("//select[@id='duration']");
	private static final By txtTimeStart = By.xpath("(//div[@class='card-section-cell']//time)[2]");

	private static final By txtTimeEnd = By.xpath("//div[@class='card-section-cell']//span[@class='time-to']/following-sibling::time");

	private static final By txtCourtName = By.xpath("//div[@class='container']//span[@class='h5']");
	private static final By txtCourtAndLocation = By.xpath("(//div[@class='card-section-cell']//p)[3]");
	private static final By txtStartToEndTime = By.xpath("(//div[@class='card-section-cell']//p)[2]");











	public WebElement gettxtStartToEndTime() {
		return waitForElementToBeVisible(txtStartToEndTime);
	}
	public WebElement gettxtCourtAndLocation() {
		return waitForElementToBeVisible(txtCourtAndLocation);
	}

	public WebElement gettxtCourtName() {
		return waitForElementToBeVisible(txtCourtName);
	}
	public WebElement gettxtTimeEnd() {
		return waitForElementToBeVisible(txtTimeEnd);
	}
	public WebElement gettxtTimeStart() {
		return waitForElementToBeVisible(txtTimeStart);
	}
	public WebElement getdrpdwnDuration() {
		return waitForElementToBeVisible(drpdwnDuration);
	}
	public WebElement gettxtCourt() {
		return waitForElementToBeVisible(txtCourt);
	}

	public WebElement gettxtStartTime() {
		return waitForElementToBeVisible(txtStartTime);
	}
	public WebElement getnavLinkWork() {
		return waitForElementToBeVisible(navLinkWork);
	}

	public WebElement getHdrPendingResr() {
		return waitForElementToBeVisible(hdrPendingResr);
	}
	public WebElement getarticipants() {
		return waitForElementToBeVisible(chkBoxParticipants);
	}

	public WebElement getTitle() {
		return waitForElementToBeVisible(txtTitle);
	}
	public WebElement getTax() {
		return waitForElementToBeVisible(txtTax);
	}

	public WebElement getLinkCancel() {
		return waitForElementToBeClickable(lnkCancel);
	}
	public WebElement getPolicyWaivers() {
		return waitForElementToBeVisible(txtResPolicyWaiver);
	}/**
	 * @return Participants
	 */
	public WebElement getParticipants() {
		return waitForElement(chkBoxParticipants);
	}

	/**
	 * @return the Payment button
	 */
	public WebElement getBtnContinueToPayment() {
		return waitForElementToBeVisible(btnContinueToPayment);
	}

	/**
	 * @return the Minute on screeen
	 */
	public WebElement getMinute() {
		return waitForElementToBeVisible(txtTimeLeftToComplete);
	}


	/**
	 * Method to Confirm Reservation
	 */
	public void confirmReservation() {

		clickElement(chkBoxTermsAndCondition);		
		clickElement(btnFinish);			
	}

	/**
	 * Method to cancel Reservation
	 */
	public void cancelReservation() {
		clickElement(chkBoxTermsAndCondition);
		clickElement(lnkCancel);		
	}

	/**
	 * Method to verify reservation policy and waiver
	 */

	public void verifyReservationPolicyAndWaiver() {
		waitForElementToBeClickable(lnkResPolicyWaiver);
		clickElement(lnkResPolicyWaiver);
		Assert.assertTrue(isElementPresent(getPolicyWaivers()));
		clickElement(btnClose);
	}


	/**
	 * Method to select All Participants
	 */
	public int selectParticipants() {

		List<WebElement> els = driver.findElements(chkBoxParticipants);
		for (WebElement el : els) {
			if (!el.isSelected()) {
				clickElement(el);
			}
		}
		int numberOfParticipants = els.size();
		return numberOfParticipants;
	}

	/**
	 * Method to verify whether all the participants checkboxes are enabled to select
	 */
	public void verifyParticipantsEnabled() {		

		isElementPresent(txtParticipant);
		List<WebElement> participants = driver.findElements(chkBoxParticipants);

		for(WebElement participant : participants)
		{    	
			Assert.assertTrue(participant.isEnabled());
		}		
	}

	public int timerStart() {

		String main = getMinute().getText();
		String sub = main.substring(1, 2);

		String count = sub;
		return Integer.parseInt(count);

	}


	public void verifyCourtTitle(String[] courtDetails, String courtName)
	{
		waitUntilSpinnerDisappears();
		verifyPageTitle(Constants.CourtReservations);
		Assert.assertTrue(isElementPresent(getHdrPendingResr()));
		Assert.assertTrue(gettxtCourtName().getText().contains(courtName));
		Assert.assertTrue(isTextPresent(gettxtCourt(), courtDetails[1]));
	}


	public void verifyCourtDetails(String[] courtDetails, String clubLocation, int duration)
	{	
		try {
			verifyPageTitle(Constants.CourtReservations);

			Assert.assertTrue(isElementPresent(getHdrPendingResr()));//verify header pending reservation
			Assert.assertTrue(isTextPresent(gettxtStartTime(), courtDetails[0]));//verify time starting
			
			Assert.assertTrue(isTextPresent(gettxtCourt(), courtDetails[1]));	//verify court value
			//verify down section court and location
			String CourtAndClubLocation = courtDetails[1]+","+" "+clubLocation;
			Assert.assertTrue(gettxtCourtAndLocation().getText().contains( CourtAndClubLocation ));//verify down section court and location
			//verify down section time start
			String TimeFrom =   courtDetails[0].substring(0, courtDetails[0].length() - 3);
			Assert.assertTrue(gettxtTimeStart().getText().contains( TimeFrom));//verify down section time start
			//Add 30 minutes to the current time
			String startTime = courtDetails[0];
			String endTime = getEndTime(startTime, duration);
			//verify down section End Time with 30 mins added
			Assert.assertTrue(gettxtTimeEnd().getText().contains( endTime));//verify down section End Time 30 mins
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void selectCheckBoxParticipants(){
	
	if(isElementPresent(chkBoxParticipants)) {
		clickElement(chkBoxParticipants);
		}
	}
}
