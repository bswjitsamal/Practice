package net.lt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import net.lt.common.Constants;
import net.lt.common.Utility;

public class ProgramsPage extends Utility {

	public ProgramsPage(WebDriver driver) {
		super(driver);
	}

	/**
	 * Parameter X-Path veriable
	 */

	private static final By ALERT_MSG = By.xpath("//div[@id='notification-schreg']//div[@role='alert']");


	private static final By BTN_RESERVEACOURT = By.xpath("//a[starts-with(text(),'Reserve')]");
	private static final By SELECTPICKLEBALL = By.xpath("//div[@class='cmpt-row']//div[@class='cmpt-col-md-5 cmpt-col-lg-4']/parent::div//select");
	private static final By ALERTMSG = By.xpath("//div[@class='container']//div[@role='alert']");
	private static final By LNKPROGRAMS = By.xpath("//a[text()='Programs']");	

	private static final By BTN_NEXTDAY = By.xpath(".//*[@id='main-content']//span[@class='ico-arrow-right']");
	private static final By BTN_PREVIOUSDAY = By.xpath(".//*[@id='main-content']//span[@class='ico-arrow-left']");
	private static final By BTN_AVAILABLETIME = By.xpath(
			".//div[@class='facilities']//ul//a[contains(@href,'/account/')]");
	private static final By AVAILABLE_TIME = By.xpath(
			".//div[@class='facilities']//ul//a[contains(@href,'/account/')]//p//time");
	private static final By BTN_AVAILABLE_TIME_CONFERENCEROOM = By.xpath(
			".//*[@id='main-content']//ui-view/section//div[@class='facility-container facility-container-main']/div/div[@class='facilities']//ul//a[contains(@href,'/member/')]");
	private static final By COURT_NAME = By.xpath(
			".//div[@class='facilities']//ul//a[contains(@href,'/account/')]/../../preceding-sibling::div[1]/span");
	

	public WebElement getReserveACourtButton() {
		return waitForElement(BTN_RESERVEACOURT);
	}


	public By getBtnAvailableTimeConferenceRoom() {
		return BTN_AVAILABLE_TIME_CONFERENCEROOM;
	}


	public WebElement getDropdown() {
		return waitForElementToBeVisible(SELECTPICKLEBALL);
	}

	/**
	 * @return the available time on a day
	 */
	public WebElement geBtnAvailTime() {
		return waitForElementToBeVisible(BTN_AVAILABLETIME);

	}

	public WebElement getAlertMsg() {
		return waitForElement(ALERT_MSG);
	}
	
	/**
	 * Method to reserve a Court
	 */

	public String[] reserveACourt(String courtName, int noOfDaysFromCurrentDay) {
		String selectedTime = "";
		String selectedCourt = "";
		try {

			int days = 0;
			String text = "";
			clickElement(BTN_RESERVEACOURT);
			verifyPageTitle(Constants.FACILITIES_PAGE_TITLE);
			if(courtName.equalsIgnoreCase("RacquetBall") 
					|| courtName.equalsIgnoreCase("Tennis"))
			{
				days = 7;
				text = "Note: Your current membership does not allow you to reserve more than 7 days in advance. Please contact your club for more information at (720) 482-5700";
			}else if(courtName.equalsIgnoreCase("Squash"))
			{
				days = 3;
				text = "Note: Your current membership does not allow you to reserve more than 3 days in advance. Please contact your club for more information at (720) 482-5700";
			}			

			for (int i = 0; i != noOfDaysFromCurrentDay; i++) {
				clickElement(BTN_NEXTDAY);				
			}
			if(isElementPresent(BTN_AVAILABLETIME))
			{
				selectedTime = driver.findElement(AVAILABLE_TIME).getText();
				selectedCourt = driver.findElement(COURT_NAME).getText();				
				clickElement(waitForElementToBeClickable(BTN_AVAILABLETIME));
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new String[] { selectedTime, selectedCourt };


	}



}